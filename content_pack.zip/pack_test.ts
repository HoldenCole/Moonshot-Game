// pack_test.ts — prove the DLC foundation: a sample pack merges additively,
// collisions are caught, and merged content loads + plays.
import raw from "./content.json";
import { mergeContentPacks, loadContracts, loadSubEvents, loadRivals } from "./content_loader";

let pass = 0, fail = 0;
const ok = (n: string, c: boolean, d = "") => { c ? pass++ : fail++; console.log(`${c ? "✓" : "✗"} ${n}${d ? " — " + d : ""}`); };

const samplePack = {
  id: "dlc_sample",
  content: {
    contracts: { templates: {
      dlc_sample_lunar_tourism: { id: "dlc_sample_lunar_tourism", customer: "commercial_enterprise",
        name: "Lunar Tourism Charter", sub_industry: "launch_services",
        description: "A sample-pack contract proving DLC merge.",
        requires: { product_tier: 2, stature_min: 5000 },
        payment: { upfront: 50, recurring_per_year: 80, term_weeks: 104 },
        effects: { power: 0, entanglement: 0, reputation: 1 } } } },
    events_world: { dlc_sample_events: {
      dlc_sample_comet: { id: "dlc_sample_comet", pool: "world", kind: "flavor", weight: 2,
        cooldown_weeks: 300, headline: "A great comet crosses the sky",
        body: "For two weeks, everyone on Earth looks up." } } },
    rivals: { rivals: {
      dlc_sample_rival: { id: "dlc_sample_rival", name: "Nadir Group", ceo: "R. Voss",
        tagline: "Sample-pack rival.", branches: ["space"], home_subs: ["launch_services"],
        aggression: 0.5, variance: 0.2, starting_stature: 9000, stature_growth_per_year: 0.1,
        ambitions: ["orbital_solar_array"], news_style: "institutional", description: "A merge test." } } },
  },
};

const base = structuredClone(raw) as Record<string, any>;
const before = {
  contracts: Object.keys(base.contracts.templates).length,
  rivals: Object.keys(base.rivals.rivals).length,
};
const reports = mergeContentPacks(base, [samplePack]);
ok("pack: additive merge reports adds", reports[0].added === 3, JSON.stringify(reports[0]));
const contracts = loadContracts(base.contracts);
const rivals = loadRivals(base.rivals);
const world = loadSubEvents(base.events_world);
ok("pack: contract count grows through the SAME loader",
  Object.keys(contracts.templates).length === before.contracts + 1
  && contracts.templates["dlc_sample_lunar_tourism"].name === "Lunar Tourism Charter");
ok("pack: rival + world event land", Object.keys(rivals.defs).length === before.rivals + 1
  && world.some(e => e.id === "dlc_sample_comet"));

// collision policy: same pack again must THROW
let threw = false;
try { mergeContentPacks(base, [samplePack]); } catch { threw = true; }
ok("pack: id collisions are a hard error (no silent overrides)", threw);
console.log(`\n=== ${pass} passed, ${fail} failed ===`);
