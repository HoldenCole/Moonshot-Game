// ============================================================================
// pacing_test.ts — THE FEEL HARNESS. Runs 24 seeded 800-week campaigns and
// measures the drama curve against hard targets:
//   T1  dead turns (nothing visible happens) < 12% of turns
//   T2  noisy turns (>6 beats) < 15% — eventful, not spammy
//   T3  every campaign sees >= 2 winters AND >= 1 boom (the downs are reliable)
//   T4  >= 60% of campaigns experience >= 1 pressure arc
//   T5  eras traverse in order; the scripted titan campaign reaches sovereign
//   T6  during winters, net cash growth is measurably below boom growth
// ============================================================================
import raw from "./content.json";
import { loadSubEconomies, loadSynergies, loadContracts, loadPowerEvents, loadSubEvents,
         loadResearchNodes, loadMegaprojects, loadRivals, megaMetaFrom,
         loadEras, loadCycleTuning, loadPressures } from "./content_loader";
import { GameSlice, GameContent, advanceTurn, TurnReport } from "./turn";
import { initResearch } from "./research";
import { initContracts, takeContract, refreshMarket } from "./contracts";
import { initRivals } from "./rivals";
import { initCycle, pressureTriggerMap } from "./pacing";
import { checkGate, beginMega } from "./megaprojects";

function rng(seed: number) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0;
  let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
  return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
let pass = 0, fail = 0;
const ok = (n: string, c: boolean, d = "") => { c ? pass++ : fail++; console.log(`${c ? "✓" : "✗"} ${n}${d ? " — " + d : ""}`); };

const contracts = loadContracts((raw as any).contracts);
const megaprojects = loadMegaprojects((raw as any).megaprojects);
const rivalsL = loadRivals((raw as any).rivals);
const pressures = loadPressures((raw as any).pressures);
const content: GameContent = {
  researchNodes: loadResearchNodes((raw as any).research), megaprojects,
  subEconomies: loadSubEconomies((raw as any).sub_economies), synergies: loadSynergies((raw as any).synergies),
  contractTemplates: contracts.templates, customers: contracts.customers,
  powerEvents: loadPowerEvents((raw as any).events_power), subEvents: loadSubEvents((raw as any).events_sub),
  worldEvents: loadSubEvents((raw as any).events_world),
  rivalDefs: rivalsL.defs, rivalTuning: rivalsL.tuning, megaMeta: megaMetaFrom(megaprojects),
  eras: loadEras((raw as any).eras), cycleTuning: loadCycleTuning((raw as any).cycles),
  pressures, pressureTriggers: pressureTriggerMap(Object.values(pressures)) };

function beats(r: TurnReport): number {
  return r.researchCompleted.length + r.megaBeats.length + r.megaCompleted.length
    + r.subEconomyCrises.filter(x => x.event).length + (r.powerEventFired ? 1 : 0)
    + r.rivalNews.length + (r.worldNews ? 1 : 0) + (r.marketRefreshed ? 1 : 0)
    + r.contractsExpired.length + r.legaciesClaimedByPlayer.length + r.legaciesLostToRivals.length
    + (r.eraTransition ? 1 : 0) + (r.cycleShift ? 1 : 0) + r.pressuresStarted.length + r.pressuresEnded.length;
}

const N = 24, TURNS = 200;
let deadTotal = 0, noisyTotal = 0, turnsTotal = 0;
let campaignsWithWinters = 0, campaignsWithBoom = 0, campaignsWithPressure = 0, eraOrderOk = 0, sovereignReached = 0;
let boomNet = 0, boomTurns = 0, winterNet = 0, winterTurns = 0;

for (let ci = 0; ci < N; ci++) {
  const r = rng(1000 + ci * 7);
  const s: GameSlice = { week: 0, cashM: 9000, stature: 33000,
    frontsOperated: ["launch_services", "space_stations", "ai_chips", "frontier_model_lab", "satellite_constellations"],
    rdLevels: {}, productTiers: { satellite_constellations: 2, ai_chips: 2, frontier_model_lab: 2, launch_services: 2, space_stations: 2, vertical_ai_saas: 2 },
    execQualityByDomain: { space_program: 0.85 }, maxMarketShare: 0.45,
    research: initResearch(Object.values(content.researchNodes)),
    megas: { builds: {}, active: [], slots_total: 2 }, subEcon: { instances: {}, resource_pool: {} },
    contracts: initContracts(),
    powerAxis: { power: 0, basePower: 0, reputation: 0, regulationLevel: 0, eventCooldowns: {} },
    activeSynergies: [], rivals: initRivals(rivalsL.defs, rivalsL.tuning, content.megaMeta),
    claimedLegacies: {}, era: "titan", cycle: initCycle(content.cycleTuning, r), activePressures: [] };
  refreshMarket(s.contracts, content.contractTemplates, content.customers,
    { stature: s.stature, productTiers: s.productTiers, rdLevels: s.rdLevels,
      frontsOperated: s.frontsOperated, clearances: ["defense_secret"] }, r);
  s.contracts.clearances = ["defense_secret"];
  s.research.nodes["mass_manufacturing"].state = "in_progress";
  s.research.nodes["inter_satellite_links"].state = "in_progress";
  const CHAIN = ["mass_manufacturing", "inter_satellite_links", "global_broadband", "space_solar_power"];
  let winters = 0, booms = 0, sawPressure = false, orderOk = true, lastOrder = 0, sawSovereign = false;
  for (let t = 0; t < TURNS; t++) {
    const gate = checkGate(megaprojects.orbital_solar_array, {
      researchDone: new Set(Object.entries(s.research.nodes).filter(([, n]) => n.state === "complete").map(([id]) => id)),
      stature: s.stature, cash: s.cashM, execDomains: new Set(["space_program"]), capacity: {}, megasDone: new Set() });
    if (gate.met && !s.megas.active.length) {
      const b = beginMega(s.megas, megaprojects.orbital_solar_array, s.week);
      if (b.ok) s.cashM -= b.cost;
    }
    for (const nid of CHAIN) {
      const st = s.research.nodes[nid].state as string;
      if ((st === "available" || st === "locked") && content.researchNodes[nid].prereqs.every(p => (s.research.nodes[p].state as string) === "complete"))
        s.research.nodes[nid].state = "in_progress";
    }
    const phaseBefore = s.cycle.phase;
    const rep = advanceTurn(s, content, r);
    if (rep.marketRefreshed && s.contracts.active.length < 4) {
      const el = s.contracts.market.map(id => content.contractTemplates[id])
        .filter(tt => !tt.requires.clearance || s.contracts.clearances.includes(tt.requires.clearance));
      const next = el.find(tt => content.customers[tt.customer].channel === "government") ?? el[0];
      if (next) takeContract(s.contracts, next);
    }
    // stature drifts up with the empire (proxy for the finance layer)
    s.stature *= 1.004;
    const b = beats(rep);
    turnsTotal++; if (b === 0) deadTotal++; if (b > 6) noisyTotal++;
    if (rep.cycleShift?.phase === "winter") winters++;
    if (rep.cycleShift?.phase === "boom") booms++;
    if (rep.pressuresStarted.length) sawPressure = true;
    const eraDef = content.eras.find(e => e.id === s.era)!;
    if (eraDef.order < lastOrder) orderOk = false;
    lastOrder = eraDef.order;
    if (s.era === "sovereign") sawSovereign = true;
    if (phaseBefore === "boom") { boomNet += rep.netCash; boomTurns++; }
    if (phaseBefore === "winter") { winterNet += rep.netCash; winterTurns++; }
  }
  if (winters >= 2) campaignsWithWinters++;
  if (booms >= 1) campaignsWithBoom++;
  if (sawPressure) campaignsWithPressure++;
  if (orderOk) eraOrderOk++;
  if (sawSovereign) sovereignReached++;
}

const deadPct = (100 * deadTotal / turnsTotal), noisyPct = (100 * noisyTotal / turnsTotal);
ok("T1 dead turns < 12%", deadPct < 12, `${deadPct.toFixed(1)}% of ${turnsTotal} turns`);
ok("T2 noisy turns (>6 beats) < 15%", noisyPct < 15, `${noisyPct.toFixed(1)}%`);
ok("T3 downs are reliable: >=2 winters + >=1 boom every campaign",
  campaignsWithWinters === N && campaignsWithBoom === N, `${campaignsWithWinters}/${N} winters, ${campaignsWithBoom}/${N} booms`);
ok("T4 pressure arcs reach >=60% of campaigns", campaignsWithPressure >= N * 0.6, `${campaignsWithPressure}/${N}`);
ok("T5 eras traverse in order; sovereign reached", eraOrderOk === N && sovereignReached >= N * 0.9,
  `order ok ${eraOrderOk}/${N}, sovereign ${sovereignReached}/${N}`);
const boomAvg = boomNet / Math.max(1, boomTurns), winterAvg = winterNet / Math.max(1, winterTurns);
ok("T6 winters bite: winter net/turn < 80% of boom net/turn", winterAvg < boomAvg * 0.8,
  `boom $${boomAvg.toFixed(0)}M/turn vs winter $${winterAvg.toFixed(0)}M/turn`);
console.log(`\n=== ${pass} passed, ${fail} failed ===`);
