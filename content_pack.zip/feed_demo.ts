// feed_demo — print the actual living-world feed from a campaign, as the player would read it
import raw from "./content.json";
import { loadSubEconomies, loadSynergies, loadContracts, loadPowerEvents, loadSubEvents,
         loadResearchNodes, loadMegaprojects, loadRivals, megaMetaFrom, loadEras, loadCycleTuning, loadPressures } from "./content_loader";
import { GameSlice, GameContent, advanceTurn } from "./turn";
import { initResearch } from "./research";
import { initContracts, takeContract, refreshMarket } from "./contracts";
import { initRivals } from "./rivals";
import { initCycle, pressureTriggerMap } from "./pacing";
import { checkGate, beginMega } from "./megaprojects";

function rng(seed: number) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0;
  let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
  return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

const contracts = loadContracts((raw as any).contracts);
const megaprojects = loadMegaprojects((raw as any).megaprojects);
const rivals = loadRivals((raw as any).rivals);
const content: GameContent = {
  researchNodes: loadResearchNodes((raw as any).research), megaprojects,
  subEconomies: loadSubEconomies((raw as any).sub_economies), synergies: loadSynergies((raw as any).synergies),
  contractTemplates: contracts.templates, customers: contracts.customers,
  powerEvents: loadPowerEvents((raw as any).events_power), subEvents: loadSubEvents((raw as any).events_sub),
  worldEvents: loadSubEvents((raw as any).events_world),
  rivalDefs: rivals.defs, rivalTuning: rivals.tuning, megaMeta: megaMetaFrom(megaprojects),
  eras: loadEras((raw as any).eras), cycleTuning: loadCycleTuning((raw as any).cycles),
  pressures: loadPressures((raw as any).pressures),
  pressureTriggers: pressureTriggerMap(Object.values(loadPressures((raw as any).pressures))) };

const s: GameSlice = { week: 0, cashM: 9000, stature: 33000,
  frontsOperated: ["launch_services", "space_stations", "ai_chips", "frontier_model_lab", "satellite_constellations"],
  rdLevels: {}, productTiers: { satellite_constellations: 2 },
  execQualityByDomain: { space_program: 0.85 }, maxMarketShare: 0.45,
  research: initResearch(Object.values(content.researchNodes)),
  megas: { builds: {}, active: [], slots_total: 2 }, subEcon: { instances: {}, resource_pool: {} },
  contracts: initContracts(),
  powerAxis: { power: 0, basePower: 0, reputation: 0, regulationLevel: 0, eventCooldowns: {} },
  activeSynergies: [], rivals: initRivals(rivals.defs, rivals.tuning, megaMetaFrom(megaprojects)),
  claimedLegacies: {},
  era: "titan", cycle: initCycle(loadCycleTuning((raw as any).cycles), rng(99)), activePressures: [] };
const r = rng(2077);
refreshMarket(s.contracts, content.contractTemplates, content.customers,
  { stature: s.stature, productTiers: s.productTiers, rdLevels: s.rdLevels,
    frontsOperated: s.frontsOperated, clearances: ["defense_secret"] }, r);
s.contracts.clearances = ["defense_secret"];
s.research.nodes["mass_manufacturing"].state = "in_progress";
s.research.nodes["inter_satellite_links"].state = "in_progress";
const CHAIN = ["mass_manufacturing", "inter_satellite_links", "global_broadband", "space_solar_power"];

let printed = 0;
for (let turn = 0; turn < 200; turn++) {
  const gate = checkGate(megaprojects.orbital_solar_array, {
    researchDone: new Set(Object.entries(s.research.nodes).filter(([, n]) => n.state === "complete").map(([id]) => id)),
    stature: s.stature, cash: s.cashM, execDomains: new Set(["space_program"]), capacity: {}, megasDone: new Set() });
  if (gate.met && !s.megas.active.length && !(s.megas.builds["orbital_solar_array"] ?? 0)) {
    const b = beginMega(s.megas, megaprojects.orbital_solar_array, s.week);
    if (b.ok) { s.cashM -= b.cost; console.log(`WK ${s.week}  ▶ YOU break ground on The Sunfarm — $${b.cost}M committed.`); printed++; }
  }
  for (const nid of CHAIN) {
    const st = s.research.nodes[nid].state as string;
    if ((st === "available" || st === "locked") && content.researchNodes[nid].prereqs.every(p => (s.research.nodes[p].state as string) === "complete"))
      s.research.nodes[nid].state = "in_progress";
  }
  const rep = advanceTurn(s, content, r);
  for (const id of rep.researchCompleted) { console.log(`WK ${rep.week}  ◆ YOUR LAB: ${content.researchNodes[id].name} complete.`); printed++; }
  for (const m of rep.megaCompleted) { console.log(`WK ${rep.week}  ★ ${content.megaprojects[m.def_id].name} IS FINISHED.`); printed++; }
  for (const l of rep.legaciesClaimedByPlayer) { console.log(`WK ${rep.week}  ♛ HISTORY IS YOURS: "${l.replace(/_/g, " ")}"`); printed++; }
  for (const n of rep.rivalNews) if (["surge","beaten","second_place","legacy_claim","groundbreak","completion"].includes(n.kind)) { console.log(`WK ${rep.week}  ${n.kind === "legacy_claim" ? "♛" : n.kind === "surge" ? "⚡" : n.kind === "beaten" ? "!" : "·"} [${n.kind}] ${n.text}`); printed++; }

}
