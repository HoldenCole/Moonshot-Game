// exec_test.ts — the executive engine on real content
import raw from "./content.json";
import { loadExecutives } from "./content_loader";
import { initExecs, generateCandidates, hireExec, fireExec, tickRetention, execQuality } from "./executives";
import { loadRivals, megaMetaFrom, loadMegaprojects } from "./content_loader";
import { initRivals, tickRivalPoaching } from "./rivals";

function rng(seed: number) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0;
  let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
  return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
let pass = 0, fail = 0;
const ok = (n: string, c: boolean, d = "") => { c ? pass++ : fail++; console.log(`${c ? "✓" : "✗"} ${n}${d ? " — " + d : ""}`); };

const ec = loadExecutives((raw as any).executives);
ok("loader: 7 domains, 8 traits, 14 archetypes", Object.keys(ec.domains).length === 7
  && Object.keys(ec.traits).length === 8 && Object.keys(ec.archetypes).length === 14);

const r = rng(42);
// stature gating: a $500M startup should never see titan-tier candidates
const early = generateCandidates(ec.archetypes, ec.traits, ec.names, ec.domains, 500, ec.tuning, r);
ok("generation: stature-gated (no titan roles at $500M)",
  early.length > 0 && early.every(c => !["chief_scientist", "space_program", "chief_executive"].includes(c.domain)));
const titan = generateCandidates(ec.archetypes, ec.traits, ec.names, ec.domains, 40000, ec.tuning, r);
ok("generation: titan market includes the mega-gating roles",
  titan.some(c => ["chief_scientist", "space_program", "chief_executive"].includes(c.domain)));
ok("generation: comp scales with competence + premium",
  titan.every(c => c.ask_salary >= c.competence * 0.05 * 0.99 && c.ask_equity >= 0.005));

// hiring: fill a seat, block a second
const s = initExecs();
s.market = titan;
const cand = titan.find(c => c.domain === "cto") ?? titan[0];
ok("hire: seats the exec", hireExec(s, cand, cand.ask_salary, 0).ok && !!s.seats[cand.domain]);
const cand2 = { ...cand, id: "other" };
ok("hire: one seat per domain", !hireExec(s, cand2, cand2.ask_salary, 0).ok);

// quality feed
const q = execQuality(s, ec.traits);
ok("quality: competence -> 0..1 feed", q[cand.domain] > 0 && q[cand.domain] <= 1,
  `${cand.domain}=${q[cand.domain]} (comp ${cand.competence}${cand.traits.includes("star") ? "+star" : ""})`);

// retention: fairly paid never defects; badly underpaid star defects over time
const rFair = rng(7);
let fairGone = 0;
for (let i = 0; i < 40; i++) fairGone += tickRetention(s, ec.traits, ec.tuning, i * 13, 13, rFair).length;
ok("retention: fairly paid exec stays (40 quarters)", fairGone === 0);
const s2 = initExecs();
const star = { ...cand, id: "star_x", traits: ["star"], ask_salary: 5, domain: "cfo" };
hireExec(s2, star, 1, 0);   // pay 1 vs ask 5 — badly underpaid star
const rPoach = rng(9);
let poached = 0;
for (let i = 0; i < 40 && !poached; i++) poached += tickRetention(s2, ec.traits, ec.tuning, i * 13, 13, rPoach).length;
ok("retention: underpaid star gets poached", poached === 1 && s2.departures[0]?.reason === "poached");

// firing costs severance
const s3 = initExecs();
hireExec(s3, cand, cand.ask_salary, 0);
const fired = fireExec(s3, cand.domain, 10, ec.tuning);
ok("fire: severance + morale hit, seat empties", !!fired && fired.severance > 0 && !s3.seats[cand.domain]);

// --- rival poaching ---
const rivalsLoaded = loadRivals((raw as any).rivals);
const meta = megaMetaFrom(loadMegaprojects((raw as any).megaprojects));
const rstates = initRivals(rivalsLoaded.defs, rivalsLoaded.tuning, meta);
// an underpaid star with low morale: raid bait
const s4 = initExecs();
hireExec(s4, { ...cand, id: "bait", name: "Priya Raman", domain: "cto", traits: ["star"],
  competence: 92, ask_salary: 6 }, 1, 0);
s4.seats["cto"].morale = 0.2;
const rp = rng(13);
let poachNews = null as null | { text: string; kind: string };
for (let i = 0; i < 60 && !poachNews; i++) {
  const res = tickRivalPoaching(rstates, rivalsLoaded.defs, rivalsLoaded.tuning, s4.seats, ec.traits, i * 4, 4, rp);
  poachNews = res.news.find(n => n.kind === "poach") ?? null;
}
ok("poaching: rivals raid an underpaid star BY NAME", !!poachNews && poachNews.text.includes("Priya Raman"),
  poachNews ? poachNews.text.slice(0, 90) : "no raid in 60 turns");
// a well-paid loyalist resists every raid
const s5 = initExecs();
hireExec(s5, { ...cand, id: "rock", name: "Dana Whitfield", domain: "cfo", traits: ["loyalist"],
  competence: 80, ask_salary: 4 }, 5, 0);
const rp2 = rng(1);
let lost = 0, resisted = 0;
for (let i = 0; i < 240; i++) {
  const res = tickRivalPoaching(rstates, rivalsLoaded.defs, rivalsLoaded.tuning, s5.seats, ec.traits, i * 4, 4, rp2);
  lost += res.poachedDomains.length;
  resisted += res.news.filter(n => n.kind === "poach_resisted").length;
}
ok("poaching: a well-paid loyalist holds the line", lost === 0 && resisted >= 1,
  `${resisted} offers turned down over ~18 years, 0 lost`);

console.log(`\n=== ${pass} passed, ${fail} failed ===`);
