// ============================================================================
// sim_test.ts — End-to-end: REAL content files -> loader -> 200-week campaign
// through the turn processor. Proves the whole stack composes.
// ============================================================================
import raw from "./content.json";
import { loadSubEconomies, loadSynergies, loadContracts, loadPowerEvents, loadSubEvents, loadResearchNodes, loadMegaprojects, loadRivals, megaMetaFrom, loadEras, loadCycleTuning, loadPressures } from "./content_loader";
import { initRivals } from "./rivals";
import { initCycle, pressureTriggerMap } from "./pacing";
import { GameSlice, GameContent, advanceTurn } from "./turn";
import { initResearch, ResearchNode } from "./research";
import { MegaprojectDef, checkGate, beginMega } from "./megaprojects";
import { initContracts, takeContract, refreshMarket, govShare, mixIdentity } from "./contracts";

function rng(seed: number) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0;
  let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
  return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
let pass = 0, fail = 0;
const ok = (n: string, c: boolean, d = "") => { c ? pass++ : fail++; console.log(`${c ? "✓" : "✗"} ${n}${d ? " — " + d : ""}`); };

// ---- load REAL content ----
const subEconomies = loadSubEconomies((raw as any).sub_economies);
const synergies = loadSynergies((raw as any).synergies);
const contracts = loadContracts((raw as any).contracts);
const powerEvents = loadPowerEvents((raw as any).events_power);
const subEvents = loadSubEvents((raw as any).events_sub);
ok("loader: 11 sub-economies", Object.keys(subEconomies).length === 11);
ok("loader: 20 synergies", synergies.length === 20);
ok("loader: 30 contract templates + 5 customers", Object.keys(contracts.templates).length === 30 && Object.keys(contracts.customers).length === 5);
ok("loader: 23 power events, 66 sub events", powerEvents.length === 23 && subEvents.length === 66);

// ---- THE REAL 82-node tree + 11 megaprojects, loaded from content ----
const researchNodes = loadResearchNodes((raw as any).research);
const megaprojects = loadMegaprojects((raw as any).megaprojects);
ok("loader: 82 research nodes, 11 megaprojects", Object.keys(researchNodes).length === 82 && Object.keys(megaprojects).length === 11);
ok("loader: satellite chain wired", researchNodes["space_solar_power"].gates_megaproject === "orbital_solar_array"
  && megaprojects["orbital_solar_array"].repeatable === true);

const rivalsLoaded = loadRivals((raw as any).rivals);
const megaMeta = megaMetaFrom(megaprojects);
const worldEvents = loadSubEvents((raw as any).events_world);
ok("loader: 6 rivals, 24 world events, mega meta w/ legacies", Object.keys(rivalsLoaded.defs).length === 6
  && worldEvents.length === 24 && megaMeta["mars_colony"].legacy === "first_on_mars");
const content: GameContent = { researchNodes, megaprojects, subEconomies, synergies,
  contractTemplates: contracts.templates, customers: contracts.customers, powerEvents, subEvents,
  worldEvents, rivalDefs: rivalsLoaded.defs, rivalTuning: rivalsLoaded.tuning, megaMeta,
  eras: loadEras((raw as any).eras), cycleTuning: loadCycleTuning((raw as any).cycles),
  pressures: loadPressures((raw as any).pressures),
  pressureTriggers: pressureTriggerMap(Object.values(loadPressures((raw as any).pressures))) };

const s: GameSlice = {
  week: 0, cashM: 9000, stature: 33000,
  frontsOperated: ["launch_services", "space_stations", "ai_chips", "frontier_model_lab"],
  rdLevels: { ai_chips: { process_node: 60, architecture: 40, yield_line: 55 },
              launch_services: { reliability: 60, reusability: 50, propulsion: 40 },
              space_stations: { module_tech: 50, life_support: 45, assembly: 40 },
              frontier_model_lab: { scaling: 50, alignment: 45, data_quality: 40 } },
  productTiers: { ai_chips: 2, launch_services: 2, space_stations: 2, frontier_model_lab: 2 },
  execQualityByDomain: { space_program: 0.85, cfo: 0.8 },
  maxMarketShare: 0.45,
  research: initResearch(Object.values(researchNodes)),
  megas: { builds: {}, active: [], slots_total: 2 },
  subEcon: { instances: {}, resource_pool: {} },
  contracts: initContracts(),
  powerAxis: { power: 0, basePower: 0, reputation: 0, regulationLevel: 0, eventCooldowns: {} },
  activeSynergies: [],
  rivals: initRivals(rivalsLoaded.defs, rivalsLoaded.tuning, megaMeta),
  claimedLegacies: {},
  era: "titan", cycle: initCycle(loadCycleTuning((raw as any).cycles), rng(99)), activePressures: [],
};
const r = rng(2077);

// Week 0 actions: refresh the market on real content, take a gov + a commercial contract
refreshMarket(s.contracts, content.contractTemplates, content.customers,
  { stature: s.stature, productTiers: s.productTiers, rdLevels: s.rdLevels,
    frontsOperated: s.frontsOperated, clearances: ["defense_secret"] }, r);
s.contracts.clearances = ["defense_secret"];
ok("campaign: market offers real deals", s.contracts.market.length >= 4, `${s.contracts.market.length} offers`);
const govDeal = s.contracts.market.map(id => content.contractTemplates[id])
  .find(t => content.customers[t.customer].channel === "government" && (!t.requires.clearance || t.requires.clearance === "defense_secret"));
const commDeal = s.contracts.market.map(id => content.contractTemplates[id])
  .find(t => content.customers[t.customer].channel === "commercial");
if (govDeal) takeContract(s.contracts, govDeal);
if (commDeal) takeContract(s.contracts, commDeal);
ok("campaign: took 1 gov + 1 commercial", s.contracts.active.length === 2);

// The REAL chain to the Orbital Solar Array:
// mass_manufacturing + inter_satellite_links -> global_broadband -> space_solar_power (frontier) -> mega
const CHAIN = ["mass_manufacturing", "inter_satellite_links", "global_broadband", "space_solar_power"];
s.research.nodes["mass_manufacturing"].state = "in_progress";
s.research.nodes["inter_satellite_links"].state = "in_progress";

// ---- run 200 weeks (50 turns) with simple policy ----
let megaBegun = false, subOpened = false, synergyLive = false, powerEventCount = 0, crisisCount = 0;
let rivalNewsCount = 0, worldNewsCount = 0, rivalLegacyClaims = 0, rivalCompletions = 0;
const reactKinds = new Set<string>();
for (let turn = 0; turn < 200; turn++) {
  // policy: when research allows, begin the mega; keep research moving
  if (!megaBegun) {
    const gate = checkGate(megaprojects.orbital_solar_array, {
      researchDone: new Set(Object.entries(s.research.nodes).filter(([, n]) => n.state === "complete").map(([id]) => id)),
      stature: s.stature, cash: s.cashM, execDomains: new Set(["space_program"]),
      capacity: {}, megasDone: new Set() });
    if (gate.met) { const b = beginMega(s.megas, megaprojects.orbital_solar_array, s.week);
      if (b.ok) { s.cashM -= b.cost; megaBegun = true; } }
  }
  for (const nid of CHAIN) {
    const st = s.research.nodes[nid].state as string;
    const prereqsDone = researchNodes[nid].prereqs.every(p => (s.research.nodes[p].state as string) === "complete");
    if ((st === "available" || st === "locked") && prereqsDone)
      s.research.nodes[nid].state = "in_progress";
  }
  const rep = advanceTurn(s, content, r);
  // policy: when the market refreshes, keep the contract book alive (like a real player)
  if (rep.marketRefreshed && s.contracts.active.length < 4) {
    const eligible = s.contracts.market.map(id => content.contractTemplates[id])
      .filter(t => !t.requires.clearance || s.contracts.clearances.includes(t.requires.clearance));
    // government-leaning identity: prefer gov deals when available
    const next = eligible.find(t => content.customers[t.customer].channel === "government") ?? eligible[0];
    if (next) takeContract(s.contracts, next);
  }
  if (Object.keys(s.subEcon.instances).length && !subOpened) subOpened = true;
  if (s.activeSynergies.some(a => a.id === "abundant_clean_energy")) synergyLive = true;
  if (rep.powerEventFired) powerEventCount++;
  crisisCount += rep.subEconomyCrises.filter(x => x.event).length;
  rivalNewsCount += rep.rivalNews.length;
  if (rep.worldNews) worldNewsCount++;
  rivalLegacyClaims += rep.legaciesLostToRivals.length;
  rivalCompletions += rep.rivalNews.filter(n => n.kind === "completion").length;
  for (const n of rep.rivalNews) reactKinds.add(n.kind);
}

ok("campaign: REAL frontier chain completed", (s.research.nodes["space_solar_power"].state as string) === "complete");
ok("campaign: megaproject begun + completed", megaBegun && (s.megas.builds["orbital_solar_array"] ?? 0) >= 1);
ok("campaign: sub-economy opened on completion", subOpened && !!s.subEcon.instances["space_power"]);
ok("campaign: sub-economy grew + fills the pool", (s.subEcon.instances["space_power"]?.scale ?? 0) > 200
  && (s.subEcon.resource_pool["clean_energy"] ?? 0) > 0,
  `scale=${s.subEcon.instances["space_power"]?.scale.toFixed(0)}, energy=${s.subEcon.resource_pool["clean_energy"]?.toFixed(1)}`);
ok("campaign: flow synergy activated from real content", synergyLive, "abundant_clean_energy live");
ok("campaign: contracts paid recurring revenue", s.cashM > 0, `cash=$${s.cashM.toFixed(0)}M`);
ok("campaign: power accumulated (mega + contracts + scale)", s.powerAxis.power >= 3, `power=${s.powerAxis.power}`);
const identity = mixIdentity(govShare(s.contracts, content.contractTemplates, content.customers));
ok("campaign: entanglement + identity tracked", s.contracts.entanglement > 0
  && ["Government Partner", "National Champion", "State-Entangled", "Independent"].includes(identity),
  `entangle=${s.contracts.entanglement.toFixed(0)}, identity=${identity}, active=${s.contracts.active.length}`);
ok("campaign: power events fired from real content", powerEventCount >= 1, `${powerEventCount} fired`);
ok("campaign: sub-economy crises drawn from real pools", crisisCount >= 0, `${crisisCount} crises`);
ok("living world: rival news flows every era", rivalNewsCount >= 20, `${rivalNewsCount} beats over 800wk`);
ok("living world: rivals complete megaprojects", rivalCompletions >= 1, `${rivalCompletions} rival megas built`);
ok("living world: rivals claim legacies FIRST (the race is real)", rivalLegacyClaims >= 1,
  `${rivalLegacyClaims} legacies lost: ${Object.entries(s.claimedLegacies).filter(([,o]) => o !== "player").map(([l,o]) => `${l}→${o}`).slice(0,3).join(", ")}`);
ok("living world: the player's own claim still lands", (s.claimedLegacies["powered_the_world"] ?? "") === "player",
  `powered_the_world → ${s.claimedLegacies["powered_the_world"]}`);
ok("living world: world news fires", worldNewsCount >= 3, `${worldNewsCount} world beats`);
ok("reactivity: a rival SURGED while racing you", reactKinds.has("surge"), [...reactKinds].join(","));
ok("reactivity: a beaten rival reacted in character", reactKinds.has("beaten") || reactKinds.has("second_place"),
  `kinds seen: ${[...reactKinds].sort().join(", ")}`);
ok("reactivity: fury is persistent (aggression_bonus accrues)",
  s.rivals.some(rv => rv.aggression_bonus > 0), `bonuses: ${s.rivals.map(rv => rv.aggression_bonus.toFixed(2)).join("/")}`);
// determinism: run the identical campaign again
console.log(`\n=== ${pass} passed, ${fail} failed ===`);
