# Moonshot Inc — Megaprojects: Design & Authoring Spec

*The civilizational endgame tier. This doc is written to be understood by someone seeing the concept for the first time: it explains **what megaprojects are**, **why they exist**, **how they work mechanically**, and **exactly what to author**. It is the payoff the R&D tree (`09`) points at and the concrete form of the sovereign era (`08`). Conventions: `$M`, weeks, snake_case ids, drop-in TOML, content/code boundary.*

---

## Part 1 — What a megaproject IS (read this first)

A **megaproject** is the single biggest thing a company can undertake in Moonshot. It is not a product you sell and not a research node you complete — it is a **multi-year, staged, can-fail endeavor that, when finished, changes the game and the world.** Mars Colony. Artificial General Intelligence. An orbital ring around the Earth. Asteroid mining. These are the things a startup literally cannot attempt and a titan builds to cement its place in history.

**The mental model:** if a *product* is "a thing you make and sell," and a *research project* is "a capability you unlock," a **megaproject is "a wonder you build."** Closest analogy: the wonders in a Civilization game, or the late-game habs/colonies in Terra Invicta — enormous, prestigious, staged builds that reshape what's possible and announce that you are now a different kind of player.

**Three things make a megaproject different from everything else in the game:**

1. **It is gated behind a *convergence*, not a single requirement.** You can't buy your way in, or research your way in, or scale your way in — you need *all of it at once*: deep research (the frontier programs from `09`), enormous capital, high stature, the right executive, sufficient capacity, and often a *prerequisite megaproject*. This convergence is why only a titan can attempt one — it's the intersection of every system in the game.

2. **It runs in *stages* over years, with real failure risk.** A megaproject isn't one payment that completes on a timer. It's a sequence of phases (e.g. Mars: first landing → outpost → settlement → self-sufficiency), each taking quarters or years, each with a chance of setback, each a narrative milestone. You commit, you sustain it, you sweat it, and each stage that lands is an *earned moment* (the celebration template from the design).

3. **Completion is *world-altering*, not just a bonus.** Finishing a megaproject doesn't grant "+10% revenue." It opens a **new sub-economy** (Mars produces and consumes things; asteroid mining feeds materials back to your fabs), permanently shifts your capabilities, fires a large **power** jump (you are now civilization-critical — `08` §4), unlocks further megaprojects, and is recorded as an optional **legacy victory** (`08` §10). It changes the board.

---

## Part 2 — Why megaprojects exist (the purpose)

They solve the core problem the whole late-game redesign is about. Stated plainly:

- **They give the trivial late-game money something enormous to do.** By the late game, money is easy (`08` — money's role inverts by design). Megaprojects are the giant, meaningful capital sinks that keep "what do I spend on" a real decision when cash stops being scarce. Without them, a rich late game is hollow.
- **They are the destination that makes a long playthrough worth playing.** A business sim that ends at "you're rich" is short. "You're building a colony on Mars / you've achieved AGI / you've become a power the government must answer to" is a *reason to keep going for hours*. Megaprojects are the north star the player steers toward from early game (the positioning in `08` §1).
- **They are how "more powerful than the government" actually happens.** A megaproject makes you strategically essential to humanity — that's the mechanism that converts business dominance into geopolitical power. You don't pick a "power path"; you build things so important that power accrues to you (`08` §0, §4).
- **They are the payoff that makes deep R&D worth it.** The frontier programs in `09` exist *to gate these*. Without megaprojects, the top of the research tree has nothing to unlock. Megaprojects are the reason to climb.
- **They make spanning fronts matter.** The biggest megaprojects need *two fronts at once* (Mars needs launch + space-habitation; AGI needs the lab + chips). This is what rewards becoming a diversified titan rather than a single-product company (`08` §8 synergy).

**The design rule that keeps them from being "just a very expensive button":** every megaproject must be a *strategic commitment with risk and consequence*, gated by a convergence no small firm can meet, staged so it's a journey not a purchase, and world-changing on completion. If any of those is missing, it's just a big product — and the late game goes hollow.

---

## Part 3 — How a megaproject works (the mechanics the engine implements)

This defines the behavior so the authoring fields make sense. (Engine is mine to build; this is the contract.)

### 3.1 Availability — the convergence gate
A megaproject becomes *available to start* only when **all** of its requirements are simultaneously met:
- **`research`** — specific frontier program(s) from `09` completed (the `megaproject_unlock` hooks already point here). Often **two**, across **two fronts** (the cross-front gate).
- **`stature_min`** — market-cap stature (`08` §2) at or above a threshold (these are titan-tier: tens of billions).
- **`capital_min`** — you must have a war chest on hand to even begin (not just the total cost — proof you can sustain it).
- **`exec_required`** — a dedicated executive of a relevant domain assigned (`08` §3) — a megaproject needs someone to run it.
- **`capacity`** *(optional)* — some require a capacity type/level (`07`) — e.g. launch slots, fab lines.
- **`prerequisite_megaprojects`** — some require an earlier mega done first (no Mars Colony without the Mars Transit Line; no O'Neill Cylinder without large-scale habitation experience). This makes megaprojects their own **tech-tree of ambition.**

### 3.2 Stages — the staged build
A megaproject is a list of **stages**, run in order. Each stage has:
- a **cost** (`$M`) and **duration** (`weeks`) — paid/elapsed while the stage runs;
- a **failure/setback risk** (a probability, resolved by seeded RNG) — on a setback, the stage extends and costs more (a *delay*, not a total loss — see 3.4);
- a **milestone payoff** — a narrative beat + often a partial benefit (the outpost earns a little before the colony is done);
- it **occupies a megaproject slot** the whole time (3.5).

Stages are sequential: you commit to the megaproject, fund stage 1, it resolves, you continue to stage 2, etc. You can **pause** between stages (stop sinking money) but the slot stays occupied until you finish or abandon. Each completed stage is an **earned moment**.

### 3.3 Completion — the world-altering payoff
When the final stage completes, the megaproject's `on_complete` fires:
- **`power`** — a large bump to the power/influence meter (`08` §4). The biggest megaprojects are the biggest single power sources in the game.
- **`sub_economy`** — opens a new ongoing economic system (Mars colony produces/consumes; asteroid mining yields a material stream that feeds your fabs/launch). Authored as a named sub-economy the engine instantiates.
- **`synergies`** — permanent cross-front bonuses (`08` §8) — e.g. asteroid mining lowers chip material costs.
- **`capability`** — permanent named modifiers (like research unlocks).
- **`unlocks_megaprojects`** — gates the next tier of ambition.
- **`legacy_victory`** — records an optional victory (`08` §10); the game continues.
- **`narrative`** — the big closing beat (text; the earned-moment template).

### 3.4 Failure & risk (so commitment has weight)
Megaprojects **don't hard-fail to zero** (losing a 150-week, $900M endeavor to one bad roll would feel terrible). Instead:
- Each stage can hit a **setback**: it extends (more weeks) and overruns (more `$M`) — a *cost/schedule blowout*, the realistic failure mode of giant projects.
- **`risk_profile`** per megaproject scales how often/how badly setbacks hit (AGI and bleeding-edge megas are riskier than a second space station).
- The player can **abandon** a megaproject mid-build (recovering nothing spent) — a real strategic loss, but their choice, never the dice's alone.
- Some megaprojects have a **`catastrophe`** tail on the riskiest stages (rare, large setback + a narrative/reputation/power hit) — reserved for the truly bleeding-edge (AGI alignment failure, a colony disaster). Authored explicitly, opt-in per megaproject; off by default.

### 3.5 Slots & concurrency
You can run only **N megaprojects at once** (`max_concurrent_megaprojects`, low — 1 to start, raised by stature and certain completions). Even with infinite money, attention is scarce — you can't build Mars *and* AGI *and* an orbital ring simultaneously early on. This is the late-game equivalent of the research-slot and bet-concurrency scarcity: **the constraint is choice, not cash.**

---

## Part 4 — The schema (what you author)

**Drop-in path:** `content/megaprojects/<id>.toml` (one file per megaproject, like a company file) **or** grouped `content/megaprojects/<branch>.toml`. Tuning: `content/megaprojects/_tuning.toml`.

```toml
# content/megaprojects/mars_colony.toml
[mars_colony]
id = "mars_colony"
name = "Mars Colony"
branch = "space"                 # space | intelligence | energy | economic (for UI grouping)
tagline = "A permanent, self-sustaining human settlement on Mars."
description = """The defining endeavor of the century. Not a flag and a footprint — \
a city that feeds itself, makes its own air and water, and grows without Earth. \
Getting people there is one problem; keeping them alive there forever is another, \
and you intend to solve both. The company that settles Mars is no longer a company. \
It is a power in its own right, and the first the species has seen that answers to \
no nation."""
icon = "planet"

# ---- AVAILABILITY: the convergence gate (ALL must be met to START) ----
[mars_colony.requires]
research = ["interplanetary_transport", "closed_loop_habitation"]   # TWO frontier programs, TWO fronts
fronts = ["launch_services", "space_stations"]                       # must operate both
stature_min = 35000              # $35B — titan-tier
capital_min = 1500               # $M war chest on hand to begin
exec_required = "space_program"  # a dedicated exec domain assigned (08 §3)
prerequisite_megaprojects = ["mars_transit_line"]   # must have built the transit line first
capacity = { launch_capacity = 12 }                  # optional: needs launch throughput (07)

# ---- STAGES: the staged, can-fail build (sequential) ----
[[mars_colony.stages]]
name = "First landing"
description = "Crewed landing and the first permanent surface foothold."
cost = 600
weeks = 90
setback_chance = 0.25            # per-stage probability of a cost/schedule blowout
milestone = "Humanity's first permanent presence on another planet. The world stops to watch."
partial_benefit = { power = 1 }  # a taste of the payoff before completion

[[mars_colony.stages]]
name = "Outpost"
description = "A working base — power, life support, the first industry."
cost = 900
weeks = 120
setback_chance = 0.3
milestone = "The outpost is self-running. Tenants and agencies start paying for a seat."
partial_benefit = { sub_economy_preview = "mars_outpost" }

[[mars_colony.stages]]
name = "Settlement"
description = "Hundreds of residents, local manufacturing, the beginnings of an economy."
cost = 1400
weeks = 160
setback_chance = 0.3
catastrophe = { chance = 0.05, narrative = "A habitat breach costs lives and dominates every headline on Earth.", power = -1, reputation_hit = true }

[[mars_colony.stages]]
name = "Self-sufficiency"
description = "The colony no longer needs Earth. It grows on its own."
cost = 2000
weeks = 200
setback_chance = 0.25

# ---- COMPLETION: the world-altering payoff ----
[mars_colony.on_complete]
power = 4                        # one of the largest single power jumps in the game
sub_economy = "mars_colony"      # opens an ongoing Mars sub-economy (engine instantiates)
synergies = ["off_world_resources", "mars_manufacturing"]   # permanent cross-front bonuses
capability = { multiplanetary = 1.0 }
unlocks_megaprojects = ["oneill_cylinder"]                   # next tier of ambition
legacy_victory = "first_on_mars"
narrative = """They said it couldn't be done in a lifetime. You did it in a career. \
There are children on Mars now who will never see Earth, and they were born under \
your company's flag, not a nation's."""

# ---- RISK tuning for this megaproject ----
[mars_colony.risk_profile]
volatility = 1.0                 # multiplier on all stage setback_chances (1.0 = as authored)
```

### Field reference
- **`branch`** — for UI grouping and thematic gating (space / intelligence / energy / economic).
- **`requires`** — the convergence (§3.1). `research` ids must be real frontier programs from `09`. `fronts` ≥1 (≥2 for the cross-front megas). `prerequisite_megaprojects` build the ambition tech-tree.
- **`stages`** — ordered list (§3.2). Each: `cost`, `weeks`, `setback_chance` (0–1), `milestone` (narrative), optional `partial_benefit`, optional `catastrophe` (rare tail; opt-in).
- **`on_complete`** — the payoff (§3.3). `power`, `sub_economy`, `synergies`, `capability`, `unlocks_megaprojects`, `legacy_victory`, `narrative`.
- **`risk_profile.volatility`** — scales this mega's setback rates without editing each stage.

---

## Part 5 — `content/megaprojects/_tuning.toml`

```toml
# content/megaprojects/_tuning.toml
[global]
starting_megaproject_slots = 1   # how many megaprojects you can run at once at first
max_megaproject_slots = 3        # ceiling (raised by stature + certain completions)
# slot sources beyond starting: stature thresholds, and on_complete.unlocks that grant slots.

# Optional per-branch pacing multipliers (like the products/research _tuning pattern)
[space]
cost_mult = 1.0
time_mult = 1.0

[intelligence]
cost_mult = 1.0
time_mult = 0.9                  # software-ish megas move a bit faster

[energy]
cost_mult = 1.1
time_mult = 1.1

[economic]
cost_mult = 0.8                  # economic-dominance megas are cheaper but stature-gated harder
time_mult = 0.9
```

---

## Part 6 — The 11 megaprojects to author (the full set the R&D tree references)

These are the ids `09`'s frontier programs already point at via `megaproject_unlock`. Author all 11. Branch, the frontier program(s) that gate each, and the intended fantasy:

| id | branch | gated by (research) | the fantasy |
|---|---|---|---|
| `artificial_general_intelligence` | intelligence | `artificial_general_intelligence` (lab) **+** `neuromorphic_substrate` (chips, via `agi_capable_hardware`) | The two-pillar marquee. Build a mind. Reshapes the game + huge power. |
| `mars_colony` | space | `interplanetary_transport` (launch) **+** `closed_loop_habitation` (space) | The two-pillar space marquee. Settle Mars. Multiplanetary + huge power. |
| `mars_transit_line` | space | `interplanetary_transport` (launch) | Routine Earth–Mars transport. **Prerequisite for `mars_colony`.** |
| `asteroid_mining_operation` | space/energy | `orbital_industrial_base` (satellites) | Mine the asteroids. Opens a **materials sub-economy** that feeds your fabs/launch (synergy). |
| `orbital_solar_array` | energy | `space_solar_power` (satellites) | Beam clean power to Earth from orbit. Energy dominance; strategic importance. |
| `oneill_cylinder` | space | `artificial_gravity_habitat` (space) | A rotating space city for millions. **Requires `mars_colony` or large-habitat experience.** The capstone habitat. |
| `orbital_ring` | space | `space_elevator_tether` (launch) | A ring around Earth — near-free access to space. Infrastructure that rewrites the launch economy. |
| `quantum_supremacy_platform` | intelligence | `quantum_accelerator` (chips) | Quantum compute at scale. Breaks cryptography/materials/optimization; strategic + power. |
| `accelerated_science_program` | intelligence | `superhuman_science` (lab) | An AI-driven discovery engine that compounds ALL your research. A force-multiplier mega. |
| `sector_dominance_platform` | economic | `industry_operating_system` (saas) | Become the OS an entire industry runs on. Power through economic indispensability, not space. |
| `autonomous_economy_platform` | economic | `autonomous_enterprise` (saas) | Software that runs whole companies. Reshapes the economy; quiet but enormous power. |

**Worked second example — Artificial General Intelligence (the intelligence marquee, two-pillar):**
```toml
[artificial_general_intelligence]
id = "artificial_general_intelligence"
name = "Artificial General Intelligence"
branch = "intelligence"
tagline = "A machine mind with human-level generality — and beyond."
description = """The threshold the whole field has been racing toward. A system that \
can learn anything a person can and then exceed it, across every domain at once. It \
cannot be done on software alone — it needs a computing substrate no ordinary fab \
can make. Finish it and every other endeavor you run accelerates, the economy \
reorganizes around what you've built, and you hold something governments will both \
court and fear."""
icon = "sparkles"

[artificial_general_intelligence.requires]
research = ["artificial_general_intelligence", "neuromorphic_substrate"]  # lab + chips
fronts = ["frontier_model_lab", "ai_chips"]
stature_min = 40000              # the highest stature gate — $40B
capital_min = 2000
exec_required = "chief_scientist"
prerequisite_megaprojects = []
capacity = { compute = 30 }      # needs a vast compute base (07)

[[artificial_general_intelligence.stages]]
name = "Proto-AGI"
description = "A system that generalizes across domains it was never trained on."
cost = 1200
weeks = 110
setback_chance = 0.35

[[artificial_general_intelligence.stages]]
name = "General capability"
description = "Human-level across the board. The world realizes what you have."
cost = 1800
weeks = 150
setback_chance = 0.35
catastrophe = { chance = 0.06, narrative = "An alignment scare goes public. Regulators and the press descend.", power = -1, reputation_hit = true }

[[artificial_general_intelligence.stages]]
name = "Superintelligence threshold"
description = "The system improves itself faster than any team could. You are steering history."
cost = 2600
weeks = 180
setback_chance = 0.3
catastrophe = { chance = 0.08, narrative = "A capability the system developed on its own forces a global reckoning about who controls it.", power = -2, reputation_hit = true }

[artificial_general_intelligence.on_complete]
power = 5                        # the single largest power source in the game
sub_economy = "agi_services"
synergies = ["agi_accelerates_all_rd", "agi_runs_divisions"]
capability = { agi = 1.0 }
unlocks_megaprojects = ["autonomous_economy_platform"]
legacy_victory = "achieved_agi"
narrative = """You built a mind. Not a product, not a feature — a mind. The questions \
that follow are no longer about markets. They are about what you do with the most \
important thing any company has ever made, and whether the world will let you keep it."""

[artificial_general_intelligence.risk_profile]
volatility = 1.3                 # the riskiest endeavor in the game
```

---

## Part 7 — Validation checklist (engine enforces; mirror in loader)

- [ ] Every `requires.research` id is a real **frontier** program in `09` (and the frontier program's `megaproject_unlock` points back at this id — bidirectional check).
- [ ] Every `requires.fronts` is a real sub-industry; ≥2 for the cross-front megas (AGI, Mars).
- [ ] Every `prerequisite_megaprojects` id resolves to another megaproject; the prerequisite graph is **acyclic**.
- [ ] Every `unlocks_megaprojects` id resolves.
- [ ] Every `on_complete.synergies` / `capability` tag is engine-known (or warns).
- [ ] `requires.capacity` keys are real capacity types in the relevant front (`07`).
- [ ] `exec_required` is a real exec domain (`08` §3) — will fully validate once execs are authored; warn until then.
- [ ] Stages: ≥2 per megaproject; each has `cost`, `weeks`, `setback_chance` in [0,1].
- [ ] `_tuning.toml` present with global + per-branch blocks.
- [ ] All 11 referenced ids exist (clears the `09` dangling-reference warnings for megaprojects).

> Like `09`, some `on_complete` hooks (`sub_economy`, `synergies`, `exec_required`) reference systems authored/built later (`08` blocks). The loader treats unknown ids as `ContentDB.warnings`, not hard failures — author the megaprojects now; the hooks resolve as those systems land.

---

## Part 8 — What I (Claude) build — not authoring

- The megaproject engine: the convergence-gate availability check, the staged runner (cost/weeks/slot occupation), setback/catastrophe resolution via seeded RNG, pause/abandon, `on_complete` application.
- Megaproject slots (start + stature + completion grants), concurrency enforcement.
- The sub-economy framework that `on_complete.sub_economy` instantiates (the new ongoing economic systems — Mars, asteroid materials, AGI services).
- The power-meter integration (`08` §4) the `power` fields feed.
- The Megaprojects UI surface (the ambition tech-tree, active endeavors with stage progress, the earned-moment milestone beats) in the `UI_LANGUAGE.md` language.
- Loader + the Part 7 validation (including the bidirectional research↔megaproject check) pushing to `ContentDB.warnings`.

---

## Part 9 — Suggested authoring order

1. **`_tuning.toml`** — slots + branch pacing first (frames cost/time scale).
2. **`mars_transit_line`** then **`mars_colony`** — the prerequisite chain + the flagship two-pillar space mega. (Transit line is simpler; do it first, then the colony that requires it.)
3. **`artificial_general_intelligence`** — the intelligence marquee, two-pillar, the worked example above is most of the way there.
4. **The single-gate megas** — `asteroid_mining_operation`, `orbital_solar_array`, `quantum_supremacy_platform`, `accelerated_science_program`, `sector_dominance_platform`, `autonomous_economy_platform` (each gated by one frontier program; straightforward once the pattern's set).
5. **`oneill_cylinder`** and **`orbital_ring`** last — the capstones (O'Neill requires Mars or large-habitat experience; the ring is pure infrastructure).

Per megaproject: a characterful description + tagline, the convergence `requires`, 2–4 staged `stages` with rising cost/weeks and sensible setback risk, a world-altering `on_complete`, and a `risk_profile`. Give each a closing `narrative` worthy of the moment — these are the biggest beats in the game.

**The feel to aim for:** a newcomer reading one of your megaproject files should immediately understand *what civilizational thing this is, why only a titan could build it, what the journey of building it feels like, and how the world changes when it's done.* That's the whole point of the tier.
