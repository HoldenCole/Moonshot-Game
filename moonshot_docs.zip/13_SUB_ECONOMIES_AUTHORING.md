# Moonshot Inc — Sub-Economies: Design & Authoring Spec

*What a megaproject opens when it completes. Written to be understood fresh: what a sub-economy is, why it exists, how it runs (mostly on its own — this is not eleven SimCities to babysit), and what to author. These are the `on_complete.sub_economy` ids the megaprojects (`10`) reference. Conventions: `$M`, weeks, snake_case, content/code boundary.*

---

## Part 1 — What a sub-economy IS

When you finish a megaproject, it doesn't just hand you a power bump and end. It **opens a new ongoing economic system** — a living thing on your board that produces, consumes, grows over time, and feeds your other businesses. Settle Mars and you don't get "+4 power and done"; you get a **Mars colony** that has a population, produces resources and revenue, consumes supplies, grows year over year, and sends materials back to feed your fabs and your launch business.

A **sub-economy** is that ongoing system. It's the difference between a megaproject being a *trophy* and being a *new frontier you now operate.*

**The mental model:** a sub-economy is a small, mostly-autonomous engine with a few inputs and outputs that ticks every turn after its megaproject completes. It is **not** a new full company you micromanage — it's a *lightly-steered* system that mostly runs itself (through your executives), grows on its own, throws off revenue and resources, and occasionally surfaces a decision or event. You're an owner watching a frontier flourish, not a foreman.

**Three things a sub-economy does:**
1. **Produces** — revenue (`$M/yr`), and/or **resources** (named outputs like materials, energy, compute, data) that feed back into your core business.
2. **Consumes** — inputs (capital upkeep, supplies, sometimes resources from elsewhere in your empire) to keep running.
3. **Grows** — a scale/population/throughput value that climbs over time (faster if you invest), increasing what it produces.

The outputs are where sub-economies connect to everything else: a sub-economy's resource output is what **synergies** (`13`, next doc) read — asteroid mining's `materials` output is what makes your chips cheaper. So sub-economies are the *source* of the synergy web.

---

## Part 2 — Why sub-economies exist (the purpose)

- **They make megaproject completion world-changing, not a one-off.** This is the core job. A megaproject's payoff is *an ongoing new system*, so the late game keeps growing in scope — you don't "finish" content, you *accumulate frontiers you operate.*
- **They are the source of the synergy web.** Sub-economies produce the resources that make your other fronts stronger (`08` §8, `13`). Without them, "vertical integration as a superpower" has nothing concrete flowing through it. Asteroid materials → cheaper chips is a sub-economy output feeding a synergy.
- **They give the trivial late-game money somewhere to keep flowing — and a reason to keep optimizing.** Even when cash is easy, a growing Mars colony or AGI services business is a compounding asset you can invest in to grow faster. The late game stays an *allocation* game.
- **They make "more powerful than the government" tangible.** A sub-economy is the *mechanism* of strategic importance: you don't just have power as a number, you literally *run the power grid* (orbital solar), *own the materials supply* (asteroids), *operate the intelligence everyone depends on* (AGI services). Power is concrete — it's the systems you operate that civilization needs.
- **They're a new texture for the endgame.** Each sub-economy has its own flavor, events, and rhythm — a Mars colony's crises are different from AGI services' regulatory pressure. They keep the late game from being one note.

**Design rule — autonomous, not micromanaged:** a sub-economy must run *mostly on its own.* The player sets a high-level posture (grow vs. harvest), the relevant exec runs it, and it surfaces only occasional decisions/events. If a sub-economy demands per-turn babysitting, it's wrong — the late game is about steering an empire, not managing eleven colonies by hand. **Lightly steered, mostly autonomous, occasionally consequential.**

---

## Part 3 — How a sub-economy works (the mechanics)

### 3.1 The tick
After its megaproject completes, a sub-economy is instantiated and ticks each turn:
```
each turn:
  scale grows toward scale_cap at growth_rate (faster if invested, slower if harvested)
  produces: revenue = scale * revenue_per_scale
            resources = { resource_id: scale * yield_per_scale, ... }
  consumes: upkeep = scale * upkeep_per_scale  (+ any input resources)
  net contribution flows into your finances + the resource pool (read by synergies)
```
It's a small autonomous engine: scale drives output, output minus upkeep is the net, resources flow to the pool.

### 3.2 Scale & growth (the one thing the player steers)
Each sub-economy has a **scale** (population for a colony, throughput for a mine, capacity for AGI services) that **grows over time toward a cap.** The player's single steering lever is a **posture**:
- **`grow`** — reinvest output into faster scale growth (less net revenue now, bigger engine later).
- **`harvest`** — take the revenue now, slower growth.
- **`balanced`** — default.

The relevant **executive runs it** within that posture (a good `space_program` lead grows the colony faster / handles setbacks better). So the player picks posture + trusts the exec — that's the light-touch steering. Investing capital can also raise the `scale_cap` or growth (an optional money sink — good for the trivial-money late game).

### 3.3 Outputs: revenue + resources
- **Revenue** flows into your normal finances (just another income stream, scaled by the sub-economy's size).
- **Resources** are named outputs (`materials`, `clean_energy`, `compute`, `data`, `research_speed`) that flow into a **resource pool** the rest of the game reads — primarily the **synergy system** (`13`), but also some can offset costs directly (clean energy lowers operating costs). Resources are *how a sub-economy makes your empire stronger*, not just richer.

### 3.4 Inputs & dependencies
Some sub-economies **consume** to run: capital upkeep always; some need resources from *elsewhere in your empire* (a Mars colony consumes launch capacity / supplies; an orbital city consumes energy). This creates **inter-sub-economy dependency** — your asteroid materials feed your orbital construction feeds your colony — the empire as an interlocking machine. (Authored as input requirements; the engine routes them.)

### 3.5 Events & crises
Each sub-economy has a small pool of **flavor events and occasional crises** (a Mars dust storm, an AGI-services outage, a regulatory probe of your power monopoly) — using the existing events system, scoped to that sub-economy. These are the "occasionally consequential" texture. Mostly light; a few are real decisions. Keeps each frontier alive and distinct.

### 3.6 Power & strategic importance
A sub-economy's *scale* feeds your **power/strategic-importance** (`08` §4) on an ongoing basis — a small Mars outpost matters less than a self-sufficient million-person colony. So power isn't just the one-time megaproject completion bump; it *grows as the sub-economy grows.* The bigger the civilization-critical thing you operate, the more powerful you are.

---

## Part 4 — What you author

**Drop-in path:** `content/sub_economies/<id>.toml` (one per sub-economy) or grouped `content/sub_economies/<branch>.toml`. Tuning in `_tuning.toml`.

```toml
# content/sub_economies/mars_colony.toml
[mars_colony]
id = "mars_colony"
name = "Mars Colony"
opened_by = "mars_colony"        # the megaproject (10) whose on_complete opens this
branch = "space"
scale_label = "residents"        # what 'scale' represents (residents / throughput / capacity)
description = """A permanent, growing settlement — residents, industry, and an \
economy of its own. It produces rare off-world materials and a stream of revenue, \
consumes supplies shipped from Earth until it's self-sufficient, and its very \
existence makes you a power no government can ignore. It grows on its own; you \
decide how hard to push it."""
icon = "planet"

# ---- SCALE & GROWTH ----
[mars_colony.scale]
starting_scale = 100             # residents at completion
scale_cap = 100000               # the ceiling (raised by investment / O'Neill etc.)
growth_rate = 0.04               # base fraction/turn toward cap (posture + exec modify)
exec_domain = "space_program"    # which exec runs it (08 §3 / 12)

# ---- OUTPUTS (per unit scale, per year) ----
[mars_colony.produces]
revenue_per_scale = 0.0008       # $M/yr per resident → 100k residents ≈ $80M/yr base, grows
[mars_colony.produces.resources]
off_world_materials = 0.0004     # feeds synergies (cheaper construction/chips)
mars_research = 0.0002           # unique research output

# ---- INPUTS (consumed to run) ----
[mars_colony.consumes]
upkeep_per_scale = 0.0003        # $M/yr per resident
[mars_colony.consumes.resources]
launch_capacity = 0.00005        # needs launch throughput until self-sufficient (eases with scale)

# ---- POWER ----
[mars_colony.power]
power_per_scale_tier = [ [1000, 1], [10000, 2], [50000, 3], [100000, 4] ]
# scale thresholds → cumulative power. A growing colony = growing power.

# ---- EVENTS ----
[mars_colony.events]
pool = "mars_colony_events"      # an events table (existing events system), scoped here
crisis_chance = 0.04             # per-turn chance of surfacing a crisis decision

# ---- FEEDS (which synergies this sub-economy's resources enable — 13) ----
[mars_colony.feeds_synergies]
off_world_materials = ["cheap_construction", "off_world_resources"]
mars_research = ["unique_research"]
```

### Field reference
- **`opened_by`** — the megaproject id whose `on_complete.sub_economy` opens this (must match `10`).
- **`scale`** — `starting_scale`, `scale_cap`, `growth_rate`, and the `exec_domain` that runs it. The player steers via posture; the exec executes.
- **`produces`** — `revenue_per_scale` (→ finances) and a `resources` table (→ the resource pool / synergies).
- **`consumes`** — `upkeep_per_scale` (capital) and optional input `resources` (inter-sub dependency).
- **`power`** — scale thresholds → cumulative power (ongoing strategic importance, `08` §4).
- **`events`** — a scoped events pool + crisis chance.
- **`feeds_synergies`** — which `13` synergies each resource output enables (forward hook to the synergy doc).

---

## Part 5 — `content/sub_economies/_tuning.toml`
```toml
[global]
default_posture = "balanced"     # grow | harvest | balanced
grow_growth_mult = 1.6           # posture multipliers on growth_rate
harvest_growth_mult = 0.5
harvest_revenue_mult = 1.4       # harvest trades growth for more current revenue
invest_to_raise_cap_cost = 50    # $M to raise a sub-economy's scale_cap a tier (money sink)

[branch_pacing]
space = 1.0                      # growth pace by branch (space slow, services fast)
intelligence = 1.4
energy = 1.0
economic = 1.5
```

---

## Part 6 — The 11 sub-economies to author

These are the `on_complete.sub_economy` ids from `10` (plus the `sub_economy_preview` ids that appear mid-build). Author all 11. Branch, the megaproject that opens each, and what it produces:

| id | opened by (`10`) | branch | scale = | produces |
|---|---|---|---|---|
| `mars_logistics` | mars_transit_line | space | transit throughput | revenue + cislunar logistics capacity |
| `mars_colony` | mars_colony | space | residents | revenue + off-world materials + mars research |
| `asteroid_materials` | asteroid_mining_operation | space | mining throughput | revenue + **raw materials** (feeds fabs/launch — key synergy source) |
| `space_power` | orbital_solar_array | energy | grid capacity | revenue + **clean energy** (lowers everyone's opex) |
| `orbital_city` | oneill_cylinder | space | residents | revenue + materials + research (the biggest habitat) |
| `ring_access` | orbital_ring | space | access throughput | revenue + **near-free launch** (slashes all space costs) |
| `agi_services` | artificial_general_intelligence | intelligence | service capacity | huge revenue + **research_speed** (accelerates all R&D) + runs divisions |
| `quantum_services` | quantum_supremacy_platform | intelligence | qubit capacity | revenue + quantum advantage (materials/optimization) |
| `discovery_engine` | accelerated_science_program | intelligence | research capacity | **research_speed across all fronts** (a force-multiplier sub-economy) |
| `platform_tolls` | sector_dominance_platform | economic | platform volume | high-margin recurring revenue + economic lock-in |
| `autonomous_economy` | autonomous_economy_platform | economic | platform volume | massive revenue + economic substrate (the biggest economic engine) |

**Note on the `sub_economy_preview` ids** in `10`'s stages (`mars_outpost`, etc.): these are *previews* — a partial sub-economy that comes online before the megaproject fully completes. Author them as either (a) a smaller starting state of the same sub-economy, or (b) skip and treat preview as just-narrative. Simplest: treat `sub_economy_preview` as "this sub-economy begins at its `starting_scale` early, at reduced output" — no separate file needed. Document which you choose.

**Worked second example — `asteroid_materials` (the key synergy-source):**
```toml
[asteroid_materials]
id = "asteroid_materials"
name = "Asteroid Materials Operation"
opened_by = "asteroid_mining_operation"
branch = "space"
scale_label = "extraction throughput"
description = """A standing fleet working the belt, returning a steady stream of \
metals and volatiles. Its revenue is real, but its true value is the materials it \
sends home — feeding your fabs and your launch program with resources that no \
Earth-bound rival can match the cost of. The supply line to the sky."""
icon = "gem"

[asteroid_materials.scale]
starting_scale = 50
scale_cap = 5000
growth_rate = 0.05
exec_domain = "space_program"

[asteroid_materials.produces]
revenue_per_scale = 0.012
[asteroid_materials.produces.resources]
raw_materials = 0.02             # the big one — feeds chips + launch + construction synergies

[asteroid_materials.consumes]
upkeep_per_scale = 0.004

[asteroid_materials.power]
power_per_scale_tier = [ [1000, 1], [3000, 2], [5000, 3] ]

[asteroid_materials.events]
pool = "asteroid_events"
crisis_chance = 0.05

[asteroid_materials.feeds_synergies]
raw_materials = ["cheap_raw_materials", "cheap_construction", "off_world_resources"]
```

---

## Part 7 — Validation checklist

- [ ] Every sub-economy's `opened_by` is a real megaproject (`10`), and that megaproject's `on_complete.sub_economy` names this id (bidirectional).
- [ ] All 11 `on_complete.sub_economy` ids from `10` have a sub-economy authored (clears those warnings).
- [ ] Every `exec_domain` is a real exec domain (`12`).
- [ ] Every `consumes.resources` input is produced by *some* sub-economy or is a real core resource (capacity types from `07`) — no orphan inputs.
- [ ] Every `feeds_synergies` value will resolve once synergies (`13`) are authored (forward hook — warn until then).
- [ ] `scale_cap` > `starting_scale`; `growth_rate` in (0,1); power tiers ascending.
- [ ] `_tuning.toml` present with global + branch_pacing.

> Forward hooks: `feeds_synergies` references the synergy doc (`13`, next). The loader treats unresolved synergy ids as `ContentDB.warnings` until `13` is authored.

---

## Part 8 — What I (Claude) build — not authoring

- The sub-economy engine: instantiation on megaproject completion, the per-turn tick (scale growth, produce/consume, net to finances, resources to pool), posture steering, exec-run modifiers, invest-to-raise-cap.
- The resource pool that synergies (`13`) read.
- Inter-sub-economy input routing (one sub-economy consuming another's output).
- Ongoing power contribution from sub-economy scale (`08` §4).
- The scoped events/crisis hooks (existing events system).
- The Sub-Economies UI surface (each frontier's scale, output, posture, events) in the `UI_LANGUAGE.md` language.
- Loader + Part 7 validation (incl. bidirectional megaproject↔sub-economy check) → `ContentDB.warnings`.

---

## Part 9 — Suggested authoring order

1. **`_tuning.toml`** — posture multipliers + branch pacing first.
2. **`asteroid_materials`** and **`space_power`** — the two clearest resource-feeders (materials, energy), since they make the synergy connection concrete and you'll reference their outputs in `13`.
3. **`mars_logistics` → `mars_colony` → `orbital_city`** — the space-habitation chain (and decide the `sub_economy_preview` handling here).
4. **`agi_services` / `discovery_engine` / `quantum_services`** — the intelligence trio (research-speed feeders).
5. **`platform_tolls` / `autonomous_economy`** — the economic engines.
6. **`ring_access`** — the launch-cost slasher.

The feel to aim for: completing a megaproject should make the player lean forward — *a new frontier just came online, and it's mine to grow.* A sub-economy is alive, it compounds, it feeds the rest of the empire, and it mostly runs itself while you decide how hard to push it. That's what turns the endgame from "I'm rich" into "I operate the systems civilization runs on."
