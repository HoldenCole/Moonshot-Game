# Moonshot Inc — Scale, Power & Megaprojects (North-Star Design)

*The late-game vision and the arc that leads to it. This is the destination the whole game builds toward — written first, so every earlier system has something to point at. Companion to the products/R&D/capacity work (`06`/`07`); this doc sits on top of it. Same conventions: `$M`, weeks, snake_case, pure/deterministic engine, content/code boundary, phased + shippable.*

> **The one-line frame:** It is a business simulator. You build products and a company and make money. But if you win hard enough, your company becomes so large and so strategically essential that it accumulates *power* — until it rivals and then eclipses the nation-state. Power is not a mode you pick; it is what *happens* to a company that becomes civilization-scale. Money is scarce early and trivial late — so the late game stops being "can I afford it?" and becomes "what do I deploy this torrent toward?": acquisitions, synergies, expansion, and megaprojects that reshape humanity.

---

## 0. The reframe (read this first)

The current build frames revenue/money as the point. That was right for the founder game and wrong for the whole game. The corrected framing:

- **Still a business sim at its core.** Products, company-building, money, growth — the spine, always. A player who only wants to get rich plays a complete, satisfying tycoon game and never has to think about "power."
- **Power is emergent, not elected.** Like Apple, Microsoft, ExxonMobil — they didn't choose to become geopolitically heavyweight; they got so big and so essential that they *became* it. A pure-profit player still accumulates power as a side effect of winning. A player who *wants* power can gear toward it deliberately. Same game, two playstyles, **no forced fork.**
- **Money's role inverts by design.** Scarce and front-and-center early (you can fail by running out); trivial and backgrounded late (the firehose is on). This is intentional. The late-game constraint is not money — it's *attention, strategic choice, research time, stature, project slots, political capital* — the scarce things money can't instantly buy. The job is not "make money hard again"; it's "give the player enough enormous, worthwhile things to spend the torrent on."
- **The destination:** founder counting pennies → titan dominating a sector → sovereign entity whose projects are essential to humanity and whose directors sit across the table from governments. The verbs change from *hire/ship/sell* to *acquire/integrate/expand/build-civilization*.

---

## 1. The four-phase arc (the spine)

One continuous progression. Crucially, **the endgame is positioned-for from the early game** — the R&D you choose, the projects you start, the fronts you expand into, the contracts you take are all seeds of the sovereign era. A player who never invested in research or strategic projects simply cannot reach Phase 4.

### Phase 1 — Founder
*Survive and find footing.* Money is scarce, dominant, knife-edge. Hands-on: you set R&D, approve hires, sweat payroll, ship your first products, raise your first rounds. **Headline concern: cash + product-market fit.** Seeds: your sub-industry and first R&D lines hint at the long arc.

### Phase 2 — Scale-up
*Become a real company.* Money loosens. You hire your first executives and delegate domains; multiple products; you begin expanding fronts and choosing **commercial vs. government contracts** (the first power seeds). **Headline concern: growth + building the machine.** Capability starts to matter alongside money.

### Phase 3 — Titan
*Dominate your sector.* Stature ramps (market-cap $10B+). The world reacts to *you* — press, rivals following your lead, talent flowing to you. Money is now easy; the game becomes **capital deployment**: acquisitions, synergy-building, expansion infrastructure (HQs, campuses, institutions), the first big undertakings. **Headline concern: where do I deploy capital, and how do I integrate my empire.** Power meter becomes visible and climbing.

### Phase 4 — Sovereign
*Eclipse the state.* Megaprojects (Mars, AGI, asteroid mining, fusion, ark ships) — civilizational endeavors that are strategically essential to humanity. The **power-vs-government axis** goes live: you lobby, then influence, then exceed — your space program outpaces the state's, your AI shapes policy, your directors work directly with (and above) governments. **Headline concern: civilizational ambition + power.** Reachable only by players who *positioned* across Phases 1–3.

**Design principle:** each phase should feel like a *different job*, not the same job with bigger numbers. The home screen, the dominant verbs, the scarce resource, and the world's treatment of you all change by phase (see §8 UI).

---

## 2. Stature — the ramp that drives the transformation

A single **stature** score, driven primarily by **market cap** (works private or public), secondarily by market dominance and strategic importance (§5/§6). Stature is the backbone that gates the scale systems and ramps their intensity.

- **< ~$10B:** minimal. You're a normal company; the world is mostly quiet about you.
- **$10B → up:** effects ramp **progressively** (not an on/off switch): press intensity rises, rivals begin reacting to you, the executive talent market opens (better execs will join a company of your stature), big undertakings unlock tier by tier, expansion options appear, and eventually regulators/antitrust circle.
- **Top:** you're the gravitational center of your sector and a geopolitical actor.

Stature is the clean variable that makes "becoming a giant" a *felt, gradual* transformation tied to a number you're already growing. It gates §3, §6, §7 and ramps §4's intensity.

---

## 3. Executives — a real management layer (help or hurt)

Not advisors who give recs you rubber-stamp. **Executives autonomously run their domain, and their competence + traits materially move the company — for better or worse.**

- **Each exec owns a domain and acts in it every turn.** CTO sets R&D allocation and product direction; CFO runs financing/treasury/earnings; COO runs ops/capacity; CRO runs go-to-market; later, a **Chief Strategy/Government Officer** runs contracts and influence. You set their mandate and guardrails; they execute; you live with the results and intervene on big calls or when someone's failing.
- **Competence has teeth.** A great CTO advances your tech faster and times bets well; a weak one wastes budget and ships duds. The *same company* performs differently based on who you hired — execs are a multiplier (or divisor) on their whole domain.
- **Traits create texture and risk.** Visionary (high-variance moonshots) vs. steady (compounds, never leaps); aggressive CFO (over-levers — great in booms, dangerous in busts) vs. cautious; a star CRO you underpay gets poached. Hiring is a strategic *character* choice.
- **It's a management game, not a toggle.** Recruit from a candidate market (quality/cost/personality vary with your stature), assign domains, compensate + retain (equity, comp, culture), fire underperformers (morale/severance fallout), survive defections, manage clashes between execs. A bad leadership team is a real way to *damage* the company — which is what makes a good one feel earned.
- **The executive fantasy, mechanically:** as you scale, your job becomes *assembling and steering a leadership team* rather than doing the work. This also dissolves the late-game "too many small clicks" problem — you delegate the weeds away. Founder does everything; titan picks great people and points them at the right problems.
- **The government interface (Phase 4):** at high stature, execs/directors begin working directly with the state — clearances, defense programs, advisory roles, political weight. An exec with government ties is a power asset (and a liability under scrutiny).

---

## 4. Power & Influence — the emergent meter

A **power/influence** meter that *rises as a consequence* of scale + strategic importance + government entanglement. It is never a mode you select; it fills as you win, and it gates/ramps the sovereign era. A pure-profit player watches it rise as a side effect; a power-gearing player optimizes for it.

**What raises power:**
- **Scale/stature** — sheer size makes you matter (the Apple/Microsoft effect).
- **Strategic importance** — products/projects the economy or state depends on (you supply the chips everyone needs; you run critical infrastructure).
- **Government entanglement** — taking government/defense contracts (§5).
- **Humanity-critical megaprojects** (§7) — a Mars colony or AGI makes you civilization-load-bearing; power jumps.
- **Influence spending** — once money is plentiful, buying influence directly (lobbying, initiatives, funding).

**What power unlocks (ramping):** lighter regulation or the muscle to resist it; favorable contracts; the ability to shape standards and policy; megaproject prerequisites; ultimately quasi-sovereign standing — governments negotiate with you as a peer, then a superior. "More powerful than the government" is the top of this meter, concretely: you can defy, co-opt, or outbuild the state.

**The counter-pressure (so power isn't free):** scrutiny, antitrust, regulatory events, public-trust risk, dependency obligations. Winning creates enemies — that's what makes power feel real rather than safe coasting.

---

## 5. Commercial vs. Government contracts — the converter

The core mechanic that turns business success into power. Revenue can come from two channels, and the *mix* is a strategic identity:

- **Commercial** — sell to the open market. Pure business: cleaner, more flexible, no entanglement, but no power kicker beyond scale.
- **Government / defense** — contracts that pay (often big, stable) **and entangle you with the state**: you become strategically important (+power), gain influence and inside access, but accept scrutiny, clearance requirements, obligations, political dependency, and reputational exposure. Defense/national-security work especially raises power and strategic-importance.
- As your projects become **humanity-critical**, strategic weight rises *regardless of channel* — at the top you're not a vendor, you're an entity the state cannot function without.

This is the connective tissue between "business sim" and "more powerful than government." It's a series of ordinary business decisions (which contracts, which projects) that *accrue* into geopolitical power.

---

## 6. The capital-deployment late game — *ways to spend* (the anti-hollow catalog)

Because money goes trivial, the late game lives or dies on having **enough enormous, meaningful things to spend on**, each a *strategic choice* (traded off against the others by attention, slots, stature gates, and time — you can't do everything at once even with infinite cash). The spend catalog:

- **Acquisitions / M&A** — buy rivals (kill competition, absorb products/tech/share), buy suppliers (vertical integration → synergy), buy into adjacent fronts (faster than building). A primary late-game verb. Carries antitrust risk at high stature.
- **Synergy buys** (§9) — deliberately acquire/build the pieces that make your *other* fronts cheaper/stronger (own chips for your AI; own launch for your space program). Spending to deepen the integration web.
- **Expansion infrastructure** — **headquarters, campuses, facilities, institutions.** A gleaming HQ tower; R&D campuses that boost research; global offices; a corporate university; a lobbying arm; a brand/PR machine. Part mechanical (permanent capability/prestige boosts), part *monument to scale* (your HQ is a flex). Giants build cathedrals to themselves; let the player too. **Tiered** so there's always a next buildout.
- **Megaprojects** (§7) — the civilizational endeavors; enormous capital sinks that also raise power.
- **Influence/power spending** (§4) — lobbying, political capital, funding initiatives.
- **Talent/exec wars** — enormous sums to poach the best people and fund research stars.
- **Power plays** — price wars you can afford and rivals can't, standard-setting, market-domination moves.

**Design principle:** every late-game money sink must be a *choice with a tradeoff*, not just a bigger button. Scarcity moves from money to choice. That is what preserves decision-making when cash stops being scarce.

---

## 7. The deepened R&D tree + Megaprojects (the foundational dependency)

**This is the first thing to build, because everything else gates on it.** Today R&D is ~3 lines per sub-industry. The endgame needs research that reaches from "better GPU" all the way to fusion / AGI / closed-loop life support / orbital industry, with **far more projects at every level.**

### 7.1 The research tree (extends `06`/`07`)
- Keep the existing per-sub-industry **R&D lines** as the base layer.
- Add **frontier programs** above the normal line levels: prestige thresholds that gate the big stuff. Borrowing Terra Invicta's **two-stage gate**: an *industry breakthrough* becomes available (anyone could pursue it), then **you** must independently develop the *private program* to actually get it — being first = dominance.
- Add **cross-domain research** that only matters once you span fronts (your chips + your AI unlock a joint capability) — research that *is* synergy.
- **Project slots:** you can only run N major programs at once; more slots unlock from your own infrastructure buildouts (HQ/campuses, §6). Borrowed straight from TI's "Skunkworks opens a slot."
- **Far more projects:** this is content work — the tree should have *many* nodes per era so research never runs dry and there's always a next thing to reach for. (See authoring, §11.)

### 7.2 Megaprojects (the civilizational tier)
A category *above* products. A product is something you sell; a **megaproject is something you build that changes the world (and the game).** Each:
- **Gated by a convergence** — high stature + deep research thresholds + war-chest capital + the right exec + often a *prerequisite megaproject* (no Mars colony without launch maturity + maybe a Moon foothold first). This creates a **tech-tree of civilizational ambition.**
- **A multi-phase committed endeavor** — years-long, staged, with milestones, setbacks, and real failure risk. Each milestone is an earned moment. Tiered cores (TI model): Outpost → Settlement → Colony, each stage a megaproject unlocking the next.
- **World-and-game-altering on completion** — opens a new sub-economy, new events, new synergies, permanent capability shifts, and a **power jump** (you're now humanity-critical). Not flavor — it changes the board.
- **Grounded 2050s + some sci-fi**, no robot/AI characters. The plausible tier (Mars, AGI, asteroid mining, fusion, orbital industry) is the core; the wilder tier (ark ships, interstellar) is the post-everything capstone.

**The branches:**
- **Space/physical:** mega space stations → Moon colony → asteroid mining (feeds materials back to your fabs/fuel) → Mars colony (marquee) → ark ships/interstellar (capstone).
- **Intelligence:** AGI (the frontier lab's ultimate program) — reshapes the game: accelerates all R&D, can run divisions semi-autonomously, raises power enormously, carries alignment-risk stakes.
- **Energy/industry:** fusion, orbital solar, closed-loop manufacturing — strategic-importance multipliers that power everything else.

**Worked example — Mars Colony:** requires launch maturity (your own heavy/human-rated vehicles or a Moon foothold), deep life-support + habitation research, a war chest, a dedicated exec, and high stature. Runs in stages (first landing → outpost → settlement → self-sufficiency), each a multi-year milestone with failure risk, each an earned moment. On meaningful progress: opens the Mars sub-economy, makes you civilization-critical (+power, governments must engage you), and unlocks further programs. A player chasing pure profit *can* build it (it's lucrative + prestigious); a power-gearing player builds it *for* the sovereignty jump.

---

## 8. Synergy — explicit integration across fronts (makes you a titan, not a conglomerate)

The connective tissue that rewards expanding across areas *as one company*. **Explicit, legible, mechanical** (your stated preference), modeled as a visible supply-chain/capability web:

- Own **chips** → your **AI** R&D is faster + cheaper.
- Own **launch** → your **space** megaprojects cost less.
- Own **asteroid mining** → your **fabs** get cheap materials.
- Build **AGI** → *every* R&D line accelerates; divisions can run semi-autonomously.
- Own **energy/fusion** → everything's operating costs drop.

A conglomerate runs separate businesses; **a titan runs businesses that multiply each other.** The synergy web is what makes vertical integration a superpower and the path to the sovereign era. Shown as an actual web/graph the player builds (see UI). Each synergy link is a concrete, named bonus — never vague.

---

## 9. UI architecture (structure now; mockups deferred)

The reframe (money as means, not score) and the new systems force a command-center rethink. **This section specifies structure only** — new tabs and how the home screen reframes and evolves by phase. Actual screen mockups come when we build each, in the established `UI_LANGUAGE.md` language (borderless, alive, no dead space).

**The home screen becomes a phase-evolving command center.** Its *purpose* changes with your era:
- **Phase 1:** operational — cash, runway, your 1–2 products, the hands-on decisions. Money front-and-center (correct for this phase).
- **Phase 3–4:** strategic overview — megaprojects in flight, divisions your execs run, your power/stature standing, the fronts you span, the synergy web, capital to deploy. Money demoted to a vital strip, not the headline.
- The screen *evolving with the era* is itself the "startup vs. titan feels different" fix — and it's consistent with stage-gated complexity.

**New nav tabs (added as stature/phase unlocks them — they don't all exist at turn one):**
- **Executives / Divisions** — your leadership team and what each runs; hiring market; comp/retention.
- **R&D / Research** — the deepened tree, line allocation, frontier programs, project slots.
- **Megaprojects** — the civilizational tech-tree and active endeavors with their stage progress.
- **Contracts / Government** — commercial vs. government work, defense programs, the influence/power interface.
- **Synergy / Integration** — the visible web of cross-front bonuses you're building.
- **Power / Influence** — the power meter, what's raising it, what it's unlocking, the government-relations standing (ramps in late; minimal/hidden early).
- (Existing: dashboard, company/products, market/investments, cap table, life.)

**Principle:** tabs and home-screen complexity **unlock with phase** — a Phase-1 founder sees a lean nav; a Phase-4 sovereign sees the full command center. The UI growing *is* the feeling of the company growing.

---

## 10. Optional victories, no hard win

Each megaproject completed is an optional **legacy victory** (First on Mars, Achieved AGI, Launched the Ark, Eclipsed the State), recorded and celebrated with the earned-moment template — **but the game continues.** You can pursue *all* of them across a long game. The megaprojects are the destinations that give the long game its pull without ending it. A player can also simply keep running a hugely profitable business forever if that's their joy. No forced ending.

---

## 11. Content authoring (what gets authored, in the `06` style)

Most of this vision is **content** on top of a reusable engine — which is the maintainability bet. Authored, per the existing TOML conventions:

- **The research tree** — *many* more projects/nodes per sub-industry and cross-domain: id, description, prerequisites (tech levels + other projects), the two-stage breakthrough→program structure, what each unlocks. **The biggest authoring job; do it first.**
- **Megaprojects** — each: description, gating convergence (stature + research + capital + exec + prerequisite projects), the staged milestones (with durations in weeks, costs, failure risk), what completion opens (sub-economy, synergies, power jump), narrative beats.
- **Executive archetypes & traits** — roles, competence ranges, personality traits and their mechanical effects, the candidate-market generation.
- **Synergy links** — the explicit web: "owning X gives Y a Z bonus," as authored pairs.
- **Contracts** — commercial vs. government contract types, their payouts, power/entanglement effects, obligations, scrutiny.
- **Expansion infrastructure** — HQs/campuses/institutions as tiered buildouts: cost, build time, permanent effect, prestige.
- **Power/government events** — the ramping scrutiny, antitrust, lobbying, sovereignty beats.

Adding/balancing any of this = authoring TOML, not engine surgery (same boundary as `06`/`07`).

---

## 12. Build sequencing (phased + shippable)

Ordered so each block is playable and the foundational dependency comes first:

1. **Deepened R&D tree + many more projects** (§7.1) — *foundational; everything gates on it.* Extend the research system, add frontier programs + project slots + the two-stage gate, author a much larger tree. Ship this first; it improves the existing game immediately even before the rest.
2. **Stature variable** (§2) + the easy world-aliveness adds (ticker, ambient no-decision events, visible milestones) — the ramp backbone + texture.
3. **Executives that actually run divisions** (§3) for the core roles (CTO/CFO/COO) — the delegation/management layer.
4. **Capital-deployment late game** (§6) — the spend catalog: acquisitions, expansion infrastructure (HQs/campuses), synergy buys. Solves "money trivial but nothing to spend on."
5. **Synergy web** (§8) — explicit cross-front integration.
6. **Commercial vs. government contracts** (§5) + the **power meter** (§4) — the converter and the emergent power axis.
7. **Megaprojects** (§7.2) — the civilizational tier, starting with one full branch (likely space: station → Moon → Mars, and AGI as the intelligence capstone).
8. **Full sovereign-era systems** — antitrust, government-as-peer, the "more powerful than the state" top of the power meter, remaining exec roles, optional victories.
9. **UI** evolves alongside each block (new tab when its system lands; home-screen reframe once Phase-3 systems exist). Mock screens per block in the `UI_LANGUAGE.md` language as they're built.

**Net:** the business sim you have grows a second half — a capital-deployment, empire-building, civilization-shaping late game where money becomes the medium and power becomes the emergent prize, all gated behind a research tree deep enough to reach the stars. Still a business sim. Just one that lets a great company become something the government has to answer to.
