# Title Screen + Founding Interstitial — Integration Notes

## Files
- `TitleScreen.tsx`, `FoundingInterstitial.tsx` — dependency-free (React only; data via props)
- `title.css` — import after `tokens.css`; uses the repo's vars, adds `--power`/`--gold`
- `content/ui/loading_lines.toml` — founding line per sub-industry + generic loading quips
- Mocks (the calibration reference): `title_screen.html`, `founding_interstitial.html`

## Font
Archivo (wdth 125, wght 500–900): `npm i @fontsource-variable/archivo` and import in `main.tsx`,
or vendor the woff2. Falls back to the system stack without breaking layout.

## Routing (App.tsx)
Current: `runOutcome ? BetweenCompanies : game ? GameShell : NewGameScreen`.
Add a `booting` phase:
1. No game + no wizard → `<TitleScreen save={saveSummary()} …/>` (replaces the wizard's "welcome" step;
   delete the `welcome` entry from `STEPS` in NewGameScreen).
2. `onNewGame` → NewGameScreen starting at `frontier`. `onContinue` → FoundingInterstitial
   (mode="loading", `genericLines` from loading_lines.toml) → GameShell.
3. NewGameScreen's `found()` → FoundingInterstitial (mode="founding") with facts from the new-game
   payload + the sub-industry's `[founding]` line; `onDone` → GameShell. Wire real progress via the
   `progress` prop if content loading is async; otherwise the self-timed mode (~4s) covers it.

## Tutorial layer
The guided tour anchored `data-guide="new-game-confirm"` on the wizard (unchanged) and the welcome
CTA (now `data-guide="title-new-game"` on the primary row — update `guided.ts`'s anchor for the
first coachmark). `emitGuided` calls in the wizard are untouched.

## Reduced motion / themes
Both components honor the app's `[data-reduce-motion="on"]` and `prefers-reduced-motion`. The title
is intentionally a night scene in both themes (`color-scheme: dark`) — the trajectory needs the dark.
