# Moonshot Inc — Power & Government Events: Design & Authoring

*The event texture of the power axis — how power's *consequences* express themselves and how the "more powerful than the government" arc actually plays out, beat by beat. This is the surface that makes the power meter (`08` §4) and the entanglement system (`16`) *felt* rather than just numeric. It services hooks already authored (the contract leak risks, the obligation penalties) and delivers the sovereign-era beats `08` §4/§7 promised. Authored like `15` — design + the actual events. Conventions: `$M`, weeks, snake_case.*

> **The frame:** as you accumulate power, the world stops ignoring you and starts *reacting* — first with scrutiny (antitrust, regulation, oversight), then with negotiation (governments treat you as a peer), and finally with deference (you're more powerful than they are). These events are how that ramp is dramatized. They also collect the bill for entanglement: the leak that exposes your intelligence contract, the obligation you can't escape, the administration that turns on you. Power is never free, and these events are where you pay — and, at the top, where you collect.

---

## Part 1 — What these events ARE

Unlike the sub-economy events (`15`, scoped to one frontier), **power/government events are global** — they fire based on your **power**, **entanglement**, and **stature** levels, not on owning a particular system. They're the world's ongoing response to *how big and how entangled you've become.* They are the primary expression surface of the power meter: without them, power is a number that unlocks content; with them, power is a *story* — the regulators circling, the leaked contract, the prime minister who now calls *you*.

**Four categories:**

1. **Scrutiny** — the cost of *bigness*. Antitrust probes, regulatory pressure, calls to break you up, oversight demands. Ramp with **power + stature**. The world's immune response to a giant.
2. **Entanglement** — the cost of *government work*. Leaks that expose classified contracts, obligations you can't exit, an administration change that turns on you, political dependency. Fire on **entanglement** (from `16`'s contracts). These service the leak/obligation hooks the contracts already declare.
3. **Lobbying / influence** — the *use* of power. Opportunities to spend money/power to shape policy, soften regulation, win favor — the deliberate exercise of influence. Available once you have power to spend.
4. **Sovereignty** — the *top* of the arc. Governments negotiate with you as a peer, then defer to you. Your execs advise heads of state; your projects set policy; you're consulted on matters of state; ultimately you're more powerful than the government. Gated to **high power** — the payoff beats of the whole game.

**The recurring fork:** most power/gov events offer a choice between **power and reputation/independence** — defy the regulator (power up, reputation down) or comply (reputation up, power down); assert control (power) or accept oversight (legitimacy). This is the same tension the contracts and sub-economy events use, now at the level of the state. *How you answer the world's reactions defines what kind of titan you are* — the feared sovereign or the respected institution.

---

## Part 2 — Why these events exist (the purpose)

- **They make power *felt*, not just counted.** The power meter (`08` §4) accumulates from megaprojects, sub-economies, and contracts — but a number is inert. These events are where power *happens to you and through you*: the headline, the showdown, the negotiation. They're the meter's dramatization.
- **They collect entanglement's bill.** The contracts system (`16`) promises that government work entangles you — scrutiny, obligation, leak risk. These events are where that promise is *kept.* The intelligence contract's "a scoped event can expose this" is one of these. Without them, entanglement is a cost with no teeth.
- **They give bigness an immune response.** A business sim where winning has no pushback gets boring. Scrutiny events mean dominance *creates its own enemies* — antitrust, regulation, public backlash — so the late game has friction that's a *consequence of success*, not artificial difficulty.
- **They deliver the "more powerful than the government" payoff.** This is the headline fantasy of the whole late-game vision (`08`). The sovereignty events are where it actually lands — the beats where you negotiate with states as an equal, then surpass them. Without these, "eclipse the government" is a meter reading, not an experience.
- **They turn power into a usable resource.** Lobbying events let you *spend* power/influence deliberately — making power something you wield, not just accumulate. The capital-deployment late game (`08` §6) extends into political capital.

**Design rule — the world reacts proportionally, and reaction is consequence not punishment.** Scrutiny should feel *earned* (you got big, of course they're watching), navigable (you have real choices), and identity-defining (how you handle it shapes who you are) — never a random tax. And the sovereignty beats must feel *earned* too: the payoff for a long climb, gated high enough that reaching them is a genuine achievement.

---

## Part 3 — How they fire (the mechanics)

### 3.1 Threshold-gated, not sub-economy-scoped
Each event declares **gates** on power / entanglement / stature. It's eligible only when you're at/above them. So:
- Scrutiny events gate on **power + stature** (you're big enough to bother regulating).
- Entanglement events gate on **entanglement** (you've done enough government work).
- Lobbying gates on **power** (you have influence to spend).
- Sovereignty gates on **high power** (the top of the meter) — these simply don't appear until you're near-sovereign.

This makes the event *texture itself* ramp with the phase: a Phase-1 founder never sees an antitrust probe; a Phase-4 sovereign sees governments defer. The world's reaction grows with you, which is the "startup vs. titan feels different" effect at the narrative layer.

### 3.2 Frequency scales with exposure
The more powerful and entangled you are, the *more often* these fire (a `frequency_scales_with` field — power or entanglement). A modest company gets the occasional regulatory nudge; a feared titan faces constant scrutiny, negotiation, and deference. Capped so it's texture, not a deluge.

### 3.3 Effects: the power-vs-reputation economy
Effects use the same vocabulary as the other events plus the power-axis meters: `power_delta`, `entanglement_delta`, `reputation_delta`, `revenue_delta`, and occasionally `regulation_level` (a soft modifier on how hard future scrutiny hits). Most are *choices* with a power/reputation tradeoff.

### 3.4 Servicing the contract hooks
Entanglement events include the **leak** events the `16` intelligence contracts declare (`leak risk: a scoped event can expose this contract`). These fire scoped to *having an active intelligence contract + high entanglement*, exposing it for reputation damage — the cost the contract warned about, finally arriving.

**Drop-in path:** `content/events/power/<category>.toml` (or wherever event files live). Schema matches existing events + the power-axis gates/effects.

---

## Part 4 — The events

Schema mirrors `15` / your existing events, plus `gates` (power/entanglement/stature floors) and `frequency_scales_with`.

### 4.1 Scrutiny — `content/events/power/scrutiny.toml`

```toml
[antitrust_inquiry]
id = "antitrust_inquiry"
category = "scrutiny"
gates = { power_min = 2, stature_min = 15000 }
frequency_scales_with = "power"
kind = "crisis"
weight = 1.0
cooldown_weeks = 78
headline = "Antitrust regulators open a formal inquiry"
body = """Your dominance has drawn a formal antitrust investigation. You can offer \
concessions to settle it quietly, or fight to keep your position whole and accept \
the scrutiny — and the precedent — that comes with refusing to yield."""
[[antitrust_inquiry.choices]]
label = "Settle with concessions"
[antitrust_inquiry.choices.effects]
reputation_delta = 1
power_delta = -1
revenue_delta = -50
[[antitrust_inquiry.choices]]
label = "Fight it"
[antitrust_inquiry.choices.effects]
power_delta = 1
reputation_delta = -1
regulation_level = 1

[breakup_pressure]
id = "breakup_pressure"
category = "scrutiny"
gates = { power_min = 4, stature_min = 40000 }
frequency_scales_with = "power"
kind = "crisis"
weight = 0.9
cooldown_weeks = 120
headline = "Lawmakers call for your company to be broken up"
body = """You have grown large enough that legislators are openly proposing to \
dismantle you. A grave threat — and a backhanded acknowledgment that you've become \
too important to ignore. You can mount a charm offensive, or dare them to try."""
[[breakup_pressure.choices]]
label = "Charm offensive ($150M)"
[breakup_pressure.choices.effects]
revenue_delta = -150
reputation_delta = 2
[[breakup_pressure.choices]]
label = "Dare them"
[breakup_pressure.choices.effects]
power_delta = 2
reputation_delta = -2
regulation_level = 1

[regulatory_framework]
id = "regulatory_framework"
category = "scrutiny"
gates = { power_min = 2, stature_min = 18000 }
frequency_scales_with = "power"
kind = "crisis"
weight = 1.0
cooldown_weeks = 70
headline = "A new regulatory framework targets your industry"
body = """Lawmakers draft rules clearly aimed at your line of business. You can help \
write them — shaping the cage you'll live in — or oppose them outright."""
[[regulatory_framework.choices]]
label = "Help write the rules"
[regulatory_framework.choices.effects]
power_delta = 1
reputation_delta = 1
revenue_delta = -30
[[regulatory_framework.choices]]
label = "Oppose them"
[regulatory_framework.choices.effects]
reputation_delta = -1
regulation_level = 1

[public_backlash]
id = "public_backlash"
category = "scrutiny"
gates = { power_min = 3, stature_min = 25000 }
frequency_scales_with = "power"
kind = "flavor"
weight = 1.0
cooldown_weeks = 60
headline = "Public unease grows over your concentration of power"
body = """Op-eds and protests question whether any company should be as powerful as \
yours has become. No immediate action — but the mood is shifting, and moods become \
laws."""
[public_backlash.effects]
reputation_delta = -1
regulation_level = 1
```

### 4.2 Entanglement — `content/events/power/entanglement.toml`

```toml
[classified_contract_leak]
id = "classified_contract_leak"
category = "entanglement"
gates = { entanglement_min = 40 }
requires_active_contract_customer = "intelligence_service"   # services the 16 leak hook
frequency_scales_with = "entanglement"
kind = "crisis"
weight = 1.0
cooldown_weeks = 90
headline = "A classified contract is leaked to the press"
body = """Documents exposing your secret work for an intelligence service have hit \
the front pages. The public and your commercial customers are alarmed. You can come \
clean and weather it, or deny and deflect and hope it blows over."""
[[classified_contract_leak.choices]]
label = "Come clean"
[classified_contract_leak.choices.effects]
reputation_delta = -1
[[classified_contract_leak.choices]]
label = "Deny and deflect"
[classified_contract_leak.choices.effects]
reputation_delta = -2
power_delta = 1

[contract_obligation]
id = "contract_obligation"
category = "entanglement"
gates = { entanglement_min = 30 }
frequency_scales_with = "entanglement"
kind = "crisis"
weight = 1.0
cooldown_weeks = 65
headline = "The state invokes a priority clause"
body = """A government you're contracted to invokes its priority rights — commandeering \
capacity you'd planned to sell commercially. You're bound by the terms you signed. \
You can comply, or push back and strain the relationship."""
[[contract_obligation.choices]]
label = "Comply with the order"
[contract_obligation.choices.effects]
revenue_delta = -40
power_delta = 1
[[contract_obligation.choices]]
label = "Push back"
[contract_obligation.choices.effects]
entanglement_delta = -8
reputation_delta = -1
power_delta = -1

[administration_change]
id = "administration_change"
category = "entanglement"
gates = { entanglement_min = 35 }
frequency_scales_with = "entanglement"
kind = "crisis"
weight = 0.9
cooldown_weeks = 100
headline = "A hostile administration takes power"
body = """An election has put a government in power that views your influence with \
suspicion. The contracts that made you strong now make you a target. You can invest \
in the new relationship, or weather the cold and lean on your other channels."""
[[administration_change.choices]]
label = "Invest in the relationship ($100M)"
[administration_change.choices.effects]
revenue_delta = -100
entanglement_delta = 5
[[administration_change.choices]]
label = "Weather the cold"
[administration_change.choices.effects]
power_delta = -1
revenue_delta = -50

[defense_dependency]
id = "defense_dependency"
category = "entanglement"
gates = { entanglement_min = 50 }
frequency_scales_with = "entanglement"
kind = "flavor"
weight = 1.0
cooldown_weeks = 70
headline = "You are named a critical defense supplier"
body = """The state formally designates your company critical national-security \
infrastructure. It is a mark of how essential you've become — and a set of \
obligations and oversight you can never fully shed. Protected, and bound."""
[defense_dependency.effects]
power_delta = 1
entanglement_delta = 5
```

### 4.3 Lobbying / influence — `content/events/power/lobbying.toml`

```toml
[lobbying_opportunity]
id = "lobbying_opportunity"
category = "lobbying"
gates = { power_min = 2, stature_min = 14000 }
frequency_scales_with = "power"
kind = "opportunity"
weight = 1.0
cooldown_weeks = 55
headline = "A chance to shape pending legislation"
body = """A bill that will affect your industry for a decade is being drafted. A \
well-placed lobbying campaign could tilt it your way — a direct, if unglamorous, \
exercise of the power you've built."""
[[lobbying_opportunity.choices]]
label = "Fund the campaign ($60M)"
[lobbying_opportunity.choices.effects]
revenue_delta = -60
power_delta = 1
regulation_level = -1
[[lobbying_opportunity.choices]]
label = "Stay out of it"
[lobbying_opportunity.choices.effects]
reputation_delta = 1

[policy_advisory_seat]
id = "policy_advisory_seat"
category = "lobbying"
gates = { power_min = 3, stature_min = 22000 }
frequency_scales_with = "power"
kind = "opportunity"
weight = 1.0
cooldown_weeks = 70
headline = "You're offered a seat on a national policy council"
body = """The government invites you onto a council shaping national technology \
strategy. Real influence over the rules everyone plays by — at the cost of being \
seen as part of the establishment you might one day need to defy."""
[[policy_advisory_seat.choices]]
label = "Take the seat"
[policy_advisory_seat.choices.effects]
power_delta = 1
entanglement_delta = 6
[[policy_advisory_seat.choices]]
label = "Decline to stay independent"
[policy_advisory_seat.choices.effects]
reputation_delta = 1

[fund_initiative]
id = "fund_initiative"
category = "lobbying"
gates = { power_min = 2, stature_min = 16000 }
frequency_scales_with = "power"
kind = "opportunity"
weight = 1.0
cooldown_weeks = 60
headline = "A chance to fund a public initiative in your favor"
body = """Bankrolling a research institute, a think tank, or a public-works program \
would build goodwill and quietly steer the conversation your way. Soft power, \
bought."""
[[fund_initiative.choices]]
label = "Fund it ($80M)"
[fund_initiative.choices.effects]
revenue_delta = -80
reputation_delta = 2
power_delta = 1
[[fund_initiative.choices]]
label = "Pass"
[fund_initiative.choices.effects]
```

### 4.4 Sovereignty — `content/events/power/sovereignty.toml`

```toml
[summoned_as_peer]
id = "summoned_as_peer"
category = "sovereignty"
gates = { power_min = 5, stature_min = 45000 }
frequency_scales_with = "power"
kind = "flavor"
weight = 1.0
cooldown_weeks = 80
headline = "A head of state requests a meeting — as an equal"
body = """A national leader asks to meet you not as a regulator to a company, but as \
one power to another. The framing alone is historic: you are now an actor on the \
world stage, negotiated with rather than governed."""
[summoned_as_peer.effects]
power_delta = 1
reputation_delta = 1

[arbitrate_dispute]
id = "arbitrate_dispute"
category = "sovereignty"
gates = { power_min = 5, stature_min = 50000 }
frequency_scales_with = "power"
kind = "opportunity"
weight = 0.9
cooldown_weeks = 100
headline = "Nations ask you to mediate a dispute"
body = """A disagreement between states — over orbital rights, or resources, or \
access to your infrastructure — and the parties have asked *you* to mediate. You \
hold leverage over both. The role is the clearest sign yet that you have surpassed \
the institutions that once oversaw you."""
[[arbitrate_dispute.choices]]
label = "Mediate impartially"
[arbitrate_dispute.choices.effects]
reputation_delta = 2
power_delta = 1
[[arbitrate_dispute.choices]]
label = "Tilt it to your advantage"
[arbitrate_dispute.choices.effects]
power_delta = 2
reputation_delta = -1

[set_the_policy]
id = "set_the_policy"
category = "sovereignty"
gates = { power_min = 6, stature_min = 60000 }
frequency_scales_with = "power"
kind = "crisis"
weight = 1.0
cooldown_weeks = 110
headline = "Governments adopt your standard as international law"
body = """A framework your company authored — for AI, for orbital traffic, for the \
new economy — is being adopted by governments as binding international policy. You \
are no longer subject to the rules. You write them. The question is only how openly \
you wield it."""
[[set_the_policy.choices]]
label = "Wield it openly"
[set_the_policy.choices.effects]
power_delta = 2
reputation_delta = -1
[[set_the_policy.choices]]
label = "Wield it quietly"
[set_the_policy.choices.effects]
power_delta = 1
reputation_delta = 1

[more_powerful_than_government]
id = "more_powerful_than_government"
category = "sovereignty"
gates = { power_min = 7, stature_min = 75000 }
frequency_scales_with = "power"
kind = "flavor"
weight = 1.0
cooldown_weeks = 9999
headline = "Analysts conclude your company now outweighs most nations"
body = """It is said plainly now, in the press and in the halls of power: your \
company is more powerful than most of the governments of the Earth. Budgets larger \
than nations', infrastructure entire states depend on, a say in matters once \
reserved for sovereigns. The founder's garage is a long way behind you. The \
question of what you do with this has no precedent to guide it."""
[more_powerful_than_government.effects]
power_delta = 1
reputation_delta = 1
legacy_victory = "more_powerful_than_government"
```

---

## Part 5 — Validation / authoring notes
- [ ] Every event has `gates` (power/entanglement/stature floors); sovereignty events gate at high power (5+).
- [ ] `kind` is flavor | opportunity | crisis; crises have ≥2 choices.
- [ ] Effect keys are engine-known (`power_delta`, `entanglement_delta`, `reputation_delta`, `revenue_delta`, `regulation_level`, `legacy_victory`).
- [ ] `classified_contract_leak` correctly gates on an active intelligence-service contract (services the `16` hook).
- [ ] Schema matches existing `content/events/` files — **confirm field names against a real event file before merge.**
- [ ] Category spread: scrutiny (5), entanglement (5), lobbying (3), sovereignty (4) = 17 events.

## Part 6 — What I (Claude) build — not authoring
- The threshold-gated firing system (eligibility by power/entanglement/stature; frequency scaling with exposure; cooldowns).
- The `regulation_level` soft modifier (how hard future scrutiny hits) and its decay.
- Wiring `classified_contract_leak` (and similar) to active-contract state from `16`.
- Power/entanglement/reputation effect application (these meters live in the power system, `08` §4 + `16`).
- The `more_powerful_than_government` legacy victory.
- Surfacing via the existing event-decision UI (these are global events in the main event stream, phase-gated).

## Part 7 — The shape of the arc these create
Read top to bottom, the categories *are* the late-game story: you get big enough to be **scrutinized**, entangled enough to be **bound**, powerful enough to **lobby**, and finally sovereign enough to be **deferred to**. A player feels the world's posture toward them shift from *governing* them → *negotiating* with them → *answering* to them. That progression, dramatized in events and gated by the power meter, is the "more powerful than the government" fantasy made into lived experience rather than a number — the emotional payoff the whole power axis was built to deliver.

> Count: 17 events across 4 categories. Like `15`, expand any category later if it feels thin in play. The sovereignty tier especially can grow — those are the rarest, most-savored beats, and more of them enriches the very top of the game.
