# Moonshot Inc — Advanced Products: Authoring Addendum

*The 13 advanced product archetypes that the R&D tree (`09`) unlocks via `unlocks.products`. This is an **addendum to `06`**, not a new system — these are ordinary product archetypes in the existing schema, just gated by research completion instead of (only) tech levels. Authoring these clears the last of the `09` dangling-reference warnings and closes the products↔research loop. Conventions: `$M`, weeks, snake_case, same schema as `06`.*

---

## What these are and how they differ from `06` products

In `06` you authored the base product tiers (tier 0–3) that gate on **tech levels** alone. The `09` research tree adds nodes whose `unlocks.products` grant **new, higher-end archetypes** — a `node_leadership_program` research project unlocks the `frontier_node_part` product, etc.

The one conceptual difference: **these are research-gated.** A normal `06` product becomes buildable when your tech levels clear its `gates`. These 13 become buildable when **the unlocking research project is complete** (and then still respect their `gates` as a floor). So the engine's availability rule for these is: *research project done AND tech-level gates met.* You author them exactly like any `06` product — the research-gating is wired by the `09` node that names them; you don't add a new field for it. Just keep their `gates` consistent with (≤) the tech levels the unlocking research node itself required, so a player who finished the research can actually build the product.

**These are top-of-tree products** (effectively tier 2–4): expensive, slow, high-margin, high addressable market — the things a serious company builds once it's done the research. Author them at the high end of the `06` economics ranges.

---

## The 13 products → their unlocking research node

| product id | sub-industry | unlocked by (`09` node) | tier | the thing it is |
|---|---|---|---|---|
| `chiplet_accelerator` | ai_chips | `chiplet_packaging` | 2 | A multi-die accelerator that scales past the monolithic yield wall. |
| `edge_ai_chip` | ai_chips | `edge_inference_chip` | 2 | Tiny power-sipping inference silicon for phones/cars/devices. |
| `frontier_node_part` | ai_chips | `node_leadership_program` | 3 | A bleeding-edge part a full node ahead of everyone. |
| `wafer_scale_engine` | ai_chips | `wafer_scale_compute` | 3 | A dinner-plate-sized single processor for AI training. |
| `autonomous_agent_platform` | frontier_model_lab | `autonomous_agents` | 3 | Models that do multi-step work autonomously — sold as a platform. |
| `multi_vertical_platform` | vertical_ai_saas | `multi_vertical_expansion` | 2 | One platform adapted across several industries. |
| `autonomous_operations_suite` | vertical_ai_saas | `autonomous_workflows` | 3 | Software that runs whole processes end-to-end (outcomes, not seats). |
| `super_heavy_vehicle` | launch_services | `heavy_lift_program` | 3 | A fully reusable super-heavy lifter — the off-world backbone. |
| `global_broadband_network` | satellite_constellations | `global_broadband` | 3 | A planet-covering broadband constellation. |
| `direct_to_device_service` | satellite_constellations | `direct_to_device` | 2 | Signal straight to ordinary phones, no terminal. |
| `servicing_vehicle` | satellite_constellations | `orbital_servicing` | 2 | Robotic craft that refuel/repair satellites in orbit. |
| `orbital_city` | space_stations | `large_scale_stations` | 3 | A multi-hundred-person orbital complex. |
| `microgravity_factory` | space_stations | `in_space_manufacturing_mod` | 2 | An orbital module making things only microgravity allows. |

---

## Schema reminder (from `06`)

Each archetype is a keyed table in the existing `content/products/<sub>.toml` file (append to it). Required fields:

```toml
[<product_id>]
id = "<product_id>"
sub_industry = "<sub>"
name = "..."
tier = 2                        # or 3 — these are top-of-tree
description = """..."""          # characterful — what it is, why it matters
flavor_naming_hint = "..."

[<product_id>.gates]            # tech-level floor; keep ≤ the unlocking research node's own rd_levels
<line_id> = <level>

[<product_id>.economics]
build_cost = <$M>
build_weeks = <weeks>
unit_margin = <0–1>
capacity_type = "<capacity_id>"  # real capacity in this sub
capacity_to_build = <units>
capacity_to_run = <units>
addressable_market = <$M/yr>
ramp_weeks = <weeks>
decay_per_quarter = <fraction>

[<product_id>.specs]           # WEIGHTS summing to 1.0; tags from this sub's lines' drives_specs
<spec_tag> = <weight>
```

**Validation reminders** (same as `06`): `gates` keys are real lines in the sub; `capacity_type` is a real capacity id; `specs` weights sum to exactly 1.0; spec tags trace to a line's `drives_specs`; `capacity_to_build` ≤ the sub's max capacity rung. **Plus one new check:** each product's `gates` should be ≤ the `rd_levels` its unlocking `09` node required (so finishing the research guarantees you can build the product).

---

## Per-product authoring guidance (economics targets)

Concrete starting numbers so they're internally consistent with `06`'s tiers and each other. Tune to taste; these are sane anchors. (Reference: `06` tier-3 chips part was ~$600M/180w; tier-3 lab ~$200M/78w; etc. — these slot at/above those.)

**ai_chips** (capacity_type `fab_line`; spec tags: performance, efficiency, margin, cost, specialization):
- `chiplet_accelerator` — tier 2. gates `{ yield_line = 45, architecture = 40 }`. ~$180M / 110w, margin 0.58, cap_build 2 / run 2, market 7000, ramp 36, decay 0.08. specs `{ performance 0.5, efficiency 0.3, margin 0.2 }`.
- `edge_ai_chip` — tier 2. gates `{ architecture = 40, process_node = 38 }`. ~$70M / 60w, margin 0.4, cap 1/1, market 2500, ramp 26, decay 0.07. specs `{ efficiency 0.5, performance 0.3, margin 0.2 }`.
- `frontier_node_part` — tier 3. gates `{ process_node = 75, yield_line = 60 }`. ~$650M / 175w, margin 0.7, cap 3/2, market 18000, ramp 52, decay 0.11. specs `{ performance 0.6, efficiency 0.25, margin 0.15 }`.
- `wafer_scale_engine` — tier 3. gates `{ yield_line = 70, architecture = 65 }`. ~$500M / 150w, margin 0.66, cap 3/3, market 14000, ramp 44, decay 0.10. specs `{ performance 0.55, efficiency 0.3, margin 0.15 }`.

**frontier_model_lab** (capacity_type `compute`; tags: capability, reliability, benchmark, safety):
- `autonomous_agent_platform` — tier 3. gates `{ scaling = 60, data_quality = 55, alignment = 45 }`. ~$200M / 78w, margin 0.64, cap 4/4, market 18000, ramp 30, decay 0.14. specs `{ capability 0.45, reliability 0.3, safety 0.25 }`.

**vertical_ai_saas** (capacity_type `deployment`; tags: fit, stickiness, reliability, moat):
- `multi_vertical_platform` — tier 2. gates `{ platform = 45, domain_depth = 40 }`. ~$45M / 40w, margin 0.78, cap 2/2, market 4500, ramp 32, decay 0.04. specs `{ fit 0.4, stickiness 0.35, reliability 0.25 }`.
- `autonomous_operations_suite` — tier 3. gates `{ platform = 60, domain_depth = 60, model_leverage = 50 }`. ~$100M / 60w, margin 0.8, cap 2/3, market 11000, ramp 44, decay 0.03. specs `{ stickiness 0.4, fit 0.35, reliability 0.25 }`.

**launch_services** (capacity_type `launch_capacity`; tags: payload, reliability, cost, performance, margin):
- `super_heavy_vehicle` — tier 3. gates `{ propulsion = 65, reusability = 60, reliability = 60 }`. ~$300M / 130w, margin 0.55, cap 3/2, market 14000, ramp 52, decay 0.03 (a workhorse). specs `{ payload 0.4, reliability 0.35, cost 0.25 }`.

**satellite_constellations** (capacity_type `sat_manufacturing` / `ground_network`; tags: coverage, capability, cost, reliability, margin):
- `global_broadband_network` — tier 3. gates `{ mass_production = 65, network = 60, satellite_tech = 55 }`. ~$700M / 150w, margin 0.58, cap_type `sat_manufacturing`, cap 5/3, market 20000, ramp 60, decay 0.07. specs `{ coverage 0.45, cost 0.3, capability 0.25 }`.
- `direct_to_device_service` — tier 2. gates `{ satellite_tech = 50, network = 45 }`. ~$220M / 100w, margin 0.5, cap_type `sat_manufacturing`, cap 3/2, market 8000, ramp 44, decay 0.06. specs `{ coverage 0.4, capability 0.35, reliability 0.25 }`.
- `servicing_vehicle` — tier 2. gates `{ satellite_tech = 60, mass_production = 55 }`. ~$120M / 70w, margin 0.48, cap_type `sat_manufacturing`, cap 2/1, market 3000, ramp 39, decay 0.05. specs `{ capability 0.45, reliability 0.35, coverage 0.2 }`.

**space_stations** (capacity_type `module_construction`; tags: capacity, capability, safety, cost):
- `orbital_city` — tier 3. gates `{ module_tech = 65, assembly = 60, life_support = 55 }`. ~$750M / 170w, margin 0.55, cap 5/3, market 14000, ramp 65, decay 0.03. specs `{ capacity 0.4, capability 0.35, safety 0.25 }`.
- `microgravity_factory` — tier 2. gates `{ module_tech = 50, assembly = 45 }`. ~$120M / 80w, margin 0.5, cap 2/2, market 4000, ramp 44, decay 0.04. specs `{ capacity 0.4, capability 0.35, cost 0.25 }`.

> **Note on `gates` consistency:** I set each product's `gates` to match the `rd_levels` its unlocking `09` node required (e.g. `frontier_node_part` gates at `process_node 75 / yield_line 60` — exactly what `node_leadership_program` needed). That guarantees: finish the research → you meet the product's gates → you can build it. Keep that alignment if you adjust numbers.

---

## One full worked example (so the pattern's concrete)

Append to `content/products/ai_chips.toml`:

```toml
[wafer_scale_engine]
id = "wafer_scale_engine"
sub_industry = "ai_chips"
name = "Wafer-scale engine"
tier = 3
description = """A single processor the size of a dinner plate — an entire wafer \
left uncut, hundreds of thousands of cores wired as one. It sidesteps the \
chip-to-chip bottleneck entirely and gives AI training a substrate nothing built \
from discrete parts can match. Only a fab that has mastered yield at the limit can \
make one without scrapping a fortune in silicon per attempt."""
flavor_naming_hint = "e.g. 'Monolith-1', a single-massive-part name"

[wafer_scale_engine.gates]
yield_line = 70
architecture = 65

[wafer_scale_engine.economics]
build_cost = 500
build_weeks = 150
unit_margin = 0.66
capacity_type = "fab_line"
capacity_to_build = 3
capacity_to_run = 3
addressable_market = 14000
ramp_weeks = 44
decay_per_quarter = 0.10

[wafer_scale_engine.specs]
performance = 0.55
efficiency = 0.30
margin = 0.15
```

---

## What I (Claude) handle — not authoring

- The research-gating wiring (a product named in a `09` node's `unlocks.products` becomes available when that node completes, then respects its `gates`). The loader already reads `unlocks.products`; I make availability check both.
- The validation extension: each product's `gates` ≤ its unlocking node's `rd_levels` (warn if a product is unlockable-but-unbuildable).
- Everything else is the existing `06`/`07` product engine — these archetypes just flow through it.

---

## Authoring order

Fast job — 13 archetypes across 6 files. Suggested:
1. **ai_chips** (4 — you're playtesting it; biggest immediate payoff): `chiplet_accelerator`, `edge_ai_chip`, `frontier_node_part`, `wafer_scale_engine`.
2. **frontier_model_lab** (1): `autonomous_agent_platform`.
3. The space trio's high-ends: `super_heavy_vehicle`, `global_broadband_network`, `orbital_city`.
4. The rest: `multi_vertical_platform`, `autonomous_operations_suite`, `direct_to_device_service`, `servicing_vehicle`, `microgravity_factory`.

Each: append to the existing `content/products/<sub>.toml`, characterful description, gates aligned to the unlocking node, economics from the anchors above, specs summing to 1.0. When done, this clears every remaining `09` product warning and the products↔research chain is fully closed.
