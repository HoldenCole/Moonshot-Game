# Moonshot Inc — Executives & Delegation: Design & Authoring Spec

*The management layer that turns the player from an operator into an executive. Written to be understood fresh: what executives are, why they exist, how they work, and what to author. This is the "feel like an executive" pillar of `08` §3, and it's referenced by the megaproject `exec_required` gates (`10`). Conventions: `$M`, weeks, snake_case, content/code boundary.*

---

## Part 1 — What the executive system IS

In the early game you do everything yourself: you set the R&D split, approve every hire, time every product bet, manage the money. That's the founder game, and it's right for a small company. But it doesn't scale — by the late game, doing it all by hand is both exhausting and *wrong* for the fantasy. A titan's CEO doesn't set the compute budget; they hire someone brilliant to do that and point them at the right problem.

The **executive system** is how that transition happens. You **hire executives**, each of whom **autonomously runs a domain of the company** — and their **competence and personality materially help or hurt** everything in that domain. Hiring a CTO means R&D now largely runs itself toward a direction you set; a great one accelerates your whole tech tree, a mediocre one quietly wastes budget and mis-times bets. You stop doing the work and start **choosing and steering the people who do it.**

**The mental model:** an executive is a *competence-and-personality multiplier bolted onto a system you already have.* The R&D system, the bet scheduler, the earnings system, go-to-market — they already exist and already run. An exec doesn't replace them; they **operate them on your behalf, modified by who they are.** A 90-competence visionary CTO and a 50-competence cautious one run the *same* R&D system to wildly different effect.

This is not a separate minigame. It's a layer that sits over the existing engine and changes how well (and how) it runs.

---

## Part 2 — Why executives exist (the purpose)

- **They deliver the executive fantasy.** The whole arc is founder → executive → owner → capital allocator (`08`). Executives are the literal mechanism of the middle of that arc: the moment you stop being the person doing the work and become the person who hires the people who do. That *feels* like growing up as a company.
- **They dissolve the late-game "too many small clicks" problem.** By mid-game there are many domains each generating decisions. Without delegation, the late game drowns you in micro-management. With it, you hand domains to execs and only engage with what they escalate — the decision load *shrinks* as you grow, which is correct (a CEO has fewer, bigger decisions than a founder).
- **They make hiring a strategic character game.** Competence + traits mean every exec is a *bet on a person.* Do you hire the visionary who swings for moonshots (and sometimes whiffs expensively) or the steady operator who compounds but never leaps? That's a real, recurring, flavorful decision — and it's a way to *damage* the company (a bad CFO over-levers you into a bust), which is what makes a good team feel earned.
- **They gate the megaprojects.** Civilizational endeavors need someone to run them — the `exec_required` gates in `10` (a Mars colony needs a `space_program` lead; AGI needs a `chief_scientist`). Executives are part of the convergence that only a titan can assemble.
- **They're the human face of the narrative.** Execs are named characters with personalities who show up in the CEO log, escalate decisions to you, clash with each other, threaten to leave, and celebrate wins. They populate the "living world" the narrative layer is built on.

**Design rule:** an executive must be *consequential in both directions* — a great one is a genuine force multiplier, a bad one genuinely costs you. If hiring an exec is always strictly good (just "unlocks automation"), the character game is dead. The risk is the point.

---

## Part 3 — How executives work (the mechanics)

### 3.1 Domains
Each executive occupies a **domain** — a slice of the company they run. The core domains map onto systems you already have:

| domain | runs (existing system) | competence affects |
|---|---|---|
| `cto` | R&D allocation + product bets (`06`/`07`/`09`) | tech-level progress rate, bet timing/success, which research to pursue |
| `cfo` | financing, treasury, earnings (`06` finance) | raise terms, treasury returns, earnings management, runway discipline |
| `coo` | capacity + operations (`07`) | capacity build cost/speed, utilization, expansion timing |
| `cro` | go-to-market / market share (`06` product market) | share capture rate, pricing, contract wins |
| `chief_scientist` | frontier research + intelligence megaprojects | frontier-program speed, AGI/quantum/science megaproject gating + risk |
| `space_program` | space megaprojects | Mars/asteroid/orbital megaproject gating, stage setback rates |
| `chief_executive` | economic megaprojects + cross-domain | economic megaproject gating, a small buff to all domains |

Early game you hold all domains yourself (founder default — you run them, no buffs/penalties, full manual control). As you grow you **hire into a domain**, which hands its routine decisions to the exec. The megaproject-gating domains (`chief_scientist`, `space_program`, `chief_executive`) are the ones `10`'s `exec_required` references — you literally cannot start a Mars colony without a `space_program` lead in the chair.

### 3.2 Competence — the multiplier with teeth
Each exec has a **competence** score (0–100). It's a multiplier on their domain's outcomes:
- A high-competence CTO: tech levels rise faster (a bonus to R&D progress), bets are timed well (lower effective setback, better build timing), good research priorities chosen.
- A low-competence one: budget partially wasted (effective R&D spend reduced), bets mistimed, occasional dud priorities.
- Competence is **relative to your stature** — a brilliant exec won't join a tiny company (the candidate market is stature-gated, 3.5). Early you get journeymen; as a titan, the legends are available.

### 3.3 Traits — personality and variance
Each exec has 1–3 **traits** that shape *how* they run the domain (beyond raw competence):
- **`visionary`** — pursues high-tier/frontier work aggressively; high variance (generational wins or expensive flops).
- **`steady`** — compounds reliably; low variance; never leaps.
- **`aggressive`** (CFO) — over-levers/over-invests; amplifies booms, dangerous in busts.
- **`cautious`** — conserves, low risk, leaves some growth on the table.
- **`empire_builder`** — grows their domain's headcount/budget hard (powerful but costly; can clash with other execs).
- **`star`** — exceptional but expensive and a flight risk (gets poached if underpaid).
- **`loyalist`** — stays through thick and thin; lower defection risk.
- **`maverick`** — occasionally ignores your mandate and does their own thing (great when right, a liability when wrong).
- (Author more — these are examples. Each trait is a named, engine-known behavior modifier.)

Traits are what make two equally-competent execs *play differently*, and what make hiring a character choice rather than a stat purchase.

### 3.4 The autonomous decision model (mandate → execute → escalate)
This is the heart of "delegation, not automation":
- You set the exec's **mandate** (a high-level direction: "chase the frontier" vs. "defend margins"; "grow aggressively" vs. "extend runway") and optionally **guardrails** (spend caps, risk limits).
- Each turn the exec **acts within that mandate** — runs their domain's decisions automatically, colored by competence + traits.
- They **escalate** to you only the big calls or threshold events ("your CTO wants to commit the next cycle to the agentic platform — approve?", "your CFO recommends a $2B raise"). You intervene on those; the rest runs.
- You can **override** at any time (take manual control of a domain for a turn), but a good exec left alone usually outperforms your micro-management — which is the design teaching you to let go.

This is what makes you *feel* like an executive: you're setting direction and reacting to escalations, not pulling every lever.

### 3.5 The hiring & retention game
- **Candidate market:** at any time a pool of available execs exists, their quality gated by your **stature** (`08` §2) — a $50B titan attracts legends; a $200M startup gets journeymen. Refreshes over time; you can also spend to headhunt (pay to surface better candidates).
- **Compensation:** each exec has a comp expectation (salary `$M/yr` + equity `%`). Underpay and retention drops; star traits raise the bar. Equity grants dilute you (ties into the cap table).
- **Retention & defection:** execs can be **poached** by rivals (especially `star`s you underpay), **leave** if morale/mandate-fit is poor, or stay (`loyalist`). Losing a key exec mid-megaproject is a real setback — retention is an ongoing game, not a one-time hire.
- **Firing:** you can fire an underperformer — but it costs severance, hits company morale, and may spook other execs. Sometimes necessary, never free.
- **Clashes:** strong personalities conflict (two `empire_builder`s fighting over budget; a `maverick` CTO vs. a `cautious` CFO). Clashes generate events and can degrade performance until resolved — managing the *team*, not just individuals.

### 3.6 Concurrency / scale
You can fill a domain only once (one CTO at a time). The number of *domains* available grows with the company — early you might only have CTO/CFO/COO; the megaproject-gating roles (`chief_scientist`, `space_program`, `chief_executive`) open at higher stature. So the leadership team *grows* as you scale, which is itself the "company feels bigger" effect.

---

## Part 4 — What you author

Execs are largely *generated* from authored **archetypes + traits + a name/flavor pool**. You don't hand-author every individual exec (they're procedural, like procedural companies); you author the *ingredients* the generator draws from.

**Drop-in paths:**
- `content/executives/_domains.toml` — the domain definitions
- `content/executives/_traits.toml` — the trait pool
- `content/executives/archetypes.toml` — exec archetypes (templates the generator uses)
- `content/executives/_names.toml` — name/flavor pools for generation
- `content/executives/_tuning.toml` — candidate market, comp, retention tuning

### 4.1 Domains — `content/executives/_domains.toml`
```toml
[cto]
id = "cto"
name = "Chief Technology Officer"
runs = "rd_and_products"         # engine-known: which system this domain operates
description = """Owns research direction and the product roadmap — what you build \
and how fast the tech advances."""
unlock_stature = 0               # available from the start (you hold it as founder until hired)
escalation_examples = ["commit a frontier program", "bet the next cycle on a new product tier"]

[chief_scientist]
id = "chief_scientist"
name = "Chief Scientist"
runs = "frontier_research"
description = """Runs the bleeding edge — frontier programs and the intelligence \
megaprojects. The person who can shepherd an AGI program without it going off the rails."""
unlock_stature = 25000           # only opens as a titan
gates_megaprojects = ["artificial_general_intelligence", "quantum_supremacy_platform", "accelerated_science_program"]
escalation_examples = ["proceed to the next AGI stage despite an alignment flag"]

# ... cfo, coo, cro, space_program, chief_executive
```
Field notes: `runs` is an engine-known system tag; `unlock_stature` gates when the domain becomes hireable; `gates_megaprojects` lists the `10` megaprojects this domain's exec is required for (the `exec_required` link — author it to match `10`).

### 4.2 Traits — `content/executives/_traits.toml`
```toml
[visionary]
id = "visionary"
name = "Visionary"
description = """Swings for the fences — pushes frontier and high-tier work hard. \
Generational wins, or expensive flops. High variance."""
effects = { tier_bias = 0.3, variance = 0.4 }      # engine-known modifiers
applies_to = ["cto", "chief_scientist"]            # domains where this trait makes sense (empty = any)
comp_premium = 0.1                                  # raises pay expectation

[steady]
id = "steady"
name = "Steady operator"
description = "Compounds reliably; low variance; rarely leaps."
effects = { variance = -0.3, consistency = 0.2 }
applies_to = []
comp_premium = 0.0

[star]
id = "star"
name = "Star"
description = """Exceptional and knows it — a major performance boost, an expensive \
salary, and a flight risk if you don't pay to keep them."""
effects = { competence_bonus = 0.15 }
applies_to = []
comp_premium = 0.4
flight_risk = 0.3

# ... aggressive, cautious, empire_builder, loyalist, maverick, ...
```

### 4.3 Archetypes — `content/executives/archetypes.toml`
Templates the generator instantiates (competence range, likely traits, flavor) per domain.
```toml
[frontier_cto]
id = "frontier_cto"
domain = "cto"
name = "Frontier CTO"
description = """A research-pedigree technologist who lives at the edge — the kind \
who'll bet the lab on the next architecture."""
competence_range = [60, 95]
trait_pool = ["visionary", "star", "maverick"]      # generator picks 1–3 from here
trait_count = [1, 2]
min_stature = 8000                                   # only appears in the market at this stature+
flavor_titles = ["ex-DeepMind research lead", "founder of a sold AI startup"]

[operator_cto]
id = "operator_cto"
domain = "cto"
name = "Operator CTO"
description = "A ship-it pragmatist who compounds steadily and rarely misses a deadline."
competence_range = [50, 80]
trait_pool = ["steady", "loyalist", "cautious"]
trait_count = [1, 2]
min_stature = 0
flavor_titles = ["VP Eng at a public tech co", "serial startup CTO"]

# ... archetypes per domain (2–4 each): a high-variance one + a steady one at least
```

### 4.4 Names & tuning
- `_names.toml` — first/last name pools + flavor-bio fragments for procedural generation (like procedural companies).
- `_tuning.toml`:
```toml
[global]
candidate_pool_size = 6          # execs visible in the market at once
market_refresh_weeks = 26        # how often the pool rotates
headhunt_cost = 20               # $M to surface a better candidate
[comp]
base_salary_by_competence = 0.05 # $M/yr per competence point (a 90-comp exec ≈ $4.5M/yr)
equity_expectation_range = [0.005, 0.03]  # 0.5%–3% equity, scaled by competence/traits
[retention]
underpay_defection_per_quarter = 0.08     # base defection chance when underpaid
star_poach_multiplier = 2.0
fire_morale_hit = 0.1
```

---

## Part 5 — Validation checklist

- [ ] Every archetype's `domain` is a real domain id.
- [ ] Every trait in an archetype `trait_pool` is a real trait id; trait `applies_to` (if set) includes that archetype's domain.
- [ ] Every domain's `gates_megaprojects` ids resolve to real megaprojects (`10`) — and conversely every `10` `exec_required` value is a real domain id (bidirectional).
- [ ] Each domain has ≥2 archetypes, including at least one high-variance and one steady (so the character choice exists at every domain).
- [ ] `competence_range` within [0,100], low < high; `trait_count` low ≤ high ≤ pool size.
- [ ] `_tuning.toml` present with global/comp/retention blocks.

---

## Part 6 — What I (Claude) build — not authoring

- The exec engine: the autonomous decision model (mandate → execute → escalate), competence/trait modifiers applied to the existing R&D/finance/ops/market systems, the override path.
- The generator (archetypes + traits + names → procedural exec candidates, stature-gated).
- The hiring market, comp/equity (cap-table integration), retention/defection/poaching, firing/morale, exec clashes + their events.
- The megaproject `exec_required` gate check (`10`) against the seated exec.
- The Executives/Divisions UI (the team, the market, each exec's domain + mandate + escalations) in the `UI_LANGUAGE.md` language.
- Loader + Part 5 validation (incl. the bidirectional domain↔megaproject check) → `ContentDB.warnings`.

---

## Part 7 — Suggested authoring order

1. **`_domains.toml`** — the 7 domains first (they're the spine; the `gates_megaprojects` here clear the `10` `exec_required` warnings).
2. **`_traits.toml`** — ~8–12 traits (the personality vocabulary).
3. **`archetypes.toml`** — 2–4 per domain (≈18–28 total), each a real character template with a competence range and trait pool. Ensure every domain has a high-variance and a steady option.
4. **`_names.toml`** + **`_tuning.toml`** — the generation pools and the market/comp/retention knobs.

The feel to aim for: a player reading their leadership roster should see *people* — a visionary CTO they're nervous about, a steady CFO they trust, a star they're scared of losing — not a list of stat blocks. Executives are where the company stops being a spreadsheet and becomes a team you lead.
