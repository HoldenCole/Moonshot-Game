# Moonshot Inc — Expansion Infrastructure: Design & Authoring (Foundations)

*The late-game capital-deployment catalog — the "ways to spend trivial money" system from `08` §6. Headquarters, research campuses, talent institutions, a lobbying arm, a brand machine. Each is a permanent buildout that grants capability buffs, **the slots other systems need** (research `09`, megaprojects `10`), and prestige. This doc is **foundations only** — the system, schema, and authored content. The UI surface is deliberately deferred to the dedicated UI pass. Conventions: `$M`, weeks, snake_case.*

> **The frame:** by the late game money is trivial (`08` — money's role inverts by design), so the question stops being "can I afford it?" and becomes "what's worth building?" Expansion infrastructure is the answer: enormous, permanent investments that make the *whole empire* stronger — a gleaming HQ, R&D campuses that speed all your research, a corporate university that attracts better executives, a lobbying arm that softens regulation. These aren't products you sell; they're *cathedrals you build to yourself*, part monument and part permanent capability. And critically, they're where the **slots** come from — the scarce concurrency that keeps the late game a game of *choice* even when cash is infinite.

---

## Part 1 — What expansion infrastructure IS

A category of **permanent buildouts** you commit capital to. Unlike a product (sold) or a megaproject (a civilizational endeavor), an infrastructure buildout is an *internal investment in your own company's capability* — it makes you permanently better at something, and it stays built.

**The mental model:** these are the **institutions of a great company** — the headquarters, the labs, the university, the government-affairs office, the brand. Real giants build them as they scale, and they compound: a better HQ attracts better people, who do better research, in better labs. Expansion infrastructure is that compounding made mechanical.

**Each buildout grants some mix of:**
- **Slots** — the big one. Research project slots (`09`), megaproject slots (`10`), and bet/concurrency. *This is how the slot economy expands.* The systems that gate on "how many can you run at once" get their headroom from infrastructure.
- **Permanent capability buffs** — R&D speed, operating-cost reduction, talent/exec quality, market share, capacity.
- **Prestige** — stature and/or power contribution (a landmark HQ, a famous institute — these make you *matter* beyond their mechanical effect).
- **System hooks** — a lobbying arm feeds the power/contracts axis (`16`/`17`); a brand machine feeds reputation/share.

**Tiered.** Most types have tiers (HQ I → II → III → landmark), so there's always a next buildout to pour money into, each bigger and more impactful than the last. That's what keeps the trivial-money late game from going hollow — an endless ladder of *meaningful* spend.

---

## Part 2 — Why it exists (the purpose)

- **It's the primary sink for trivial late-game money.** `08` §6 names this as the anti-hollow catalog: when cash is infinite, you need *enormous, worthwhile things to spend on*. Infrastructure is the steady backbone of that (megaprojects are the spectacular peaks; infrastructure is the always-available ladder). Without it, "money is easy late-game" becomes "money is pointless late-game."
- **It's where the slots come from — the scarcity that keeps the late game strategic.** Research (`09`) and megaprojects (`10`) are slot-limited *on purpose*, so even infinite money can't let you do everything at once. Infrastructure is how you *buy more concurrency* — which makes "what do I build to expand my capacity to act?" a core late-game decision. The constraint shifts from money to slots, and infrastructure is the lever on slots.
- **It makes spending a strategic choice, not a bigger number.** Each buildout is a *tradeoff* — an R&D campus speeds research but a production complex adds capacity; you can't build everything at once (build slots + capital-at-once + stature gates). So even though money is easy, *which* infrastructure to prioritize is a real decision shaped by your strategy.
- **It compounds the empire.** Infrastructure buffs stack with synergies (`14`) and sub-economy outputs (`13`) — a research campus + the AGI research-speed synergy + a discovery-engine sub-economy together make your R&D untouchable. Infrastructure is the *owned, permanent* layer of the compounding machine.
- **It's the monument layer.** A landmark HQ, a world-famous institute — these are how a titan expresses scale *to itself and the world*. Part of the power fantasy is building things that say "we are colossal." Prestige effects (stature/power) capture that.

**Design rule — every buildout is a meaningful choice, never a strict upgrade you'd always take.** Tradeoffs (this type vs. that), scarcity (build slots, capital-at-once), and stature gates ensure you're *choosing* what to build, not just buying everything in order. Money is easy; *focus* is not.

---

## Part 3 — How it works (the mechanics)

### 3.1 Buildouts and tiers
Each infrastructure **type** (headquarters, rd_campus, etc.) has **tiers**. You build tier 1, then can upgrade to tier 2, etc. Each tier: a **cost** (`$M`), a **build time** (`weeks`), a **stature gate** (when it becomes available), and **permanent effects** that replace the prior tier's (upgrading, not stacking duplicates). Some types you can build **multiple of** (three R&D campuses); others are **singular** (one headquarters, upgraded in place).

### 3.2 Build concurrency
You can build only **N infrastructure projects at once** (an infrastructure build slot, small — 1–2, raised by… infrastructure). Even with infinite money, you build the empire *deliberately*, one or two cathedrals at a time. This is the scarcity that makes it a choice.

### 3.3 Effects vocabulary
Permanent effects (applied on completion, replacing prior tier):
- `research_slots`, `megaproject_slots`, `bet_slots`, `infra_slots` — **slot grants** (the headline capability).
- `rd_speed_mult`, `opex_mult`, `capacity_bonus`, `talent_quality`, `exec_quality`, `share_bonus`, `retention_bonus` — capability buffs.
- `stature_bonus`, `power_bonus` — prestige.
- `regulation_relief`, `influence_bonus` — power-axis hooks (lobbying arm).
These are engine-known modifiers applied to the systems that already exist (same philosophy as execs/synergies — a layer over the running engine).

### 3.4 Connections (what it feeds)
- **Slots → `09` research, `10` megaprojects, the bet scheduler.** Infrastructure is the supply side of the slot economy.
- **Buffs → products/R&D/finance/ops/market.** Permanent multipliers on the core loop.
- **Lobbying arm / think tank → the power axis (`16`/`17`).** `regulation_relief` softens the scrutiny events; `influence_bonus` strengthens lobbying.
- **Talent institution → executives (`12`).** Raises the quality floor of the candidate market.
- **Prestige → stature/power meters (`08`).**

### 3.5 The money-sink shape
Costs scale steeply by tier so they remain *meaningful* spend even as your treasury balloons — a landmark HQ or a flagship institute should cost on the order of a small megaproject. The ladder is endless enough (tiers + multiple-of types) that there's always a worthwhile next buildout, but gated (stature + slots + capital-at-once) so it's paced, not a shopping spree.

---

## Part 4 — What you author

**Drop-in path:** `content/infrastructure/<type>.toml` (one per type) + `content/infrastructure/_tuning.toml`.

```toml
# content/infrastructure/headquarters.toml
[headquarters]
id = "headquarters"
name = "Corporate Headquarters"
singular = true                  # one HQ, upgraded in place (vs. multiple-of)
category = "prestige"            # prestige | research | production | talent | influence | brand
description = """The seat of the empire. More than offices — a statement of scale, \
a magnet for talent, and the nerve center everything is run from. Each expansion \
says, to the world and to your own people, how far you've come."""

[[headquarters.tiers]]
tier = 1
name = "Headquarters"
stature_min = 0
cost = 30
weeks = 26
effects = { exec_quality = 0.05, retention_bonus = 0.05 }

[[headquarters.tiers]]
tier = 2
name = "Corporate Campus"
stature_min = 8000
cost = 150
weeks = 52
effects = { exec_quality = 0.1, retention_bonus = 0.1, stature_bonus = 1000 }

[[headquarters.tiers]]
tier = 3
name = "Global Headquarters Tower"
stature_min = 25000
cost = 600
weeks = 90
effects = { exec_quality = 0.15, retention_bonus = 0.15, stature_bonus = 4000, infra_slots = 1 }

[[headquarters.tiers]]
tier = 4
name = "Landmark Arcology"
stature_min = 60000
cost = 2000
weeks = 130
effects = { exec_quality = 0.2, retention_bonus = 0.2, stature_bonus = 12000, power_bonus = 1, infra_slots = 1 }
```

### Field reference
- **`singular`** — true = one of these, upgraded in place; false = build multiple instances.
- **`category`** — for grouping (and the deferred UI).
- **`tiers`** — ordered; each has `stature_min` (availability gate), `cost`, `weeks`, and `effects` (which *replace* the prior tier on a singular type).
- **`effects`** — engine-known modifier keys (§3.3).

---

## Part 5 — The authored content

### 5.1 `headquarters.toml` — above (the monument + exec/retention buffs + infra slots)

### 5.2 `rd_campus.toml` — research speed + research slots (multiple-of)
```toml
[rd_campus]
id = "rd_campus"
name = "R&D Campus"
singular = false                 # build several
category = "research"
description = """A dedicated research campus — labs, talent, and the freedom to \
pursue the frontier. Each one speeds your research and widens how many programs you \
can run at once. The physical foundation of a technological lead."""

[[rd_campus.tiers]]
tier = 1
name = "Research Campus"
stature_min = 4000
cost = 80
weeks = 44
effects = { rd_speed_mult = 1.08, research_slots = 1 }

[[rd_campus.tiers]]
tier = 2
name = "Advanced Research Institute"
stature_min = 15000
cost = 280
weeks = 70
effects = { rd_speed_mult = 1.15, research_slots = 1, talent_quality = 0.1 }

[[rd_campus.tiers]]
tier = 3
name = "Frontier Research City"
stature_min = 35000
cost = 900
weeks = 100
effects = { rd_speed_mult = 1.25, research_slots = 1, talent_quality = 0.15, stature_bonus = 3000 }
```

### 5.3 `production_complex.toml` — capacity + opex (multiple-of)
```toml
[production_complex]
id = "production_complex"
name = "Production Complex"
singular = false
category = "production"
description = """An integrated manufacturing and operations complex — gigafabs, \
assembly lines, mission-control floors. It raises your capacity ceiling and drives \
the cost of running everything down through sheer scale and integration."""

[[production_complex.tiers]]
tier = 1
name = "Production Complex"
stature_min = 5000
cost = 100
weeks = 48
effects = { capacity_bonus = 0.1, opex_mult = 0.95 }

[[production_complex.tiers]]
tier = 2
name = "Megafactory"
stature_min = 16000
cost = 350
weeks = 72
effects = { capacity_bonus = 0.2, opex_mult = 0.9, bet_slots = 1 }

[[production_complex.tiers]]
tier = 3
name = "Industrial Megacomplex"
stature_min = 38000
cost = 1100
weeks = 105
effects = { capacity_bonus = 0.3, opex_mult = 0.85, bet_slots = 1, megaproject_slots = 1 }
```

### 5.4 `talent_institution.toml` — better execs/talent (singular)
```toml
[talent_institution]
id = "talent_institution"
name = "Corporate University"
singular = true
category = "talent"
description = """A university and leadership academy of your own — training your \
people, drawing the best in the world, and grooming the executives who will run the \
empire. The institution that turns a company into a dynasty of talent."""

[[talent_institution.tiers]]
tier = 1
name = "Training Academy"
stature_min = 6000
cost = 70
weeks = 44
effects = { talent_quality = 0.1, exec_quality = 0.05 }

[[talent_institution.tiers]]
tier = 2
name = "Corporate University"
stature_min = 18000
cost = 260
weeks = 66
effects = { talent_quality = 0.18, exec_quality = 0.12, retention_bonus = 0.1 }

[[talent_institution.tiers]]
tier = 3
name = "World-Renowned Institute"
stature_min = 40000
cost = 800
weeks = 95
effects = { talent_quality = 0.25, exec_quality = 0.2, retention_bonus = 0.15, stature_bonus = 2500 }
```

### 5.5 `brand_machine.toml` — reputation + market share (singular)
```toml
[brand_machine]
id = "brand_machine"
name = "Brand & Communications"
singular = true
category = "brand"
description = """A world-class brand, marketing, and communications operation — the \
machine that makes your name mean something. It lifts your market share, cushions \
your reputation when things go wrong, and turns the company into a cultural force."""

[[brand_machine.tiers]]
tier = 1
name = "Brand Studio"
stature_min = 3000
cost = 50
weeks = 36
effects = { share_bonus = 0.05, reputation_floor = 0.05 }

[[brand_machine.tiers]]
tier = 2
name = "Global Brand Operation"
stature_min = 14000
cost = 200
weeks = 58
effects = { share_bonus = 0.1, reputation_floor = 0.1 }

[[brand_machine.tiers]]
tier = 3
name = "Cultural Institution"
stature_min = 32000
cost = 650
weeks = 85
effects = { share_bonus = 0.15, reputation_floor = 0.15, stature_bonus = 2000 }
```

### 5.6 `lobbying_arm.toml` — power axis hooks (singular)
```toml
[lobbying_arm]
id = "lobbying_arm"
name = "Government Affairs Office"
singular = true
category = "influence"
description = """A standing government-affairs and lobbying operation — the \
permanent machinery of influence. It softens the regulation that comes for every \
giant, strengthens your hand when you choose to lobby, and quietly keeps the state \
on your side. The institutional form of power."""

[[lobbying_arm.tiers]]
tier = 1
name = "Government Affairs Office"
stature_min = 10000
cost = 90
weeks = 44
effects = { regulation_relief = 0.1, influence_bonus = 0.1 }

[[lobbying_arm.tiers]]
tier = 2
name = "Policy & Influence Division"
stature_min = 24000
cost = 320
weeks = 64
effects = { regulation_relief = 0.18, influence_bonus = 0.2, power_bonus = 1 }

[[lobbying_arm.tiers]]
tier = 3
name = "Statecraft Operation"
stature_min = 50000
cost = 950
weeks = 90
effects = { regulation_relief = 0.25, influence_bonus = 0.3, power_bonus = 2 }
```

### 5.7 `think_tank.toml` — research + influence blend (singular)
```toml
[think_tank]
id = "think_tank"
name = "Institute for the Future"
singular = true
category = "influence"
description = """A prestigious research institute and think tank under your banner — \
shaping the intellectual climate, the policy debate, and the public's sense of \
what's possible. Soft power and hard research at once: it speeds your own work and \
bends the conversation your way."""

[[think_tank.tiers]]
tier = 1
name = "Research Foundation"
stature_min = 12000
cost = 110
weeks = 50
effects = { rd_speed_mult = 1.05, influence_bonus = 0.1, reputation_floor = 0.05 }

[[think_tank.tiers]]
tier = 2
name = "Institute for the Future"
stature_min = 30000
cost = 400
weeks = 75
effects = { rd_speed_mult = 1.1, influence_bonus = 0.2, reputation_floor = 0.1, stature_bonus = 2500 }
```

### 5.8 `_tuning.toml`
```toml
# content/infrastructure/_tuning.toml
[global]
starting_infra_slots = 1         # infrastructure builds you can run at once
max_infra_slots = 3              # ceiling (raised by HQ tier 3+, which grant infra_slots)
# Slot grants from buildouts (research_slots, megaproject_slots, bet_slots) feed the
# respective system slot pools (09 / 10 / bet scheduler). Engine sums and clamps to
# those systems' own max caps (e.g. research max_slots = 5 from 09).
[caps]
# Global ceilings so infrastructure buffs stack but don't spiral (with synergies 14).
max_rd_speed_from_infra = 1.5
min_opex_from_infra = 0.7
max_talent_quality = 0.4
```

---

## Part 6 — Validation / authoring notes
- [ ] Each type's tiers are ordered with ascending `stature_min`, `cost`, `weeks`.
- [ ] `singular` types upgrade in place (effects replace); multiple-of types can repeat.
- [ ] Effect keys are engine-known (§3.3); slot grants (`research_slots`/`megaproject_slots`/`bet_slots`) feed the right system.
- [ ] `category` is one of prestige | research | production | talent | influence | brand.
- [ ] Slot totals respect the downstream systems' caps (research max 5 from `09`, megaproject max 3 from `10`).
- [ ] `_tuning.toml` present with infra slots + the anti-spiral caps.
- [ ] 7 types authored (headquarters, rd_campus, production_complex, talent_institution, brand_machine, lobbying_arm, think_tank).

## Part 7 — What I (Claude) build — not authoring
- The infrastructure engine: buildout commitment (cost/weeks, infra build-slot occupation), tier upgrades (replace prior effects), singular-vs-multiple handling.
- Slot accounting: summing `research_slots`/`megaproject_slots`/`bet_slots`/`infra_slots` into the respective pools, clamped to each system's cap.
- Permanent buff application to products/R&D/finance/ops/market/execs (the modifier layer), with the anti-spiral caps.
- Power-axis hooks: `regulation_relief` into the scrutiny events (`17`), `influence_bonus` into lobbying.
- Stature/power prestige contributions.
- **The Infrastructure UI** — deferred to the UI pass (this doc is foundations only). When built: the buildout catalog, what's built/upgradeable, slot accounting visible, in the `UI_LANGUAGE.md` language.
- Loader + Part 6 validation → `ContentDB.warnings`.

## Part 8 — How this completes the spend catalog
With infrastructure authored, `08` §6's "ways to spend" catalog is materially complete: **acquisitions** (M&A — an engine feature, not authored content), **megaprojects** (`10`), **synergy buys** (build/acquire the pieces — driven by `09`/`13`/`14`), **influence/lobbying** (`16`/`17` + the lobbying arm here), **talent/exec wars** (`12` + the talent institution here), and now **expansion infrastructure** (this doc). The trivial-late-game money has a deep, tiered, strategic set of sinks — and the slot grants here are the supply side of the concurrency scarcity that keeps it all a game of choice. The late game is a capital-deployment game with plenty to deploy into.

> **Foundations complete.** This closes the last content/design gap from the `08` audit. Every system the north-star sketched now exists as authored, validated content or a specced engine feature. What remains is the **UI system** (the phase-evolving command center, the new tabs — Executives, R&D, Megaprojects, Contracts, Power, Synergy, Infrastructure — and the reframed home screen) and the **engine build**. The UI is the next pass, as planned.
