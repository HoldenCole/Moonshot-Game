# Moonshot Inc — R&D Tree: Authoring Spec

*The deepened research system — the foundational block of the late-game vision (`08`, block 1). Everything else (megaprojects, synergies, power, expansion) gates on this. It **extends** the `rd_lines` you already authored in `06`; it does not replace them. Same conventions: `$M`, weeks, snake_case ids, drop-in TOML, validation checklist, content/code boundary.*

> **What's new vs. `06`:** `06` gave each sub-industry 2–4 **R&D lines** (continuous tech levels that gate products). This spec keeps those and adds three layers on top: **research projects** (discrete unlockable nodes — the bulk of the authoring), **frontier programs** (prestige nodes that gate the civilizational tier), and **cross-domain projects** (nodes that only matter once you span fronts — the research that *is* synergy). Plus **project slots** (how many you can run at once). Together these turn "three sliders" into a real tree that reaches from "better GPU" to "AGI / Mars / fusion."

---

## What you're authoring (per sub-industry, all 6)

| # | What | File | Notes |
|---|---|---|---|
| 1 | **R&D lines** (existing) | `content/rd_lines/<sub>.toml` | already authored in `06` — keep; optionally extend level ceilings |
| 2 | **Research projects** | `content/research/<sub>.toml` | NEW — the many nodes; the bulk of the work |
| 3 | **Frontier programs** | `content/research/<sub>.toml` (same file, `tier = "frontier"`) | NEW — prestige gates to the megaproject tier |
| 4 | **Cross-domain projects** | `content/research/_cross_domain.toml` | NEW — one shared file; synergy research |
| 5 | **Slot rules** | `content/research/_tuning.toml` | NEW — project slots + pacing per sub-industry |

Six sub-industries: `frontier_model_lab`, `vertical_ai_saas`, `ai_chips`, `launch_services`, `satellite_constellations`, `space_stations`.

**Timing in weeks. Money in `$M`. Ids global snake_case.**

---

## The model (so the fields make sense)

Three layers, one engine:

1. **R&D lines** (from `06`) — continuous tech levels (0–100+) that rise with allocated budget. The *foundation layer*. Unchanged.
2. **Research projects** — discrete nodes you commit to (a **bet**, like a product build): they cost money, take weeks, occupy a **project slot**, and on completion **unlock** something (a product archetype, a capability bonus, a line-ceiling raise, a synergy, or a gate toward a frontier program). The **two-stage gate** (from Terra Invicta): a project becomes *available* when its prerequisites are met (industry breakthrough), but you must actually *develop* it (the private program) to get the benefit. Being first = dominance.
3. **Frontier programs** — the prestige nodes at the top of each tree: enormous, slow, gated behind high line levels + prerequisite projects + stature. They unlock the **megaproject tier** (`08` §7.2) and the **power** jumps. This is where "deepen R&D" reaches the stars.

**Project slots:** you can only run N research projects at once. Slots start low (1–2) and increase via expansion infrastructure (`08` §6) and certain projects themselves. This makes "what do I research now" a real scarcity decision even when money is plentiful.

---

## 1. R&D Lines — small extension to `06`

Keep your authored lines as-is. One optional addition: a `level_ceiling` so frontier programs can require pushing a line past the normal product-gating range.

```toml
# content/rd_lines/ai_chips.toml  (existing — add the one field if you want frontier gating)
[process_node]
# ... all existing fields from 06 ...
level_ceiling = 130          # NEW (optional): how high this line can be pushed.
                             # normal products gate <=70; frontier programs can require 90+.
```
If omitted, the engine defaults `level_ceiling = 100`. Author this only where a frontier program needs a line pushed into prestige range.

---

## 2. Research Projects — `content/research/<sub>.toml`

The bulk of the authoring. Each project is a node. **Author many** — aim for ~10–18 per sub-industry across tiers so research never runs dry. Schema:

```toml
# content/research/ai_chips.toml
[chiplet_packaging]
id = "chiplet_packaging"
sub_industry = "ai_chips"
name = "Chiplet packaging"
tier = "applied"               # "applied" (early/mid) | "advanced" (mid/late) | "frontier" (§3)
description = """Stitching multiple smaller dies into one package instead of betting \
on a single monolithic chip. Sidesteps the yield cliff at the bleeding edge and \
lets you scale performance when the node alone can't. The architecture the whole \
industry is converging on."""
icon = "grid-dots"

[chiplet_packaging.requires]   # the two-stage gate: what makes this AVAILABLE
rd_levels = { yield_line = 45, architecture = 40 }   # line tech levels required
projects = []                                         # prerequisite project ids (none here)
stature_min = 0                                       # market-cap gate ($M); 0 = none

[chiplet_packaging.cost]
budget = 35                    # $M to develop
weeks = 40                     # duration (occupies a project slot the whole time)

[chiplet_packaging.unlocks]
# any combination of these effect kinds; engine applies on completion:
products = ["chiplet_accelerator"]        # product archetype ids this makes buildable
line_ceiling = {}                          # e.g. { architecture = 110 } to raise a cap
capability = { yield_bonus = 0.1 }         # named, engine-known capability modifiers
synergy_tags = []                          # synergy hooks (see §4)
frontier_unlock = []                       # frontier program ids this is a prereq for

[advanced_lithography]
id = "advanced_lithography"
sub_industry = "ai_chips"
name = "Advanced lithography"
tier = "advanced"
description = """In-house mastery of the most extreme ultraviolet processes — the \
hardest, most expensive step in chipmaking, controlled by almost no one. Owning it \
means you no longer wait in anyone's queue and your node leadership is structural."""
icon = "wave-sine"

[advanced_lithography.requires]
rd_levels = { process_node = 65 }
projects = ["chiplet_packaging"]
stature_min = 8000             # $8B — only a serious company attempts this

[advanced_lithography.cost]
budget = 120
weeks = 78

[advanced_lithography.unlocks]
products = []
line_ceiling = { process_node = 130 }      # lets you push the node into frontier range
capability = { node_leadership = 0.15 }
synergy_tags = ["owns_advanced_fab"]       # other fronts can read this (AI gets cheaper compute)
frontier_unlock = ["sentient_compute_substrate"]
```

**Field notes:**
- `tier` — `applied` (early/mid, cheap/fast, gates products & small bonuses), `advanced` (mid/late, bigger, gates synergies & ceilings), `frontier` (§3).
- `requires` — the two-stage gate. `rd_levels` (line tech), `projects` (prereq nodes — this is what makes it a *tree*), `stature_min` (market-cap $M; keeps the big nodes out of early reach).
- `cost.weeks` — occupies a project slot the whole time (slot scarcity = §5).
- `unlocks` — the payoff. Mix and match: make products buildable, raise a line ceiling, grant a named capability modifier, expose a `synergy_tag` other fronts read, or serve as a prereq toward a frontier program. **Every project must unlock *something*.**

**Author ~10–18 per sub-industry**, forming a connected tree (early nodes with no prereqs → mid nodes requiring them → a few advanced nodes → pointing at frontier programs). Give each a characterful description — research nodes are where the fiction of "what your company is pioneering" lives.

---

## 3. Frontier Programs — the prestige tier (same file, `tier = "frontier"`)

The top of each tree. Enormous, slow, gated hard. These unlock the **megaproject tier** and drive **power** jumps. Author **2–4 per sub-industry.** Same schema as a project, plus a `megaproject_unlock` and usually a `power` effect.

```toml
[sentient_compute_substrate]
id = "sentient_compute_substrate"
sub_industry = "ai_chips"
name = "Neuromorphic compute substrate"
tier = "frontier"
description = """A fundamentally new computing architecture — brain-like, massively \
parallel, orders of magnitude more efficient for intelligence workloads. The \
hardware foundation a true artificial general intelligence would run on. A handful \
of labs on Earth could even attempt it; you intend to be the one that finishes."""
icon = "brain"

[sentient_compute_substrate.requires]
rd_levels = { process_node = 95, architecture = 90 }
projects = ["advanced_lithography"]
stature_min = 25000            # $25B — a titan-tier endeavor

[sentient_compute_substrate.cost]
budget = 600
weeks = 150                    # multi-year

[sentient_compute_substrate.unlocks]
products = []
capability = { ai_compute_efficiency = 0.4 }
synergy_tags = ["agi_capable_hardware"]      # the AGI megaproject reads this as a prerequisite
megaproject_unlock = ["artificial_general_intelligence"]   # gates a megaproject (08 §7.2)
power = 1                       # completing it raises strategic importance / power meter
```

**Field notes:**
- `megaproject_unlock` — the frontier program is the *research prerequisite* for a megaproject (the megaprojects themselves are authored in their own spec later, per `08` §11; here you just reference the id this program gates).
- `power` — a small power-meter bump on completion (you've done something civilization-relevant). The full power system is `08` §4; here it's just a hook.
- Frontier programs should require pushing lines past 90 (hence the optional `level_ceiling` in §1) and usually a `stature_min` in the billions — they're explicitly titan-only.

**Author 2–4 per sub-industry**, each pointing at a megaproject or a major power/synergy payoff. These are the "reach for the stars" nodes — the reason to deepen R&D at all.

---

## 4. Cross-Domain Projects — `content/research/_cross_domain.toml`

The research that *is* synergy — nodes that only become available once you operate in **multiple** sub-industries, and whose payoff is a cross-front bonus. One shared file. Author ~6–10 total.

```toml
# content/research/_cross_domain.toml
[ai_designed_silicon]
id = "ai_designed_silicon"
name = "AI-designed silicon"
description = """Turn your own models loose on chip design — let the AI explore the \
architecture space no human team could. Only possible if you run both a frontier \
lab and a chip operation, and it makes each one better than it could ever be alone."""
icon = "circuit"

[ai_designed_silicon.requires]
# requires presence + tech in TWO fronts (this is what makes it cross-domain)
fronts = ["frontier_model_lab", "ai_chips"]
rd_levels = { scaling = 50, architecture = 50 }   # lines from either front
projects = []
stature_min = 12000

[ai_designed_silicon.cost]
budget = 90
weeks = 60

[ai_designed_silicon.unlocks]
capability = { chip_rd_speed = 0.25, ai_rd_speed = 0.1 }   # both fronts benefit
synergy_tags = ["ai_chip_codesign"]
```

**Field notes:**
- `requires.fronts` — the list of sub-industries you must *operate in* for this to be available. This is the gate that rewards expanding across areas as one titan.
- `unlocks.capability` — typically buffs *both* contributing fronts (the synergy made mechanical and explicit, per `08` §8).
- These are the connective tissue of the empire. Author them to reward the natural integration paths (AI+chips, launch+satellite, launch+space, energy+everything).

---

## 5. Slot Rules & Pacing — `content/research/_tuning.toml`

How many projects run at once, and per-sub-industry research pacing. One file, keyed by sub-industry plus a global block.

```toml
# content/research/_tuning.toml
[global]
starting_slots = 1             # research projects you can run at once at game start
max_slots = 5                  # ceiling (more unlocked via expansion infra / projects)
# slot sources beyond starting: certain projects grant +1 (unlocks.capability.slot = 1),
# and expansion-infrastructure buildouts (08 §6) grant slots — engine sums them.

[frontier_model_lab]
rd_pace_mult = 1.0             # multiplier on all this sub's project durations (fast-moving field)
budget_mult = 1.0             # multiplier on all this sub's project budgets
frontier_stature_floor = 20000 # $M below which NO frontier program in this sub is available

[ai_chips]
rd_pace_mult = 1.4             # chips research is slow
budget_mult = 1.3
frontier_stature_floor = 25000

[launch_services]
rd_pace_mult = 1.1
budget_mult = 1.2
frontier_stature_floor = 22000

# ... vertical_ai_saas, satellite_constellations, space_stations
```

**Author all six sub-industry blocks** plus the global. The `rd_pace_mult` / `budget_mult` let you tune each field's research *feel* (chips slow + dear, SaaS fast + cheap) without touching individual nodes — same pattern as the products `_tuning.toml`.

---

## Per-sub-industry tree sketches (what to aim for)

A starting shape for each tree so they're distinct and each reaches a frontier/megaproject. You flesh out the nodes; these are the spines:

- **frontier_model_lab** → applied (better training, multimodal, agents) → advanced (autonomous research, self-improvement) → **frontier: Artificial General Intelligence** (the marquee — gates the AGI megaproject, huge power). The tree that reaches furthest.
- **ai_chips** → applied (chiplets, specialized accelerators) → advanced (in-house lithography, node leadership) → **frontier: neuromorphic substrate** (gates AGI hardware; synergy with the lab).
- **vertical_ai_saas** → applied (deeper domain models, platform) → advanced (autonomous workflows, industry OS) → **frontier: become the system-of-record for an entire industry** (power via economic indispensability rather than space).
- **launch_services** → applied (reusability, cadence) → advanced (full reuse, heavy-lift, in-space refueling) → **frontier: routine interplanetary transport** (gates Moon/Mars megaprojects).
- **satellite_constellations** → applied (mass production, inter-sat links) → advanced (global broadband, real-time earth obs) → **frontier: orbital industrial base / in-space manufacturing** (gates asteroid mining; synergy with launch).
- **space_stations** → applied (modules, life support) → advanced (large stations, closed-loop life support) → **frontier: self-sustaining off-world habitation** (gates Moon/Mars colonies; the life-support tree the colonies need).

Note how frontier nodes **cross-reference**: AGI needs both the lab's program *and* chips' neuromorphic substrate; Mars needs launch's interplanetary transport *and* space's closed-loop habitation. That cross-gating is what makes spanning fronts the path to the biggest endeavors — author the frontier `requires.projects` / synergy_tags to reflect it.

---

## Validation checklist (engine enforces; mirror in the loader)

- [ ] Every `requires.rd_levels` key is a real line id in that sub-industry (or, for cross-domain, in one of its `fronts`).
- [ ] Every `requires.projects` id resolves to a real project (no dangling prereqs); the prereq graph is **acyclic** (no loops).
- [ ] Every `unlocks.products` id is a real product archetype in that sub-industry.
- [ ] Every `unlocks.line_ceiling` / `requires.rd_levels` above 100 has a matching `level_ceiling` on that line (else unreachable).
- [ ] Every `megaproject_unlock` id is referenced (will validate fully once megaprojects are authored).
- [ ] Cross-domain `requires.fronts` lists ≥2 real sub-industries.
- [ ] Every project `unlocks` *something* (no dead nodes).
- [ ] Every tree has ≥1 reachable `frontier` node from the starting state (given enough time/money/stature).
- [ ] `_tuning.toml` has all six sub-industry blocks + global.
- [ ] No project is unreachable (its prereq chain bottoms out at nodes with no `projects` prereq).

---

## What I (Claude) build — not authoring

- The research engine: project commitment, slot accounting, the two-stage availability check (rd_levels + projects + stature), duration/budget with `_tuning` multipliers, completion → apply `unlocks`.
- The prereq-graph resolver + the acyclic/reachability validation above, in the loader (pushing problems to `ContentDB.warnings`).
- The capability-modifier system (named bonuses like `node_leadership`, `chip_rd_speed`) and how they feed the existing product/R&D math.
- Slot sources (starting + projects + expansion infra) summed into available slots.
- The Research UI (the tree view, available/in-progress/locked nodes, slot indicator) in the `UI_LANGUAGE.md` language.
- The hooks for `megaproject_unlock`, `power`, and `synergy_tags` (the systems they feed are later blocks; this spec just defines the data they read).

---

## Suggested authoring order

1. **`_tuning.toml`** — set the six pacing blocks + slots first (frames everything).
2. **`ai_chips` + `frontier_model_lab`** full trees (applied → advanced → frontier) — max contrast, and they share the AGI cross-gate so you'll see the tree interlock.
3. **The other four** sub-industry trees, copying the pattern.
4. **`_cross_domain.toml`** last — once the per-front trees exist, the synergy nodes have real ids to reference.

Per sub-industry: ~10–18 applied/advanced projects + 2–4 frontier programs, each with a characterful description, a clean prereq chain, and a real unlock. Start with chips (what you're playtesting); it improves the current game the moment the engine lands, well before the rest of `08`.
