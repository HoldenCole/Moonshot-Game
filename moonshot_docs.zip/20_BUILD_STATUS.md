# Moonshot Inc — Build Status & Review Inventory

*The complete state of the late-game systems build, for review. Everything below is in `/mnt/user-data/outputs/` and `content_pack.zip`. Date: 2026-07-02.*

---

## 1. The stack, top to bottom

| Layer | Files | Status |
|---|---|---|
| **Design docs** | `00`–`19` + bible + UI_LANGUAGE | ✅ complete (reconciliation pass pending) |
| **Content (TOML)** | `content/` — **51 files, 8 families** | ✅ all validated, zero errors |
| **Engines (pure TS)** | research, megaprojects, contracts, empire, advisory, executives | ✅ 6 modules |
| **Integration** | content_loader, turn (the turn processor) | ✅ |
| **State** | store.ts (Zustand v5) | ✅ |
| **UI kit** | tokens.ts, components.tsx (contracts-v2 calibration) | ✅ |
| **Tabs** | Home, Contracts, Research, Megaprojects, Empire, Executives, Standing | ✅ 7 assembled |
| **Shell** | App.tsx (tab bar + week/cash/power + End turn) | ✅ |
| **Tests** | sim_test (18/18 on 100% real content), exec_test (10/10), engine suites (25/25 earlier) | ✅ 53 green |

## 2. Content families (all cross-validated)

1. **Research** — the full validated **82-node tree** (42 applied / 21 advanced / 12 frontier / 7 cross-domain), 6 sub files + `_cross_domain` + `_tuning` (six pacing blocks). Prereq graph acyclic; every megaproject_unlock resolves.
2. **Megaprojects** — all **11**, exact validated gates (AGI + Mars two-pillar cross-gates, transit-line prereq, O'Neill needs Mars), stage tables, power payoffs (2→5), 11 legacy victories, 3 repeatables + the pinned repeat curves in `_tuning`.
3. **Sub-economies** — 11 (one per mega), resource production/consumption chains, posture + growth + power tiers.
4. **Synergies** — 20 (13 flow + 7 presence), floors + diminishing curve in `_tuning`.
5. **Contracts** — 17 templates, 5 customers, clearance chain, identity thresholds, market tuning.
6. **Events** — 44 sub-economy events (11 pools) + 17 power/gov events (scrutiny 5 / entanglement 5 / lobbying 3 / sovereignty 4, incl. the legacy victory).
7. **Infrastructure** — 7 expansion types + tuning.
8. **Executives** — 7 domains (domain↔megaproject bidirectional check closed), 8 traits, 14 archetypes (variance + steady per domain), name pools, market/comp/retention tuning.

## 3. What the end-to-end simulation proves (sim_test, 18/18)

A seeded 800-week campaign on **real content only**: climbs the real satellite tree (mass_manufacturing + inter_satellite_links → global_broadband → space_solar_power) → gates + builds the **Orbital Solar Array** (3 real stages) → `space_power` opens → scale grows → clean_energy fills the pool → `abundant_clean_energy` flow synergy activates → contracts pay recurring revenue → power hits **7** → the government-leaning book ends **State-Entangled, entanglement 98** → power events + a sub-economy crisis fire from the real pools. The exec engine (exec_test, 10/10) proves stature-gated generation, comp scaling, one-seat-per-domain, quality feed, fair-pay retention, star poaching, and severance.

## 4. Numbers that are TUNING ANCHORS (not design-locked)

Flagged in file headers/comments; revisit at first playable:
- Research node **budget/weeks** beyond the 4 doc-authored values (tier formulas).
- Sub-economy revenue/upkeep rates beyond the 2 doc examples.
- Contract payments beyond the 4 doc examples.
- `space_program`/`chief_executive` unlock_stature (22000/20000).
- Stage `setback_chance` ramps (0.10 + 0.03·i), catastrophe 0.01.
- 2 reconstructed power events (`oversight_hearing`, `export_control_restriction`) — swap in original prose if preferred.

## 5. Known gaps / deferred (deliberate)

- **Build/Capacity + Capital Overview tabs** — bind to the *existing repo systems* (06/07 products, capacity, finance), not the new engines; assemble when integrating into the Tauri repo.
- **Repo integration** — the new stack is standalone; wiring into the actual game (Tauri/Zustand app, real finance feeding `stature`/`cashM`, products feeding `productTiers`/`rdLevels`) is the next engineering block. `store.ts` needs `zustand@5`.
- **3 old bugs** (07 §8): IPO→fundraise reverts to private; earnings popup stale shape. Untouched, deprioritized.
- **Tier-0 ROI rebalance** — user unconcerned; leave.
- **Doc reconciliation pass** — fold the late-game vision into the bible/01/03.
- **Studio name** — candidates: Heliopause Games, Antapex.
- **Exec mandate→escalate loop** — the generator/hire/retention/quality layer is built; the per-domain autonomous decision AI (mandates, escalations, clashes) is a later engineering block on top of the same data.

## 6. Suggested review order

1. Play the content: `content/megaprojects/megaprojects.toml` + one research file — do the numbers *feel* right?
2. `turn.ts` — the turn order (synergies → research → megas → sub-economies → contracts → power → events).
3. `sim_test.ts` output — the campaign story.
4. The tabs against `capital_contracts.html` (the calibration) — same language everywhere?
5. §4 anchors — mark any you want re-authored now vs. at playtest.
