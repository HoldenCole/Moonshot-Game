# Moonshot Inc — Products, R&D & Capacity: Authoring Spec

*What to author for the depth system. One unified engine; per-industry data. This is the hands-on authoring guide — every file, every field, what it means, and worked examples to copy. Companion to `05_CONTENT_AUTHORING.md` (same conventions: snake_case ids, $M for money, weeks for time, drop-in TOML).*

> **The triangle:** three co-equal systems — **R&D lines** (push tech levels) → gate **Products** (real things you create & grow) → which need **Capacity** (the resource bets & live products consume). Every turn balances the three. The signature bet (training run / tape-out / launch) becomes *the act of creating or upgrading a product*, and you can run **several in parallel**, limited by capacity + budget.

---

## What you're authoring (4 things, all per playable sub-industry)

For each of the **6 playable sub-industries** you author four blocks. Three are new content folders; one is a tuning block.

| # | What | Folder / file | One per |
|---|---|---|---|
| 1 | **R&D lines** | `content/rd_lines/<sub_industry>.toml` | sub-industry (2–4 lines each) |
| 2 | **Product archetypes** (the tech-gated tree) | `content/products/<sub_industry>.toml` | sub-industry (3–5 archetypes each) |
| 3 | **Capacity types** | `content/capacity/<sub_industry>.toml` | sub-industry (1–2 types each) |
| 4 | **Per-industry tuning** | `content/products/_tuning.toml` (keyed by sub-industry) | all six in one file |

Six sub-industries: `frontier_model_lab`, `vertical_ai_saas`, `ai_chips`, `launch_services`, `satellite_constellations`, `space_stations`.

**Timing is in weeks** everywhere (UI humanizes to "~2.5 yrs"). **Money is $M.** Decay/growth are fraction-per-quarter unless noted.

---

## 1. R&D Lines — `content/rd_lines/<sub_industry>.toml`

2–4 concurrent research lines the player splits R&D budget across. Each line has a **tech level** (0–100+, starts low) that rises with sustained funding and **gates products** + lifts their quality. This is the "allocate R&D vs other areas" decision.

```toml
# content/rd_lines/ai_chips.toml
[process_node]
id = "process_node"
sub_industry = "ai_chips"
name = "Process node"
description = """How small you can etch. Each step down — 5nm, 3nm, 2nm — packs more \
compute per watt and is the single biggest driver of whether your silicon is \
competitive. Brutally expensive, slow, and the whole industry is sprinting."""
icon = "chip"
starting_level = 20            # where a new company in this sub-industry begins
# cost-to-progress curve: $M per quarter to advance ~1 level at low levels;
# rises as the level climbs (diminishing returns — see _tuning per-industry)
base_cost_per_quarter = 8
# which product specs this line drives (referenced by product archetypes, §2)
drives_specs = ["performance", "efficiency"]

[architecture]
id = "architecture"
sub_industry = "ai_chips"
name = "Architecture"
description = """Your core design — how the chip is laid out and what it's good at. \
A clever architecture can beat a smaller node. This is where you bet on a \
direction (general-purpose vs. AI-specialized) the market may or may not reward."""
icon = "blueprint"
starting_level = 25
base_cost_per_quarter = 6
drives_specs = ["performance", "specialization"]

[yield_line]
id = "yield_line"
sub_industry = "ai_chips"
name = "Yield & packaging"
description = """How many good chips you get per wafer, and how you package them. \
Unglamorous, but yield is margin. Low yield means you're scrapping silicon and \
bleeding cash on every batch."""
icon = "stack"
starting_level = 30
base_cost_per_quarter = 4
drives_specs = ["margin", "cost"]
```

**Field notes:**
- `starting_level` — sets where a fresh company begins on that line; the gap to the rivals' frontier (defined in market companies' `quality`) is the climb.
- `base_cost_per_quarter` — the *anchor* cost to push the line; the real curve (diminishing returns, frontier-pull) is computed by the engine using the per-industry tuning (§4). You just set the anchor.
- `drives_specs` — free-form spec tags that product archetypes (§2) reference. A product's quality in a given spec = function of the tech levels of the lines that drive it. Keep tags consistent within a sub-industry.

**Author 2–4 lines per sub-industry.** Make them a real *vs.* — they should pull in different directions so the player can't fund all of them and must choose a strategy (e.g. chase the node vs. perfect yield vs. bet on architecture).

---

## 2. Product Archetypes — `content/products/<sub_industry>.toml`

The tech-gated tree of **real things** you create: GPUs, AI models, rockets, satellites. Each archetype is a rung the player unlocks (by hitting tech-level gates) and then **instantiates** — the player names each instance ("the H-2 accelerator"), but the archetype gives it character, specs, economics, and lifecycle. This is the "creating new products" system and the cure for "the business is vague."

```toml
# content/products/ai_chips.toml
[consumer_gpu]
id = "consumer_gpu"
sub_industry = "ai_chips"
name = "Consumer GPU"
tier = 1                        # tree depth; tier 1 = available early
description = """A graphics card for gamers and creators. Your entry product — \
lower margins, huge volume, and a brand-building beachhead. The training wheels \
of silicon: it teaches your fab to walk before you bet the company on datacenter parts."""
flavor_naming_hint = "e.g. 'GX-1', 'Vega', a number+letter consumer brand"

[consumer_gpu.gates]            # tech levels required to UNLOCK creating this
process_node = 15
architecture = 20

[consumer_gpu.economics]        # $M and fractions; engine blends with tech levels
build_cost = 40                 # one-time cost to create (the "tape-out" bet cost)
build_weeks = 60                # how long the bet runs before it ships (per-industry feel)
unit_margin = 0.35              # gross margin at launch (decays as it ages)
capacity_type = "fab_line"      # which capacity it consumes (see §3)
capacity_to_build = 1           # capacity units tied up DURING the build bet
capacity_to_run = 1             # capacity units a SHIPPED product occupies while live
addressable_market = 1200       # $M/yr ceiling this product class can capture
ramp_weeks = 26                 # weeks from ship to peak revenue
decay_per_quarter = 0.04        # how fast it obsolesces once mature (low = workhorse)

[consumer_gpu.specs]            # 0–100 each; the engine fills actuals from tech levels
# These are the WEIGHTS for how each R&D line's level maps to this product's quality.
performance = 0.5
efficiency = 0.3
margin = 0.2

[datacenter_accel]
id = "datacenter_accel"
sub_industry = "ai_chips"
name = "Datacenter accelerator"
tier = 2
description = """The product that makes empires. Sold by the rack to AI labs and \
clouds, priced like jewelry, and the thing OpenMind and the hyperscalers are \
desperate for. Demands a real process node and flawless yield — and the AI-hype \
cycle can make or unmake it overnight."""
flavor_naming_hint = "e.g. 'H-series', 'Hopper-class', a datacenter codename"

[datacenter_accel.gates]
process_node = 45
architecture = 40
yield_line = 35

[datacenter_accel.economics]
build_cost = 220
build_weeks = 130               # ~2.5 yrs — the bet-the-company tape-out
unit_margin = 0.62
capacity_type = "fab_line"
capacity_to_build = 2
capacity_to_run = 2
addressable_market = 9000
ramp_weeks = 39
decay_per_quarter = 0.09        # decays faster — frontier treadmill

[datacenter_accel.specs]
performance = 0.55
efficiency = 0.30
margin = 0.15

[next_gen_arch]
id = "next_gen_arch"
sub_industry = "ai_chips"
name = "Next-gen architecture part"
tier = 3
description = """A generational leap — a part that redefines the category and \
locks in customers for years. Requires bleeding-edge everything and a fortune, \
but if it lands you set the market's pace and the rivals chase you."""
flavor_naming_hint = "e.g. a bold codename — 'Helios', 'Titan'"

[next_gen_arch.gates]
process_node = 70
architecture = 65
yield_line = 55

[next_gen_arch.economics]
build_cost = 600
build_weeks = 180
unit_margin = 0.68
capacity_type = "fab_line"
capacity_to_build = 3
capacity_to_run = 2
addressable_market = 16000
ramp_weeks = 52
decay_per_quarter = 0.10

[next_gen_arch.specs]
performance = 0.6
efficiency = 0.25
margin = 0.15
```

**Field notes:**
- `tier` — rough tree depth / unlock order. Higher tiers gate behind higher tech levels.
- `gates` — the **tech levels required to create** this archetype. This is what makes R&D matter: you fund `process_node` for quarters to unlock the datacenter part.
- `economics.build_cost` / `build_weeks` — the cost and duration of the **bet** that creates the product (this *is* the signature mechanic instance — tape-out / training run / launch). **Per-industry feel lives here**: chips are expensive + slow, models cheaper + faster, etc.
- `capacity_to_build` vs `capacity_to_run` — capacity tied up *during* the bet vs *while the product is live*. This is what limits concurrent bets and forces capacity expansion (§3).
- `addressable_market` — the $M/yr ceiling the product can grow into (it competes with rivals for share within this).
- `ramp_weeks` / `decay_per_quarter` — the lifecycle. **Decay is per-archetype**: workhorses (a proven rocket, a mature satellite bus) get low decay = steady cash; frontier parts get high decay = treadmill. The player's strategic mix of stable vs. frontier products falls out of these numbers.
- `specs` — **weights** (sum ~1.0) mapping which R&D lines determine this product's quality. Engine computes actual quality from current tech levels × these weights, then market share vs. rivals follows from quality.

**Author 3–5 archetypes per sub-industry as a progression** (tier 1 → 3+). Make tier 1 cheap/fast/low-margin (a beachhead) and top tier expensive/slow/high-margin/bet-the-company. Give each a **real description with character** — this is what makes the business concrete.

---

## 3. Capacity Types — `content/capacity/<sub_industry>.toml`

The resource products and bets consume. Replaces the old "three one-time economic buys" with an **ongoing ladder** that scales with the portfolio. 1–2 types per sub-industry.

```toml
# content/capacity/ai_chips.toml
[fab_line]
id = "fab_line"
sub_industry = "ai_chips"
name = "Fab line"
unit_label = "line"             # "3 fab lines"
description = """Where silicon gets made. Each line is an enormous capital project \
that takes time to stand up — and your products can't ship or scale without one. \
Run out of lines and your best chip just sits in a queue."""
# the expansion ladder — each rung adds capacity, costs more than the last
[[fab_line.rungs]]
capacity = 2
cost = 60
build_weeks = 52
[[fab_line.rungs]]
capacity = 4
cost = 140
build_weeks = 60
[[fab_line.rungs]]
capacity = 7
cost = 300
build_weeks = 72
[[fab_line.rungs]]
capacity = 11
cost = 560
build_weeks = 84
```

**Field notes:**
- A new company starts with rung-0 (small base capacity, set in tuning §4). Each `rung` is a buyable expansion that takes `build_weeks` and adds `capacity` units.
- Capacity is consumed by `capacity_to_build` (active bets) + `capacity_to_run` (live products). When you're capacity-constrained you **can't start new bets** — the pressure that forces expansion. This is the engine that never bottoms out.
- Most sub-industries have **one** capacity type (compute, fab lines, launch slots). A couple may want two (e.g. constellations: *manufacturing* + *ground stations*). Keep it to 1–2.
- Author **5–8 rungs** so there's always a next rung at any scale (don't cap it at three!).

**Per-sub-industry capacity flavors** (suggested — you set the names/economics):
- frontier_model_lab → **compute** (pods → clusters → datacenters)
- vertical_ai_saas → **deployment/infra** (and lighter; SaaS is capacity-light, more go-to-market)
- ai_chips → **fab lines**
- launch_services → **launch slots / vehicles** (pads + vehicle fleet)
- satellite_constellations → **manufacturing throughput** (+ optionally ground stations)
- space_stations → **module construction / berths**

---

## 4. Per-Industry Tuning — `content/products/_tuning.toml`

One file, keyed by sub-industry. The knobs that make each industry's *economics and pace* feel distinct without touching the engine. This is where your "timing, costs, decay should be by industry" lives at the global level (individual products override timing/cost in their own `economics`).

```toml
[frontier_model_lab]
starting_capacity = 2           # rung-0 capacity a new company has
rd_diminishing_k = 0.7          # how hard returns diminish as a line's level climbs (0–1; higher = harsher)
frontier_pull = 1.3             # bonus to R&D progress when rivals are ahead of you (catch-up aid)
max_concurrent_bets = 4         # ceiling on parallel training runs (also gated by capacity)
build_cost_mult = 1.0           # global multiplier on this industry's product build costs
build_time_mult = 1.0           # global multiplier on build durations
decay_mult = 1.0                # global multiplier on product decay (treadmill intensity)
share_volatility = 0.25         # how fast market share can swing vs rivals (hype-driven here)

[ai_chips]
starting_capacity = 2
rd_diminishing_k = 0.8
frontier_pull = 1.2
max_concurrent_bets = 3         # fewer parallel tape-outs — they're huge
build_cost_mult = 1.4           # chips are capital-heavy
build_time_mult = 1.6           # and slow
decay_mult = 1.1
share_volatility = 0.15         # stickier, design-win-driven

[launch_services]
starting_capacity = 3
rd_diminishing_k = 0.75
frontier_pull = 1.1
max_concurrent_bets = 4
build_cost_mult = 1.2
build_time_mult = 0.7           # launches are faster cadence than tape-outs
decay_mult = 0.6                # a reliable vehicle is a long-lived workhorse
share_volatility = 0.12         # contract/reliability-driven, very sticky

# ... vertical_ai_saas, satellite_constellations, space_stations
```

**Author all six blocks.** The contrast between them is what makes the sub-industries feel different to play: chips = slow/expensive/few-parallel/sticky; frontier labs = fast/cheaper/many-parallel/hype-volatile; launch = fast-cadence/workhorse-decay/contract-sticky. Tune these against each other so no sub-industry is strictly easiest.

---

## How it all wires together (so the fields make sense)

```
R&D budget you allocate  ──►  R&D line tech levels rise (per rd_diminishing_k, frontier_pull)
        │
        ▼
tech levels meet a product archetype's `gates`  ──►  you can CREATE that product
        │
        ▼
creating = a BET (build_cost, build_weeks) that consumes capacity_to_build   ◄── this is the
        │                                                                        signature mechanic,
        ▼                                                                        now multiple-in-parallel
bet resolves  ──►  product SHIPS into your portfolio
        │
        ▼
live product: quality (from tech levels × specs) → market share vs rivals (share_volatility)
        → revenue (ramps over ramp_weeks toward addressable_market share) → decays (decay_per_quarter)
        │           occupies capacity_to_run the whole time
        ▼
revenue funds  ──►  more R&D + more capacity rungs + new product bets + new lines of business
        │
        ▼
product obsolesces  ──►  create its successor (higher tier). The treadmill never stops.
```

Concurrent bets are limited by `max_concurrent_bets` **and** available capacity — so mid-game you're juggling several training runs / tape-outs / launches, each tied to a product, each drawing on shared capacity. That's the depth.

---

## Authoring checklist (per sub-industry — do all 6)

- [ ] `content/rd_lines/<sub>.toml` — 2–4 lines that pull in *different* directions; each with description, starting_level, base_cost_per_quarter, drives_specs
- [ ] `content/products/<sub>.toml` — 3–5 archetypes as a tier 1→N progression; each with a **characterful description**, gates (tech levels), full economics, lifecycle, and spec weights
- [ ] `content/capacity/<sub>.toml` — 1–2 capacity types, each with 5–8 expansion rungs (never caps out)
- [ ] `content/products/_tuning.toml` — one block for this sub-industry, tuned to feel distinct from the others
- [ ] Sanity: every product `gates` references a real line id in the same sub-industry; every `capacity_type` references a real capacity id; `specs` weights ≈ sum to 1.0; spec tags match the lines' `drives_specs`
- [ ] Character check: would a player read the product descriptions and *understand what the company does*? That's the whole point.

---

## What I'll handle (code, not authoring) — so you don't author it

- The allocation UI, the R&D-progress math (diminishing returns, frontier pull), the bet scheduler + concurrency, lifecycle/decay, market-share-vs-rivals, capacity accounting, and the portfolio/operating screens.
- Wiring the **signature mechanic** to "create/upgrade product" (replacing the standalone minigame).
- The three bug fixes (IPO-relapse, earnings popup fields, chip revenue between tape-outs — the last one is *fixed by this system*: revenue now grows organically via ramp, not just at ship).
- The `_tuning.toml` → engine mapping and the new content schemas/loaders + cross-ref validation (gates/capacity/spec ids).

---

## Suggested authoring order (fastest path to something playable)

1. **`ai_chips`** first (you're already playing it, and it's the one that felt flat) — all four blocks.
2. **`frontier_model_lab`** next (maximally different economics — fast/parallel/hype) to prove the per-industry contrast.
3. Then the other four, copying the patterns.

Start with chips: 3 R&D lines, 3 product archetypes (consumer GPU → datacenter accelerator → next-gen part), 1 capacity type (fab lines, 6 rungs), 1 tuning block. The examples above are literally a runnable chips draft — tweak the numbers/descriptions to taste and you've got the first sub-industry done.
