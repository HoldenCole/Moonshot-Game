# Moonshot Inc — Design & Build Plan

*A Steam-first business sim in the vein of Coffee Inc 2, Plutocracy, and Wall Street Raider — set in the moonshot industries of Space, AI, Biotech, Energy & Climate, Defense, Advanced Manufacturing, Mobility, and Quantum. A focused mobile port to follow after Steam launch validates the core loop.*

---

## 1. Name Ideas

Strong options, ranked roughly by fit:

1. **Moonshot Inc** — directly evokes all three industries (space, AI, gene editing are *the* canonical moonshots). Echoes Coffee Inc 2's naming pattern. **My top pick.**
2. **Frontier** / **Frontier Tycoon** — captures bleeding-edge industries; clean and brandable.
3. **Magnate** — implies both empire-building and the lifestyle/wealth side (yachts, mansions).
4. **Cap Table** — insider-y, signals depth to sim fans; might be too jargon-heavy for casual.
5. **Founder Mode** — culturally current (Paul Graham essay), evokes the operator fantasy.
6. **Series Z** — playful VC reference; suggests endless growth.
7. **Exit Strategy** — IPO/acquisition fantasy front and center.
8. **Apex Inc**
9. **Conglomerate**
10. **Burn Rate**
11. **Vested**
12. **The Founder**

**Recommended shortlist for testing:** *Moonshot Inc*, *Frontier Tycoon*, *Magnate*. All three are clean, available-sounding, and signal genre. Run a quick App Store search and trademark check before committing.

---

## 2. Vision & Elevator Pitch

> Start with $50,000 and a dream. Found a rocket company, a frontier AI lab, or a gene therapy startup. Raise venture capital, hire engineers, ship products, IPO. Then do it again — and again. Build a portfolio of companies, a personal fortune, and an empire that bends industries. Live the founder-investor-magnate fantasy: from your first seed round to your name on a hospital wing.

The game sits at the intersection of three fantasies players already love:

- **Operator fantasy** (Coffee Inc 2): running a real business, decisions matter
- **Investor fantasy** (Trading Game): reading the market, sizing positions, getting rich
- **Magnate fantasy** (Bitlife / GTA wealth porn): the cars, the houses, the philanthropy, the influence

Most games do one. This does all three, with the deep economic simulation as the spine.

---

## 3. Core Game Loop

**Inner loop (per turn):**
Player makes decisions for the current week (hire, ship, invest, vote, buy) → clicks **Advance Week** → simulation ticks one game-week forward → player reviews changes (financials, news, market prices) → handles any new decisions → repeat.

The game is **fully turn-based**. No real-time pressure. Time advances only when the player clicks. For uneventful stretches, the player can fast-forward via **Advance Month** or **Advance to Next Event** — the engine auto-pauses the moment anything needs attention (board vote, term sheet, FDA decision, market shock, employee crisis). Players never miss anything important, and they never feel rushed.

Compare to Civilization VI, Crusader Kings III, or Stardew Valley's "sleep to advance day" — same pacing philosophy, different theme.

**Outer loop (session-to-session):**
Found company → raise rounds → grow → exit (IPO/acquisition) → use proceeds to invest, found another company, or live large → unlock higher-tier opportunities.

**Meta loop (across save files):**
Net worth milestones unlock new starting options, industries, and difficulty modifiers (e.g., "Start in 1995," "Hard mode: AI winter," "Sandbox: $1B starting cash").

---

## 4. Game Pillars

These constrain every design decision. If a feature doesn't serve a pillar, cut it.

1. **Decisions feel weighty.** Every major choice has trade-offs that play out over weeks of game time, not seconds.
2. **Numbers are honest.** Cap tables, valuations, dilution, P&L — they should resemble real-world finance closely enough that founders/finance people respect it. This is the moat vs. shallow tycoons.
3. **The world feels alive.** Procedural events, sector rotations, competitor moves, and macro cycles make every save unique.
4. **Three power loops, one game.** Operating, investing, and lifestyle/influence reinforce each other rather than competing for attention.
5. **Desktop-first density, depth-friendly pacing.** Built for the Steam sim audience — Bloomberg-grade information density, multi-panel workspaces, keyboard-driven navigation. Sessions can be a quick check-in or a 4-hour empire-building binge. Both feel good. A focused mobile port follows after Steam launch.

---

## 5. The Industries

A roster of **8 future-forward industries**, each with 3–7 sub-industries the player chooses from when founding a company. The sub-industry choice is one of the most consequential decisions in the game — sub-industries within a parent share some flavor (regulators, talent pool, news feed) but play *mechanically* differently. Founding a frontier AI lab vs. an AI chip foundry vs. a vertical AI SaaS should feel like three different games.

### How the Industries Differ (Cross-Cutting Texture)

Each industry has a signature profile. These shape pacing, risk, and what kinds of decisions matter.

| Industry | Capex | Time Horizon | Cycle Speed | Talent Cost | Regulatory | Binary Outcomes |
|---|---|---|---|---|---|---|
| Space | Extreme | Long | Slow | High | Heavy | Yes (launches) |
| Artificial Intelligence | High | Short | Fast | Extreme | Rising | No |
| Biotech & Gene Editing | High | Longest | Slow | High | Heaviest | Yes (trials) |
| Energy & Climate | Extreme | Long | Slow | Medium | Heavy | Mixed |
| Defense Tech | High | Medium | Slow | High | Heaviest | No |
| Advanced Mfg & Materials | High | Medium | Medium | Medium | Medium | No |
| Mobility & Autonomy | High | Medium | Medium | High | Medium | No |
| Quantum Computing | Medium | Longest | Slow | Extreme | Light | Mixed |

Variety across these axes is what gives the game replayability. A "speed-run an AI vertical SaaS to IPO in 4 game-years" run feels nothing like a "20-year fusion company that may or may not work" run.

---

### 5.1 Space
*Cinematic, capital-extreme, defined by binary launch events and government anchor customers.*

**Sub-industries:**
- **Launch services** — cadence-driven; revenue per successful launch; failures destroy customer payloads (lawsuits, insurance hikes)
- **Satellite constellations** — massive upfront capex, then recurring subscription revenue from data/comms customers
- **Space stations** — real-estate-like; lease modules to research, tourism, and in-space manufacturing tenants
- **Space mining** — ultra-long horizon; single missions are bet-the-company; commodity-price exposure on success
- **In-space manufacturing** — orbit-based factories producing materials (fiber optics, pharmaceuticals, exotic alloys) that command premium pricing
- **Space tourism** — B2C, seat economics, brand-driven; safety incidents are existential
- **Lunar / Mars logistics** — multi-decade government contracts; cost-plus economics

**Signature mechanic:** Launch events. Rocket attempts play out as scripted moments where R&D investment, manufacturing quality, weather, and luck combine into a probabilistic outcome. Players watch.

**Real-world archetypes:** SpaceX, Rocket Lab, Planet Labs, Astranis, Varda, Vast.

---

### 5.2 Artificial Intelligence
*The fastest-cycle industry. Talent wars, compute constraints, eroding moats.*

**Sub-industries:**
- **Frontier model labs** — massive compute capex, top-tier researchers, low early revenue, winner-take-most dynamics
- **Vertical AI SaaS** (legal, medical, financial, etc.) — predictable SaaS metrics (ARR, churn, NRR); standard B2B sales motion
- **AI chips / silicon** — long fab cycles, customer concentration, brutal margins until scale
- **AI infrastructure / data centers** — real-estate + power play; lease compute capacity to model labs
- **Robotics & humanoids** — hardware margins, supply chain, manufacturing complexity
- **Autonomy stack** (self-driving, robotaxis at the software level) — regulatory unlocks city-by-city; liability exposure
- **Creative & generative tools** — B2C dynamics, copyright lawsuit exposure, fast viral growth

**Signature mechanic:** Talent + compute as twin constraints. Top researchers can be poached for 8-figure packages and can leave you for competitors. GPU allocation is a real, managed resource. SOTA decays — what's proprietary today is open-source in 18 months.

**Real-world archetypes:** OpenAI, Anthropic, Mistral, Scale, Cerebras, Groq, Nvidia, Databricks, Figure, Wayve.

---

### 5.3 Biotech & Gene Editing
*Longest horizons, probabilistic outcomes, regulatory mountain.*

**Sub-industries:**
- **Gene therapeutics** (CRISPR, base editing) — rare disease and oncology programs; clinical trial pipeline as core mechanic
- **mRNA & cellular therapies** — platform technology; multiple shots on goal
- **Agricultural biotech** — drought-resistant crops, livestock genetics; regulatory varies by country
- **Synthetic biology / biomanufacturing** — engineered organisms producing chemicals, materials, food
- **Longevity & aging** — early-stage; long timelines; massive TAM if it works
- **Personalized medicine** — companion diagnostics, biomarker-driven trials
- **Bio-defense** — government-anchored, classified contracts

**Signature mechanic:** Clinical trial pipeline. Phase I → II → III with probabilistic outcomes (~15–25% combined approval rate). A single Phase III hit can be a 50x return; failures can wipe out a company. FDA timelines are non-negotiable.

**Real-world archetypes:** Vertex, Beam, Verve, Editas, Ginkgo, Recursion, Moderna, Altos Labs.

---

### 5.4 Energy & Climate
*Capital-intensive, policy-driven, the most mission-aligned vertical.*

**Sub-industries:**
- **Utility-scale solar** — project finance model; PPAs (power purchase agreements) drive revenue
- **Offshore & onshore wind** — site selection, turbine supply chain, long-term contracts
- **Battery & energy storage** — arbitrage revenue (charge cheap, discharge expensive); grid services
- **Green hydrogen** — needs massive scale to be cost-competitive; long path to profitability
- **Small modular nuclear (SMRs)** — 10+ year build cycles, regulatory mountain, but baseload contracts that print money once operating
- **Fusion** — still pre-commercial; the ultimate long bet; potential industry-redefining payoff
- **Direct air capture (DAC) & carbon removal** — revenue from carbon markets + offtake agreements
- **Smart grid & virtual power plants** — software margins, utility customers, regulatory tailwinds
- **Geothermal** — location-dependent; deep drilling tech enabling new sites

**Signature mechanic:** Project finance. Most energy plays are about getting projects financed, built, and operating. The mini-game is structuring deals: equity vs. debt, tax credits, PPAs, offtake agreements. Macro interest rates massively swing project economics.

**Real-world archetypes:** First Solar, Ørsted, Form Energy, Commonwealth Fusion, Helion, Climeworks, NuScale, Fervo.

---

### 5.5 Defense Tech
*Government-customer dominated, geopolitically-reactive, fastest-rising sector culturally.*

**Sub-industries:**
- **Autonomous systems** — drones (air, ground, maritime), loitering munitions
- **Hypersonics** — extreme-speed propulsion; major DoD programs of record
- **Cyber & electronic warfare** — software margins; classified contracts
- **Space defense** — anti-satellite, missile warning (overlaps with Space)
- **Military AI / decision support** — battlefield AI, ISR (intelligence, surveillance, reconnaissance)
- **Ammunition & propulsion** — industrial base; surge capacity is the asset
- **Soldier systems** — wearables, comms, AR

**Signature mechanic:** Programs of record. Long sales cycles (3–7 years from pitch to first dollar), but contracts are massive and sticky. Geopolitical events (procedurally generated wars, tensions) drive demand spikes. Reputation with DoD compounds — winning small contracts qualifies you for bigger ones.

**Real-world archetypes:** Anduril, Palantir, Shield AI, Saronic, Hadrian, Epirus.

---

### 5.6 Advanced Manufacturing & Materials
*Industrial backbone of the moonshot economy. Less glamorous, deeply profitable when scaled.*

**Sub-industries:**
- **Semiconductor fabs** — extreme capex ($10B+ per fab), long lead times, generational technology bets
- **3D printing & additive manufacturing** — democratizing production; high-mix low-volume parts
- **Advanced materials** — graphene, metamaterials, carbon nanotubes; B2B licensing model
- **Industrial robotics** — replacing factory labor; recurring service revenue
- **Lightweight composites** — aerospace, automotive, defense customers
- **Reshoring-focused contract manufacturing** — riding the geopolitical reshoring wave

**Signature mechanic:** Asset utilization and capacity planning. You build expensive facilities, then have to keep them running at high utilization to make money. Customer concentration risk is real.

**Real-world archetypes:** TSMC, Hadrian, Relativity, Boom, Carbon, Apptronik.

---

### 5.7 Mobility & Autonomy
*Where consumer-tech meets hard tech. Tesla-shaped opportunity space.*

**Sub-industries:**
- **Electric vehicles (consumer)** — capital-intense, brand-driven, factory ramp is the make-or-break
- **eVTOL / flying cars** — pre-commercial; FAA certification mountain
- **Autonomous trucking & freight** — B2B, route-by-route rollout, fleet operator partnerships
- **Robotaxis** — capital-light operator model OR full-stack like Waymo
- **Maritime autonomy** — autonomous shipping, naval applications
- **Last-mile delivery robotics** — sidewalk and aerial delivery
- **High-speed rail / hyperloop** — infrastructure-scale; government partnerships required

**Signature mechanic:** Manufacturing ramp + regulatory unlock. EVs and eVTOLs are about scaling production without quality collapse; autonomy is about expanding operational design domain (more cities, more weather, more situations) one approval at a time.

**Real-world archetypes:** Tesla, Rivian, Joby, Archer, Waymo, Aurora, Kodiak, Zipline.

---

### 5.8 Quantum Computing
*Longest-horizon hard tech bet. Maybe nothing for a decade, then everything overnight.*

**Sub-industries:**
- **Quantum hardware** — competing modalities (superconducting, trapped-ion, photonic, neutral atom); pick your physics
- **Quantum software & algorithms** — applications layer; works on whichever hardware wins
- **Quantum networking** — secure communication; long-distance entanglement
- **Post-quantum cryptography** — software margins; near-term enterprise demand driven by "harvest now, decrypt later" threat
- **Quantum sensing** — sensors that exploit quantum effects; defense and biomedical applications

**Signature mechanic:** Milestone-gated funding. Quantum companies live and die on technical milestones (logical qubits, error rates, gate fidelity). Hitting a milestone unlocks the next round; missing one stalls the company. Long stretches of pure R&D burn before any commercial revenue.

**Real-world archetypes:** PsiQuantum, IonQ, Rigetti, Atom Computing, Quantinuum, SandboxAQ.

---

### Cross-Industry Synergies

This is where the conglomerate fantasy lives. Owning paired companies creates in-game bonuses:

- **AI + Advanced Mfg** — your AI chip company gets priority allocation from your foundry partner
- **AI + Biotech** — drug discovery acceleration; faster trial design
- **Space + Advanced Mfg** — in-house composites and propulsion components
- **Space + Defense** — space defense contracts route to your launch company
- **Energy + Mobility** — battery integration; EV charging network advantages
- **Energy + AI** — data center power deals; grid-scale optimization software
- **Quantum + Defense** — post-quantum crypto contracts via DoD relationships
- **Biotech + AI** — protein design, computational chemistry

Late-game players who assemble well-paired portfolios get genuine strategic moats. This is the modern Berkshire-meets-Bond-villain endgame the game should make irresistible.

---

### Future Expansion (V2+ / DLC Candidates)

Not in the initial roster but strong candidates for later content drops:

- **Neurotech & BCI** (Neuralink-shaped) — extreme regulatory, ethical tension, late-game flavor
- **Synthetic media & XR/VR** — Apple Vision-shaped consumer tech
- **Ocean tech** — desalination, aquaculture, deep-sea mining
- **Asteroid defense** — pure late-game vanity industry; wildly expensive, government-funded, prestige play
- **Fintech infrastructure** — adjacent rather than moonshot but fits if you want a "boring profit machine" option

---

## 6. Company Building

### Lifecycle Phases

| Phase | Cash Range | Player Activities |
|---|---|---|
| Idea | $0–50K | Pick industry, sub-vertical, name, logo, write pitch |
| Pre-seed | $250K–2M | Hire 2–5 founding engineers, build MVP, choose product wedge |
| Seed | $2M–10M | First customers/users, hire executive team, define metrics |
| Series A | $10M–30M | Scale go-to-market, expand product, formalize org chart |
| Series B–D | $30M–500M | Geographic expansion, M&A, multiple product lines |
| Pre-IPO | $500M+ | Hire CFO, audit, S-1, roadshow |
| Public | $1B+ market cap | Quarterly earnings, analyst coverage, public scrutiny |

### Operating Levers (Generic Across Industries)

- **Hiring:** Engineers, sales, ops, executives. Each hire has skill stats, salary, equity expectations. Senior hires shift company culture.
- **R&D allocation:** % of budget into research vs. product vs. ops. Compounds over years.
- **Pricing:** For revenue-generating businesses, set price points; affects volume and margin.
- **Marketing & GTM:** Brand vs. performance vs. enterprise sales motion.
- **Strategic decisions:** Pivots, acquisitions, geographic expansion, product line launches.

### VC Fundraising Mechanics

The first of two hero features. Players will negotiate dozens of rounds across a playthrough; the system must be deep enough to reward expertise without overwhelming new players, and varied enough that no two negotiations feel identical.

#### Negotiable Terms (V1: 5 Knobs, Light Mode)

V1 ships with **five negotiable terms** — the ones that matter most, that founders actually fight over:

- **Pre-money valuation** — single biggest negotiation; anchored by recent comparables, your metrics, and market state
- **Round size** — how much capital you're raising
- **Liquidation preference** — 1x non-participating is market standard (Q2 2025: 98% of rounds use 1x, 95% non-participating); 2x or participating is "rough terms" players will learn to push back on
- **Board seats** — lead investor's seat count; affects governance balance
- **Option pool top-up** — comes out of pre-money (the classic founder trap); negotiating it to post-money is a real win

These five cover the vast majority of consequential negotiation in real fundraising. Players learn real concepts that transfer to actual VC literacy.

#### Future DLC: Advanced Terms

V1's 5-knob mode is deliberately approachable. A future paid DLC ("Term Sheet" expansion, fits naturally inside Mogul or as standalone) adds the deeper economic terms:

- **Anti-dilution provisions** (broad-based weighted average vs. full ratchet)
- **Pro-rata rights**
- **Protective provisions** (investor veto rights on major decisions)
- **Dividend structure** (cumulative vs. non-cumulative)
- **Drag-along and tag-along rights**
- **Founder vesting acceleration** (single-trigger vs. double-trigger)
- **Information rights and inspection clauses**

The DLC also adds the economics-focused **Cap Table Pro mode** — richer cap table visualization with liquidation waterfall scenarios, dilution analysis across hypothetical future rounds, exit-payout modeling under different term structures. This is a finance-power-user expansion. V1's 5 terms are enough for everyone else.

#### The Negotiation Flow

A negotiation runs up to **3 rounds** of offer/counter-offer, capped tight to stay engaging:

**Round 1 — Opening offer:** Investor opens with a term sheet anchored by your company metrics, sector hype, VC climate, IPO window state, the investor's personality (5 hidden axes), and prior relationship score. The player sees the full term sheet on a single screen.

**Round 2 — Player counter:** Player can adjust any of the 5 visible knobs via sliders. Sliders show valid ranges (constrained by what could plausibly be accepted, not what would be); pushing aggressively works sometimes, depending on counterparty. Player submits the counter.

**Round 3 — Final response:** Investor accepts, makes a final counter, or walks. If they counter, player has one last chance to accept or walk.

The 3-round cap matters. Real negotiations can drag for weeks; the game compresses them to bounded, high-tempo exchanges. No infinite back-and-forth.

#### Live Decision Support — Three Layers

This is where UI investment pays off. The negotiation screen exposes three reading aids simultaneously:

**1. Color-coded terms.** Each term gets a contextual red/yellow/green badge:
- Green: founder-friendly relative to current market
- Yellow: market-standard
- Red: investor-friendly / aggressive

Color is contextual to the current macro state — a 1.5x liquidation preference might be red in a bull market but yellow in a deep recession. Teaches market norms by exposure.

**2. Comparable Rounds widget.** Side panel showing 3–5 recent comparable rounds in your sector and stage:

> *"Recent Series A in AI Vertical SaaS (last 12 months):
> Median pre-money: $32M
> Range: $18M – $58M
> Median round size: $8M
> Liquidation pref: 1x non-participating (4 of 5 deals)
> Option pool: 12–15% (post-money in 3 of 5)"*

This is exactly what real founders do — pattern-match against recent deals. Surfacing this in-UI grounds the player's expectations and teaches comparison thinking.

**3. Live Outcome Preview.** Always-visible cap table preview showing what *will happen* if the current proposal gets accepted:
- Your post-round ownership % (founder dilution)
- New investor's stake
- ESOP after option pool top-up
- Founder shares vested vs. unvested
- Hypothetical exit waterfall: "If you exit at $200M, you walk away with $X.XM after liquidation preferences"

Numbers update live as the player adjusts sliders. The "if I accept this, here's exactly what happens to my cap table" feeling is the heart of why this game is different from Coffee Inc 2.

#### Soft Reaction Signals (Not Probability %)

When the player submits a counter, the investor's response is communicated through **qualitative reaction tags**, not acceptance probability percentages:

- *"They're stretching to meet you on valuation"*
- *"This is in their comfort zone"*
- *"They'll likely push back hard on this"*
- *"You're testing their patience"*
- *"They consider this a hard no"*

Why not show probability? Because that reduces the game to optimization (find the highest acceptable number) and removes the human texture. Soft signals teach pattern recognition over time — players learn that the Aggressive-axis-high Frontier Partners managing partner pushes back hard on valuation but is flexible on board seats, while the Patient-axis-high Helio Capital partner accepts whatever valuation but insists on protective provisions. Personality matters because patterns are learnable.

#### What Drives Investor Counter-Logic

Every investor's response combines four input layers:

1. **Your company metrics** — revenue, growth rate, burn, runway, product maturity, brand, team quality
2. **Macro state** — VC Climate, Industry Hype for your sector, IPO Window, interest rate
3. **Investor personality** — the 5 hidden axes (Aggression, Patience, Conviction, Founder-Friendliness, Network Strength)
4. **Relationship history** — prior numeric score + event log if hand-crafted firm

The combination means two investors looking at the same company at the same time will produce *different* term sheets. And the same investor with the same company at different macro states will also produce different terms. That's the source of genuine replayability — players can't memorize "Series A = these terms."

A future DLC expansion deepens the macro/personality interactions (more granular reactions to sub-conditions, contagion effects between competing investors in hot deals, etc.) and adds the "Cap Table Pro" finance modeling for power users.

#### Walking Away

The player can walk away from a negotiation at any point — but consequences scale with pattern:

- **Single walk:** Reputation hit with that specific investor (–10 to –20 on the relationship score). They may still talk to you later but the warmth is gone.
- **Walking on a hand-crafted firm without genuine reason:** Event-log entry that persists across the playthrough ("Founder walked from term sheet at Helio Capital, Y3"). Hand-crafted firms have long memories.
- **Serial walking (3+ walks in a short period):** Broader ecosystem reputation drop. Firms talk. A headline appears: "Founder shopping aggressively — investors growing wary." Subsequent term sheets come in tighter, valuations 10–20% lower.

This is realistic — VC is a small world — and it prevents save-reload exploits ("walk from offer, reload, get the next one"). The player can always walk; they just can't *systematically* walk without cost.

#### Round Structure: Lead + Recommended Followers

Per the Investor Archetypes design, rounds scale by stage:

- **Pre-seed/Seed:** Single lead or angel; no follower negotiation
- **Series A and beyond:** Lead negotiation is the main event; once accepted, the lead **recommends a syndicate** (2–4 follower firms)
- Player sees the recommended followers with their identities, brief context, check sizes
- Player can **approve as-is** (fastest), **swap one or two** (small reputation cost with the swapped-out firm), or **veto the syndicate** (significant cost with the lead — "founder won't take our friends" is a real signal)

Most players will approve as-is most of the time. The veto option matters for the moments when it matters — keeping a hostile or low-quality firm off your cap table can be worth the friction.

#### Hot Deal Trigger — Competing Term Sheets

Per the Investor Archetypes design, ~3% of rounds (gated by exceptional company metrics + high sector hype) trigger competing term sheets. When this fires:

- 2–3 firms put in term sheets simultaneously, displayed side-by-side
- Player can negotiate with each independently
- Visible bidding-war dynamics — firms know they're competing and may improve terms unprompted
- Choosing one closes the others (those firms remember; reputation effects)

This is the "you've made it" moment. The mechanic only fires when earned by metrics + hype — it's rare, dramatic, memorable.

#### When the Player Raises — Player-Initiated + Inbound Offers

V1 uses **player-initiated fundraising**: the player decides when to raise. Runway pressure is the implicit timer; nothing forces a raise.

**Inbound offers** layer on top. Hot companies (strong metrics + sector hype) periodically receive unsolicited term sheets in the news feed — firms reaching out before the player asks. The player can:

- Engage and enter negotiation (treats as a normal round, but starts with the firm already interested)
- Decline politely (small relationship credit with the firm — "they thought of us first")
- Ignore (no effect; common)

This creates two kinds of fundraising moments: the *deliberate* raise (player decides, hits the market) and the *opportunistic* raise (a great firm comes calling at the right moment).

**The profitability alternative:** Strong, profitable companies legitimately may never need to raise again after Series A or B. Once a company hits sustainable profitability, runway becomes infinite, and the player can grow organically without dilution. This is realistic (Mailchimp, Atlassian, Basecamp) and creates a real strategic alternative to perpetual fundraising. Bootstrapped-to-IPO is a viable V1 playstyle — and arguably a satisfying one for players who don't want to dilute. The game should recognize and celebrate this path with achievements ("Bootstrapped to IPO," "No Dilution Champion").

**Advisor reminders** appear only on Forgiving difficulty: gentle prompts when runway falls below 6 game-months suggesting a raise. Realistic and Brutal modes give no prompts — players who don't watch their runway run out of money. That's correct difficulty design.

#### Self-Investing (Forward Note)

A player who eventually has angel capital (V1.5 free update — angel investing) or runs their own VC fund (Mogul DLC) should be able to **invest in their own companies** during rounds. This creates interesting strategic options:

- Anchor your own round to signal confidence to other investors
- Take down a tough round when external capital is scarce
- Maintain ownership % through pro-rata participation when you have personal capital
- Real conflict-of-interest tension when investing from a fund you manage with outside LPs

The mechanic isn't in V1 (no angel/fund systems yet), but the **negotiation system should architecturally support a "self" investor type** so it plugs in cleanly when those systems arrive. Designed forward: when the player's own fund or angel pool exists, they show up in the investor list during rounds with their own check size and personality (themselves, basically).

When eventually implemented, this introduces real governance questions — investing in your own company from your own VC fund creates fiduciary duties to your LPs that come into tension with founder self-interest. That's good gameplay tension, not a bug.

#### Why This System Works

A few structural reasons this design will produce engaging negotiations across hundreds of rounds:

- **Five terms is enough variety for V1, restrained enough to learn.** Three are too few; eight is overwhelming. Five hits the sweet spot.
- **Three-layer evaluation help (color + comparables + cap table preview) serves both audiences.** Casuals read colors; finance audience lives in cap table preview; everyone benefits from comparables.
- **Soft signals over probability percentages keeps it human.** Pattern recognition is the skill being rewarded.
- **Personality + macro + metrics + relationship = no two negotiations identical.** This is what kills the Plutocracy "click through the same negotiation 100 times" problem.
- **Player-initiated frequency means strategic timing matters.** Reading the IPO Window, VC Climate, and Industry Hype before pulling the raise trigger is real gameplay.
- **Profitability as an alternative to raising** rewards a completely different playstyle and teaches a real lesson about business models.

### Exit Paths — Going Public, Selling, or Staying Private

The endgame of any company arc. **There is no single "right" exit** — staying private is a competitive long-term strategy, not a delay tactic. Each path has clear advantages and ongoing costs; the player chooses based on company state, market conditions, and their own goals.

This is one of the highest-leverage strategic decisions in the game. Coffee Inc 2's hard-filter approach (cross thresholds → IPO unlocks → IPO is obvious) removes the decision. Our system makes it a real choice with real trade-offs.

#### The Three Exit Paths (V1)

**1. Traditional IPO** — go public on the stock market. Maximum capital access, maximum visibility, ongoing public-company costs.

**2. Acquisition** — sell the company to a strategic acquirer or PE buyer. Single liquidity event; you exit; price often less than IPO peak but more certain.

**3. Stay Private with Secondaries** — late-stage private rounds + secondary tender offers provide partial liquidity for founders and early investors without going public. The SpaceX / Stripe / Cargill playbook.

V1.5 adds **Direct Listing** (Spotify/Slack/Coinbase model — no new shares, no underwriting fees, no lockup) and **SPAC merger** (faster, riskier, often worse outcomes).

#### Eligibility: Soft Requirements + Banker Quote + Market Timing

IPO is **always available** — there's no hard threshold that blocks it. But outcomes vary dramatically based on:

- **Company metrics** — revenue scale, growth rate, profitability, brand strength
- **Market timing** — IPO Window state (Open / Cracking / Closed)
- **Sector hype** — current investor appetite for your industry
- **Macro context** — interest rates, broader market sentiment

When the player initiates an IPO, **underwriters provide a quote**: a likely valuation range, expected first-day pop, predicted demand level, and a recommendation (proceed / wait / reconsider). This is the player's preview — they decide whether to proceed based on the quote.

A weak company can absolutely IPO during a bull market, just at a lousy valuation. A strong company in a closed window faces a brutal quote that often makes waiting the right call. **Both fundamentals and timing matter** — neither alone is sufficient.

This makes the IPO Window state genuinely consequential. Players watching the window flip from Open to Cracking face real urgency; players in a Closed window have to weigh waiting vs. taking a haircut.

#### The IPO Process: Three-Act Compressed

When the player decides to proceed, the IPO unfolds across ~12 game-weeks as a focused three-act sequence. Each act has one meaningful decision; total player time is ~5 minutes of clicks across the period.

**Act 1: Underwriter Selection (Week 1)**
- 3–4 underwriting firms pitch to lead the offering
- Each offers different terms: valuation range, fee structure, expected demand, prestige level
- Top-tier banks (Goldman-equivalent) bring credibility and demand but charge higher fees
- Lower-tier banks are cheaper but may price the deal weaker
- **Player picks the lead underwriter** — single decision

**Act 2: Roadshow (Weeks 9–10)**
- After ~6 weeks of S-1 filing prep (auto-handled), the roadshow begins
- Player visits 3–5 city stops (NYC, San Francisco, Boston, London, Hong Kong) over 2 weeks
- At each stop, **one decision**: how to position the pitch
  - "Lean into our growth story" — appeals to growth investors; risks if metrics weaken
  - "Emphasize our profitability path" — appeals to value-conscious institutions; ceiling on valuation
  - "Sell the vision" — appeals to long-only mission-driven funds; binary outcomes
- Each stop's reception modulates the underwriter's range
- Strong roadshow → range shifts up; weak roadshow → range shifts down

**Act 3: Pricing Decision + First-Day Reveal (Week 11)**
- Night-before-trading: underwriter gives final range based on roadshow performance
- Player picks within the range: Conservative / Target / Aggressive
- Conservative: lower price, near-guaranteed first-day pop, money left on table
- Target: balanced; matches underwriter recommendation
- Aggressive: higher price, captures more for the company, risk of flat or negative first day
- **First-day trading is "lived," not just revealed — a 6-beat sequence the player moves through.** This is the climax of a whole playthrough; the player should *participate* in it, not watch a number appear. The spine always plays; the interactive beats are all optional.

  1. **Pre-market / the morning** — at the exchange before the open; underwriter's final read; narrative scene-set; optional small "how are you feeling / a word to your team" beat.
  2. **Interviews (OPTIONAL)** — financial-news crews ask questions (text-based; no voice ever); the player picks tonal answers (confident / humble / visionary / grounded). **If the player skips, the IPO is still covered by general auto-generated news stories** ("Helio AI debuts on NASDAQ; shares pop on strong demand") and the day proceeds with no penalty — the press talks *about* you instead of *with* you. Skipping costs only the chance to *shape* the narrative.
  3. **Ring the bell** — the player triggers it themselves (click to ring); ceremonial peak before the numbers start.
  4. **The open** — trading begins and the price discovers itself live (the animated chart finding its opening print) — now the climax of a sequence, not a static reveal.
  5. **Watching it move** — the stock trades through day one; live micro-moments (a pop, a dip, an analyst note crossing the wire, congratulations buzzing in); optional light choices (watch obsessively or walk away; a word to the press as it spikes).
  6. **The close / settling** — final number, net-worth update, the reflective narrative beat, and the consequence (180-day lockup begins).

- **Interview impact scales with a "sway" setting (the key knob).** What the player says on camera has impact, and *how much* is tunable:
  - **Low sway** (Forgiving / casual default) — answers are mostly flavor + a little reputation; they color the moment but barely move the price. Roleplay without pressure.
  - **Medium sway** (Realistic default) — answers nudge first-day sentiment, set public reputation, and lightly raise/lower the expectations bar for the first earnings call.
  - **High sway** (Brutal default / cranked) — answers *materially* move the open, set analyst expectations the player will be held to, and can genuinely backfire: overhype the stock on camera and the first earnings miss hits twice as hard; play too humble and leave money on the table.
  - Difficulty presets set a sensible sway default, but an explicit **"Interview & press impact"** slider (Low / Medium / High) lives in settings — some players want max roleplay consequence on an easy economic difficulty, or vice versa. Consistent with the hierarchical-difficulty philosophy (presets set defaults, advanced tunes any axis).

- **Ties into existing systems:** interview answers feed the **public-profile / reputation** system and, crucially, the **post-IPO earnings-guidance trade-off** — on-camera bravado literally raises the expectations bar the player must beat next quarter. The interview is not a standalone toy; it seeds the earnings game that follows.

- **The earned-moment template** (reusable): game stops, chrome recedes, the hero number counts up, stakes made concrete, narrative carries the emotion (text-only), one-shot celebration that settles, ends on consequence. Reused for first unicorn valuation, successful launch, first profitable quarter, company sale, net-worth milestones — same skeleton, different number and copy.

- This is one of the biggest emotional beats in the game — invest in the polish. Everything interactive in it is optional; the celebration always plays.

#### Post-IPO Quarterly Cadence: Active Guidance

Going public means living on a 13-week clock. The recurring decision is **earnings guidance**.

Each quarter, the player sets guidance: revenue, profit, growth metrics for the upcoming quarter. Then operations play out for 13 weeks. At the end of the quarter, results are revealed against guidance:

- **Beat guidance** → stock pops, analyst confidence rises, harder to beat next quarter
- **Match guidance** → stock holds, expected
- **Miss guidance** → stock drops, analyst confidence falls, board pressure mounts on repeated misses

The strategic depth: **sandbag vs. stretch**. Conservative guidance is easier to beat but signals weakness; aggressive guidance signals confidence but risks misses. Repeated misses trigger investor pressure, board scrutiny, and eventually CEO replacement risk (in DLC with the deep executive layer).

#### Earnings Management: The Core Post-IPO Trade-Off (V1)

Beyond setting guidance, V1 includes the central values-driven choice of public-company life: **engineer short-term results to hit the quarter, or invest for the long term and eat the volatility.** This is the real-world trade-off where some companies manage earnings to hit guidance every quarter while others think in years and tolerate lumpy results — and there is no objectively right answer; it depends on the player's strategy and values.

Each quarter, when results are tracking toward a miss, the player can choose to *engineer* the number:
- **Pull revenue forward** (recognize deals early), **cut R&D or defer hiring**, **trim discretionary spend**, **delay investment** — all hit the quarter's target but borrow from the future
- Or **take the miss** — eat the stock drop, keep investing in fundamentals, trust that real value compounds

**The slow-building consequence:** sustained earnings engineering accumulates a hidden gap between *engineered* and *real* performance. The wider the gap, the higher the risk of a brutal eventual miss, a guidance reset, or — at the aggressive extreme — a restatement and credibility collapse. This ties directly into the ethics/integrity score: light smoothing is normal corporate behavior; aggressive engineering edges toward accounting manipulation and its compounding risk of exposure.

- **The earnings engineer** path: smooth predictable beats, happy market, rising stock — but a mortgaged future that eventually catches up
- **The long-term builder** path: lumpy results, volatile stock, analyst grumbling — but compounding real value if you survive the short-term pressure

This is a **light recurring decision** (guidance slider + occasional engineer/invest choice) that captures the most distinctive feature of public-company life without becoming a chore. DLCs add depth: activist investors attacking on misses or demanding buybacks, analyst relationships and whisper numbers, share buyback/dividend/capital-return policy, deeper accounting-treatment and restatement mechanics, and the full earnings-call mini-game (analyst Q&A) for special quarters (post-acquisition, post-scandal, first earnings as public, fiscal year-end).

#### Lockup Period: 180 Days, Then a Decision Moment

Standard 180-day lockup applies to founders, executives, and pre-IPO investors. During this period: **no insider sales allowed, full stop**. This creates real tension — you've created paper wealth but can't access it for six months.

When the lockup expires (game-week 180 post-IPO), the engine triggers a **Lockup Expiration Event** — a designed moment, not just a timer. The player decides:

- How many of their personal shares to sell (slider, with tax preview)
- What signal to send (small sale = confidence; large sale = "founder cashing out" headlines)
- Pre-arrange a 10b5-1 plan for ongoing scheduled sales (avoids future allegations of insider trading)

The amount insiders collectively sell at lockup expiration moves the stock — heavy selling triggers a 5–15% drop; restrained selling barely registers. Other insiders (executives, early investors) make their own decisions procedurally based on their personalities and needs.

This turns the lockup constraint into actual gameplay. The expiration is a moment players will remember.

#### Going Public — The Trade-Off Summary

**What you gain:**
- Massive capital access (raise hundreds of millions to billions)
- Stock as M&A currency (acquire competitors with shares, no cash)
- Founder/employee paper wealth becomes real wealth (after lockup)
- Brand prestige and customer trust
- Ability to raise more later via secondary offerings
- Public profile that opens doors

**What you take on (V1 scope):**
- **Stock volatility** — your net worth now swings with sector hype, macro cycle, and earnings outcomes. A bad quarter or industry downturn hits your wealth directly.
- **Disclosure obligations** — quarterly earnings reports become public; competitors see your numbers. Light annual cost (a few % of revenue); strategic cost is harder to quantify but real.
- **Quarterly cadence** — you now think in 13-week increments forever, with public scrutiny on every cycle.
- **Earnings management trade-off** — guidance-setting plus the engineer-short-term vs. invest-long-term choice each quarter (see "Earnings Management" above). This is the strategic heart of public-company life and is in V1.

DLCs layer in analyst coverage as a system, activist investors, hostile takeover risk, buyback/dividend policy, and deeper accounting/restatement mechanics. V1 keeps post-IPO focused on volatility + disclosure + the earnings-management trade-off — enough to make going public a real transformation, light enough not to drown V1 scope.

#### Staying Private — A Real Endgame Strategy

The plan we've designed makes staying private genuinely competitive long-term, not just a delay tactic before the inevitable IPO. The case for staying private leans on **upside** more than avoidance — running *toward* something rather than away from it.

**What staying private offers:**

- **Founder control intact** — no public board pressure, no activist investors, no hostile takeover risk
- **No quarterly earnings circus** — operate on multi-year horizons; no 13-week tyranny
- **No public disclosure** — competitors don't see your numbers, your strategy, your customer concentration
- **Long-term strategic flexibility** — pursue moonshot bets that public markets would punish
- **Cleaner cap table** — fewer external constraints; founder-friendly governance
- **No analyst pressure on every product decision**

**Mechanics that make it viable:**

**Late-stage private rounds (Series E, F, G+)** — once a company is at scale ($500M+ revenue, profitable or near-profitable), late-stage private rounds become available. Valuations approach what a public company would command. Funding sources include growth equity firms, sovereign wealth funds, and crossover investors (mutual funds that invest pre-IPO). These rounds are larger and slower than earlier rounds but sustainable indefinitely.

**Secondary tender offers** — periodically (every 18–36 game-months), late-stage investors offer to buy shares from existing holders at a set price. This gives founders, employees, and early VCs partial liquidity without an IPO. Player decides:

- Whether to allow the tender (always optional)
- Whether to participate personally (and how much to sell)
- Pricing dynamics — strong companies command premiums; weaker ones get marked down

This is the SpaceX / Stripe / Anthropic model. The mega-private-unicorn path is a real V1 endgame, not just a delay.

**Trade-offs for staying private:**

- **Less capital available** — late-stage private rounds top out below what public markets can offer
- **Limited stock-based M&A** — harder to acquire competitors using shares
- **Eventual liquidity pressure** — early investors and employees eventually want full exit
- **No public profile boost** — brand recognition lower than IPO peers
- **Cap table complexity** — many late rounds with various preferences and rights

#### Acquisition — The Quick Exit

Acquisition is the third path: a single liquidity event where the company sells to a strategic acquirer (a larger company in your industry) or PE buyer.

- **Triggered by:** unsolicited offers (procedural, more likely after strong quarters), or player-initiated outreach
- **Valuation:** typically 60–90% of likely IPO valuation, but immediate and certain
- **Outcome:** founders/investors get cash and/or acquirer stock; depending on terms, founder may stay on or exit
- **Strategic case:** ideal for founders who want out, companies in shaky markets, or when an acquirer offers a premium for strategic value

Acquisitions can be especially attractive when the IPO Window is Closed and a bidder offers fair terms. The cleanness of the exit (vs. lockup periods, vs. ongoing public-company life) is part of the appeal.

#### The Strategic Decision Tree

By construction, the right exit varies by player situation:

| Situation | Often Best Path |
|---|---|
| Strong metrics, IPO Window Open, want growth capital | Traditional IPO |
| Strong metrics, IPO Window Closed, can wait | Late private round + tender, IPO later |
| Strong metrics but founder wants out | Acquisition |
| Strong metrics, want long-term founder control | Stay Private with periodic tenders |
| Mediocre metrics, IPO Window Open | IPO at lower valuation, or acquisition for premium |
| Mediocre metrics, Window Closed | Wait, build, or take acquisition if offered |
| Weak metrics, capital running out | Acquisition (best available exit) |

There is no single dominant strategy. Different players, different companies, different worlds will produce different optimal exits — and the same player on the same playthrough may exit different companies different ways.

#### V1 Scope vs. Future Expansion

**V1 ships:**
- All three core exit paths (IPO, Acquisition, Stay Private)
- Three-act compressed IPO process
- Active quarterly guidance post-IPO
- 180-day lockup with expiration moment
- Late private rounds + secondary tenders
- Light public risks (volatility, disclosure)
- Underwriter quote system

**V1.5 adds:**
- Direct Listing as alternative path
- SPAC merger as alternative path
- Full earnings call mini-game for special quarters
- Analyst coverage as a system (procedural analysts with biases, ratings)

**V2.0 adds:**
- Activist investor mechanics (5% threshold integration with governance)
- Hostile takeover risk
- Going-private transactions (LBO your own public company)
- Secondary stock offerings post-IPO

### Delegation & the Executive Layer

The biggest scaling problem in any business sim: as the player accumulates companies, investments, and complexity, micromanagement becomes either impossible or boring. Delegation is the system that solves it — and it transforms gameplay from operator → executive → owner as scale grows.

**Key design insight:** Delegation IS the auto-decisions system. Whatever you've delegated runs automatically when you fast-forward; whatever you haven't, surfaces as a pause. One mechanic, two problems solved.

#### The Three-Stage Player Arc

1. **Founder mode** (early game, 1 company) — you handle everything directly. Hiring, pricing, product, fundraising, board prep.
2. **Executive mode** (mid game, 1–3 companies) — you've hired execs to run departments. You set strategy and approve big decisions; they execute.
3. **Owner mode** (late game, multiple companies + investments + VC fund) — you've hired CEOs to run entire companies. You're a board member, capital allocator, and strategist. Day-to-day is invisible; you read quarterly reports and intervene only when needed.

The game should make this transition feel earned and meaningful, not like a feature unlock. The first time you trust a CEO to run a company autonomously is a real moment.

#### Hireable Roles

Per operating company:

| Role | Owns | Authority Without Player Approval |
|---|---|---|
| **CEO** | Overall strategy, all functions | Everything below CEO; escalates M&A, fundraising terms, IPO timing, executive hires |
| **CTO / Head of Engineering** | Technology, R&D, eng hires | Eng team hires, tech stack, technical roadmap (within product strategy) |
| **CFO** | Finance, capital allocation | Budgeting, planning, audits, reporting; escalates fundraising terms |
| **COO** | Operations, supply chain | Operational hires, vendor decisions, process improvements |
| **CRO / VP Sales** | Revenue, pipeline, pricing | Sales hires, pricing within bands, large customer concessions |
| **CPO** | Product roadmap, design | Features, design decisions, user research priorities |
| **CMO** | Marketing, brand, PR | Campaigns, brand decisions, press strategy |
| **General Counsel** | Legal, compliance | Routine legal, contracts, regulatory filings |
| **Chief People Officer** | Talent, culture | Compensation philosophy, performance reviews |

Beyond operating companies, the same system extends to:
- **Family Office Director** — runs personal investment portfolio per the thesis you set
- **Chief of Staff** — manages your time, filters opportunities, schedules meetings
- **Estate Manager** — handles property purchases/sales, maintenance, taxes
- **Foundation Director** — runs philanthropy operations, recommends causes
- **Fund GP / Managing Partners** — run your VC fund (sourcing, diligence, board seats, LP relations)

#### Executive Stats

Every hireable exec has visible stats:

- **Skill** (1–100 in their function) — directly affects performance outcomes
- **Strategic style** — Cost-cutter / Growth-pusher / Innovator / Operator
- **Risk tolerance** — Conservative / Moderate / Aggressive
- **Loyalty** (1–100) — likelihood of staying when poached
- **Integrity** (1–100, partially hidden) — likelihood of cutting corners or causing scandal
- **Ambition** (1–100) — high ambition = drive *and* flight risk
- **Reputation** (1–100) — affects hiring cost and what they signal to the market

When recruiting, you see ranges. Once hired, exact numbers reveal over time as you observe their behavior.

#### Delegation Levels (Per Role, Per Company)

Granular sliders the player sets for each executive:

- **Hands-off** — handles everything; escalates only company-threatening decisions
- **Standard** — executes; escalates strategic decisions and anything above a $X threshold
- **Active** — recommends; you approve most decisions
- **Hands-on** — you make the calls; they execute

Plus per-decision-type toggles:
- "Always escalate hires above $X salary"
- "Always escalate spending above $X"
- "Always escalate any board vote"
- "Always escalate press appearances or external commitments"
- "Auto-handle routine operations"

Sensible defaults ship with each role; players can customize per company.

#### Recruiting

You don't pick executives from a menu — you recruit them.

- **Tier 1 talent** (proven, prior unicorn exits, big-tech alumni) — extremely expensive, hard to land, only join companies they believe in
- **Tier 2 talent** — solid track record; reasonable to recruit
- **Tier 3 talent** — junior or unproven; affordable but risk-laden

Compensation packages have multiple knobs: base salary, bonus structure, equity grant + vesting, signing bonus, severance terms. Top execs negotiate hard. Recruiting Tier 1 talent for a Series A startup requires either an exceptional founder reputation, a compelling company narrative, or both.

Reputation compounds here: once you've shipped one unicorn, top execs return your calls. Until then, you're scraping.

#### Risks of Delegation (it's not a cheat code)

- **Bad hires execute poorly** — low-skill execs miss numbers, make bad calls
- **Good hires might disagree** — high-integrity execs push back on bad strategies; high-ambition ones might lobby the board against you
- **Scandals** — low-integrity execs can blow up (fraud, harassment, misconduct) and you take reputation damage as the person who hired them
- **Information asymmetry** — execs sometimes know things you don't; if you're not paying attention, problems compound before they reach you
- **Late-game coup risk** — a charismatic CEO with strong board relationships can lead an effort to push you out of your own company. The Steve Jobs scenario.

These risks scale with how hands-off you are. Pure hands-off play with three rogue execs is a real failure mode.

#### Reporting & Oversight

For each delegated company:

- **Quarterly executive report** — auto-generated summary of company performance, key decisions made, items flagged for attention
- **Real-time alerts** — anything crossing an escalation threshold pings the player immediately
- **Multi-company dashboard** — status grid showing revenue trend, headcount, runway, key issues across all companies
- **Drill-down** — click any company to see full state and override decisions
- **Performance reviews** — quarterly reviews per exec; rate, retain, promote, fire, regrant equity

#### When to Introduce This (MVP Phasing)

**Light delegation ships in V1.0 — it is a core system, not a later add.** The reason: cadence is player-defined (see Operating Loop), and the player must never be forced to make decisions they don't want to make. A single-company V1 player who prefers to go hands-off needs executives to delegate to. Without delegation in V1, "player-defined hands-off play" doesn't actually work. The depth scales up over later versions:

- **V1.0 — Light delegation, core to the loop.** Single company. The player can hire a handful of key executives (CFO, COO, Head of Revenue/Sales, plus one sub-industry-relevant leader — e.g. Head of Research for a Frontier Lab, Head of Launch for Launch Services). Per-area delegation settings (*Handle it* / *Recommend* / *I'll decide*), simple escalation thresholds ("only escalate decisions above $X"), and **reports instead of decisions** for delegated areas. Executive quality matters — a strong exec handles more autonomously and decides well; a weak one makes mistakes or over-escalates. This is what lets a player choose their own cadence: fully hands-on (advance weekly, decide everything) through fully delegated (advance in big jumps, handle only escalations + strategy). Ties into existing hiring/comp/retention systems.
- **V1.5 — Multi-company delegation.** Delegation extends across several companies run in parallel. Escalation aggregation across a portfolio.
- **Mogul DLC — Deep executive layer.** Holding-company org charts, delegating an entire company to a hired CEO, exec poaching wars, coups, succession, exec equity negotiations at scale.
- **V2.5 — Delegation extended to family office, fund GPs, estate manager, foundation director.**

The V1.0 and DLC systems are architecturally the same — later versions extend the V1 executive/delegation system rather than replacing it. The "Delegation IS the auto-decisions system" insight holds from day one: whatever you've delegated runs automatically when you advance time; whatever you haven't surfaces as a pause.

### Investor Archetypes — Who Funds You

The fundraising counterparty system. Investors are the most-encountered NPCs in the game; their design shapes how every round feels.

#### What an Investor Is

Investors are **firms with a face** — each firm is represented by a named lead partner. The player negotiates with the partner, but the firm provides institutional weight (fund size, reputation, signaling).

This solves a tension between abstract firms (no personality, feels like a database) and pure individuals (hundreds of entities, partner-switching realism-tax). The firm-with-a-face structure delivers Plutocracy's character-driven engagement without the grind.

#### Roster Composition: Two-Tier System

The investor roster has two distinct tiers that play different roles:

**Hand-crafted tier (~30 firms):** Iconic firms with rich design — distinctive personalities, named partners, signature investment theses, narrative weight. These are the recurring characters across all playthroughs. Stable across saves so players develop intuition over time ("Helio Capital always pushes for board control, but their portfolio companies do well").

**Procedural tier (~150–250 firms, generated each save):** The ambient VC ecosystem — varies every save for replayability. Lighter design, lower authoring cost. These are the firms that fund early rounds and provide background activity.

The split solves multiple problems at once: cold start (procedurals are there from day one), iconic moments (hand-crafted firms feel earned to meet), replayability (procedurals differ each save), and authoring economics (rich design only where it matters).

#### Naming

- **Hand-crafted firms:** Archetype-flavored fictional names that evoke real firms without copying them (Helio Capital, Frontier Partners, Redwood Ventures, Apex Industries Fund). Legally clean, grounded-feeling, players catch the vibes.
- **Procedural firms:** Generated from word banks each save (Quartz Ventures, Northwind Capital, Meridian Partners). Different every game; bland by design — they're the long tail.

#### Personality System

Every investor has both **mechanical drivers** (hidden) and **flavor communication** (visible).

**Five hidden axes (1–100):**
- **Aggression** — willingness to push hard on terms
- **Patience** — tolerance for slow-burn investments
- **Conviction** — willingness to lead vs. follow others
- **Founder-Friendliness** — bias toward founder-favorable terms
- **Network Strength** — quality of post-investment value-add (intros, hires, follow-on capital)

**Visible trait tags (1–3 per investor):** Human-readable flavor labels surfaced in the UI ("Activist," "Founder Whisperer," "Vision Investor," "Tough Negotiator," "Hands-On Builder"). These don't drive mechanics directly — they communicate the partner's vibe to the player.

Hand-crafted firms have hand-tuned axis values aligned with their narrative identity. Procedural firms get axis values rolled from sector- and stage-appropriate distributions, with traits derived from the resulting profile.

#### Specialization: Sector + Stage with Flex

Each investor has:
- **Primary sector focus** (one of the 8 industries) and an optional secondary
- **Primary stage focus** (pre-seed / seed / Series A / growth / late-stage)
- **Stretch tolerance** — how far outside the lane they'll reach for an exceptional deal

Most investors stay in their lane; a few will reach for unicorn-shaped opportunities outside it. This creates strategic levers: founders with extraordinary metrics can attract unexpected investors, while typical founders should stay aligned with sector specialists.

#### Fund Mechanics: NPC vs. Player

A clean split between how the world simulates investor capital and what the player gets when they run their own VC fund (V2.0+):

**NPC investors (V1):** Fund cycles + check size limits.
- Each firm has a current fund (Fund I, Fund II, etc.) with a deployment period (~3–4 years) and total fund size
- Check sizes are gated by fund stage — Fund I is small, Fund III is large; this explains why some firms can lead Series D and others can't
- When a fund finishes deploying, the firm raises the next one (with some lag) — surfaces as news ("Frontier Partners closes $800M Fund IV")
- Firms can run dry between funds — temporarily unavailable, creating timing dynamics
- Top firms whose funds perform well raise larger next funds (light feedback loop)

**Player VC fund (V2.0+):** Full LP relations, fund formation, GP/carry mechanics, deeper than NPC simulation. Player feels the difference — running a fund is meaningfully richer than watching one.

This split keeps NPC simulation tractable while giving the player's eventual fund a distinctive depth.

#### Relationships: Two-Tier Memory

Relationships scale with investor tier:

**Hand-crafted firms:** Full event-history relationship.
- Numeric relationship score (–100 to +100)
- Visible event log per firm: "Funded your seed at Helio AI (Y3) → 12x exit (Y9) → led Series A at NeuroForge (Y11)"
- Visible relationship status badge ("Trusted Partner," "Burned Bridge," "Watching You," "First Meeting")
- Relationships compound across companies and decades — a hand-crafted firm that funded your last unicorn comes back warm

**Procedural firms:** Light numeric memory only.
- Numeric relationship score
- No event log, no badges — they remember whether they've worked with you, not the saga
- Avoids "why does this random VC have a multi-decade history with me" weirdness

This focuses player attention on the recurring characters that matter while keeping procedural firms transactional and clean.

#### Round Dynamics: Stage-Scaled Syndication

Round structure varies meaningfully by stage:

| Stage | Default Structure |
|---|---|
| Pre-seed | Solo angel (1 investor; usually procedural) |
| Seed | Lead + 2–3 followers (lead may be hand-crafted; followers usually procedural) |
| Series A | Lead + named followers (hand-crafted firms more likely to lead) |
| Series B+ | Lead + named followers; player can solicit specific firms |
| **Hot Deal trigger** | Competing term sheets — only fires when company metrics + sector hype cross threshold |

The Hot Deal trigger is critical: competing term sheets aren't a default behavior, they're a *moment* — earned by exceptional metrics or sector timing. This avoids the Plutocracy lesson of overusing the most engaging mechanic until it becomes routine.

#### Investor Competition: Three Modes

How firms compete for deals (frequency-tuned to avoid noise):

1. **Quiet (~85% of rounds):** No visible competition. You pitch; they decide. World moves on. The default texture of fundraising.
2. **Reactive (~12% of rounds):** After you have a term sheet, 1–2 other firms may match or counter within a short window. Simulates "shopping a term sheet."
3. **Pre-emptive (~3% of rounds, Hot Deal-gated):** Top firms reach out *before* you raise — unsolicited term sheets, dramatic moments. The "you've made it" experience.

Hand-crafted firms are more likely to participate in reactive and pre-emptive moments; procedural firms stay quiet. This creates a felt difference: meeting a hand-crafted firm is memorable; meeting a procedural one is transactional.

#### Discoverability: Three Tracks

How the player meets investors:

**Procedural firms — always visible.** Searchable from game start. The ambient VC ecosystem. Cold-start solved.

**Hand-crafted firms — network + reputation gated.** Players meet them through:
- Warm intros from existing investors
- Reputation thresholds (post-exit, post-press milestone)
- Each firm has visible criteria for what they're looking for
- Discovery events (firm reaches out after a press hit)

**Cold pitching — always available, with consequences.** Player can cold-pitch any firm. Cold-pitching a hand-crafted firm without warrant carries real cost:
- Reputation hit with that firm (–10 to –20)
- Broader ecosystem reputation tax (firms talk)
- Very low success rate
- Asymmetric upside keeps the option live — occasionally lands

This balances cold-start solvability, earned-iconic-firm feeling, and player agency.

#### Hand-Crafted Firms as Recurring Characters

A natural emergent property: the 30 hand-crafted firms are persistent across saves and accumulate history with the player across multiple companies. They show up in news, fund competitors, become long-term relationships.

In V1 they're investors with personality. In V2.0+, they can deepen into proper recurring characters: partner careers evolve (the rising star at Helio Capital becomes managing partner by Year 15), firms rise and fall, partner-firm transitions create story moments. This is the seed of the AI Rivals system in V2.0 — some hand-crafted firms become full rival capitalists with their own portfolios visible to the player.

Worth designing the V1 schema with this evolution in mind: hand-crafted firms should be data structures rich enough to support story arcs later without rework.

#### Authoring Cost (V1 Reality Check)

**Hand-crafted firm:** ~30 minutes to design well — name, partner name, sector/stage focus, hidden axes, trait tags, signature thesis, voice for negotiation responses.

**30 hand-crafted firms = ~15 hours of focused authoring work.** Tractable for V1 launch.

**Procedural firms:** Algorithmic — generation cost is engineering, not authoring. Word banks for names, distribution rolls for axes, traits derived from profile. Build once, runs forever.

### The Holding Company

Once the player controls **3 or more companies** (>50% economic interest, or effective control via super-voting share class), the option to **form a holding company** unlocks. This is the late-game endgame structure — the Berkshire Hathaway / Alphabet / LVMH play.

The holdco changes gameplay fundamentally. You're no longer running businesses; you're **allocating capital across them**. The role shift mirrors the real-world arc of capital allocators like Warren Buffett, Bernard Arnault, and Barry Diller — your job becomes choosing which subsidiaries get cash, which get acquired, which get spun off.

This is also the player arc's natural fourth stage:

> **Founder → Executive → Owner → Capital Allocator**

#### Forming the Holdco

The player triggers formation when they're ready. Steps:

- Choose a name (Magnate Holdings, Apex Industries, Frontier Capital, etc.)
- Choose a structure type:
  - **Operating holdco** (Berkshire-style) — actively manages subs; deep synergies; slower to spin off
  - **Pure investment holdco** (PE-style) — hands-off; treats subs as portfolio investments
  - **Strategic holdco** (Alphabet-style) — distinct mission per sub; lighter integration
- Subs roll up — each becomes a subsidiary of the new parent
- A new governance layer emerges: holdco board, holdco CEO (probably you), holdco CFO

Each structure trades integration depth for flexibility. Operating holdcos extract more synergy but face more bureaucratic drag.

#### The Capital Allocation Pool — the Core Mechanic

Profitable subs throw off cash to the parent through dividends and retained earnings sweeps. The holdco accumulates a treasury. Each quarter, the player decides where to deploy it:

- **Fund a struggling sub** — buy time for a turnaround
- **Acquire new companies** — bolt on adjacent businesses
- **Incubate new subs** — start companies inside the holdco using internal capital
- **Buy back holdco shares** — return capital, signal undervaluation
- **Pay holdco dividends** — shareholders get cash
- **Hold cash** — wait for opportunities (Buffett's "elephant gun")
- **Move to personal portfolio** — convert holdco cash to your personal wealth (tax implications apply)

This is the heart of the late-game loop. Reading the dynamic world (per Section 12), spotting opportunities, and timing deployment is what great capital allocators do. **This mechanic IS the realization of the Berkshire fantasy.**

#### Cross-Subsidiary Synergies

Owning paired subs unlocks visible bonuses (callbacks to the cross-industry synergies in Section 5):

- **Technology sharing** — your AI sub powers your Space sub's autonomy; your Biotech sub uses your AI sub for protein design
- **Customer sharing** — your Defense sub's DoD relationships open doors for your Space sub
- **Talent rotation** — move a top exec from a struggling sub to a growing one
- **Procurement leverage** — buy compute, chips, or materials at consolidated scale
- **Brand halo** — a strong holdco brand raises trust for new subs

Each pair gives a small effect. Cumulatively, a well-paired conglomerate has real edge.

#### Shared Services

Centralize legal, finance, HR, and IT at the parent:

- **Cost savings** — one legal team beats many
- **Loss of responsiveness** — sub-specific needs get less attention
- Player tunes the centralization slider per service; sensible defaults ship

#### Tax Efficiency

Consolidated tax filing lets losses in one sub offset gains in another. Effective tax rate drops by ~3–8 percentage points vs. separate filings. This compounds once you're profitable across multiple subs.

#### Holdco-Level Financing

Capital raises now happen at the parent:

- **Holdco bonds** — debt issued by the parent at favorable rates due to diversification
- **Sub equity as collateral** — borrow against the value of your subs
- **Cross-collateralization** — raise more cheaply than any single sub could alone

This is how real conglomerates achieve disproportionate financial firepower.

#### M&A as the Holdco's Core Activity

Once formed, the holdco becomes an acquisition platform:

- **Friendly acquisitions** — negotiate purchase; target board agrees
- **Hostile takeovers** — accumulate public shares quietly until you can force a vote
- **Stock-for-stock deals** — use holdco shares as currency (only works if your stock trades at a premium)
- **Tender offers** — public bids for control of a target

Each acquisition triggers integration choices: fold the target into an existing sub, or keep it standalone?

#### Spin-offs

The reverse move: separate a sub back into a standalone company.

- Distribute sub shares to existing holdco shareholders
- Sub becomes independently traded (if public) or independently owned
- **Why spin off?** Sometimes the sum of parts is worth more separated (conglomerate discount). Sometimes a sub doesn't fit strategy anymore. Sometimes activist pressure forces your hand.
- Trade-off: lose synergies, gain focus, often unlock value

#### Going Public — the Berkshire Endgame

You can IPO the holdco itself. Distinct mechanics from a regular IPO:

- **Conglomerate discount applies** — public market typically values diversified holdcos at 80–95% of the sum of the parts. Realistic, and creates strategic tension.
- **Dual-class share structure** — Berkshire-style Class A (your control shares) + Class B (public liquidity). You can run it indefinitely without losing control.
- **Annual shareholder letter** — flavor mechanic. The player writes a few lines each year that surface in the news cycle and modestly affect stock price. Iconic, deeply satisfying for the Buffett-coded player.

#### Risks of the Holdco Structure

Real downsides keep the late game tense:

- **Conglomerate discount** — public market punishes complexity
- **Activist pressure** — when the discount widens, activists agitate for spin-offs (procedural events)
- **Bureaucratic drag** — decisions slow as layers multiply
- **Cross-sub contagion** — scandal at one sub damages the whole; your holdco stock tanks even when other subs are fine
- **Internal politics** — sub CEOs fight for capital allocation; coalitions form
- **Regulatory scrutiny** — at extreme scale, antitrust attention
- **Second-derivative problem** — at huge scale, a single great sub no longer moves the needle for the whole

These risks scale with size. A 5-sub holdco has minor friction; a 30-sub mega-conglomerate has real drag — and that drag is the natural ceiling on uncontrolled empire-building.

#### UI: The Holdco Dashboard

When the holdco is active, a new top-level view appears (replacing or augmenting the Companies tab):

- **Consolidated financials** — revenue, profit, cash, debt, market cap
- **Subsidiary grid** — mini-status per sub (revenue trend, profit, runway, key issues)
- **Capital allocation interface** — visual deployment of treasury cash across subs and opportunities
- **Synergy opportunities** — flagged paired moves
- **M&A pipeline** — current acquisition targets with diligence stage
- **Annual letter editor** — when public

This becomes the player's "command center" at scale.

#### How the Gameplay Rhythm Changes

Forming the holdco visibly shifts the rhythm:

- Daily/weekly decisions decrease; **quarterly capital allocation** becomes the meta-game
- Sub CEOs run their companies under delegation; you supervise via quarterly reports
- Time horizon shifts — you're thinking in years, not weeks
- The dashboard shows fewer urgent alerts, more strategic options
- News and macro signals matter more (you're betting on cycles, not on customer counts)

This is the late-game feature, not a bug. The pacing should slow and the decisions should grow heavier as you scale.

#### MVP Phasing

Holdco core mechanics enter in **V2.0** ("Conglomerate Era") — the natural fit, alongside multi-industry play and the full executive layer:

- V1.0 — single company, founder mode (no holdco)
- V1.5 — multi-company play unlocks; basic delegation
- V2.0 — **holdco system unlocks** at 3+ controlled companies: capital allocation, synergies, shared services, tax efficiency, basic M&A, structure choice
- V2.5 — public holdco listing, dual-class shares, annual letter, activist mechanics
- V3.0 — advanced M&A (hostile takeovers), regulatory antitrust events, mega-conglomerate scale

---

## 7. Investment & Portfolio System

### Public Markets
- **Stock screen:** Hundreds of procedurally-named (with some real-feeling archetypes) public companies across all sectors, not just the three core industries.
- **Per-stock data:** Price chart, P/E, market cap, revenue, recent news, your position.
- **Order types:** Market, limit, stop-loss. (Options as a late-game unlock.)
- **Dividends, splits, buybacks** as quarterly events.
- **Index funds & ETFs** for passive players who want broad exposure.

### Private Markets
- **Angel investments:** Small checks ($25K–500K) into procedurally-generated startups. High failure rate, occasional 100x.
- **LP positions in VC funds:** Set-and-forget; returns over 7–10 game years.
- **Direct investments:** Lead or follow rounds in private companies. Requires capital + reputation.
- **Liquidity:** Private positions are locked until exit (acquisition, IPO, write-off). Secondary market unlocks late game.

### Your Own VC Fund (Late Game)
- **Fund formation:** Raise from LPs (procedural family offices, pensions, sovereign wealth, you can be the GP + anchor LP).
- **Fund economics:** 2/20 (2% management fee, 20% carry) is the default; can be negotiated.
- **Deal flow:** You see startups pitching you. Pick which to fund. Build a portfolio across stages and sectors.
- **Reputation feedback loop:** Good returns → easier to raise Fund II → bigger checks → bigger wins.
- **End state:** Player can be a founder, public company executive, *and* GP of a top-decile fund simultaneously.

---

## 8. Governance & Influence

This is where ownership turns into power. Use the thresholds you proposed:

| Threshold | Right Unlocked |
|---|---|
| 1% (public) | Receive shareholder communications, attend annual meetings |
| 5% (public) | Schedule 13D filing, can submit shareholder proposals, activist status |
| 10% (public) | Insider trading rules apply; can call special meetings |
| 20%+ (public) | Effective control consideration; FTC review on further accumulation |
| 20% (private) | Can recommend strategic ideas to leadership; observer board status |
| 33% (private) | Blocking minority on major decisions |
| 50%+ | Control |

### Board Mechanics
- Board seats are negotiated at fundraising or won via shareholder vote
- Board votes appear as discrete decisions: M&A approvals, exec comp packages, dividend policy, strategic pivots
- Each board member has a personality (financially-driven, mission-driven, risk-averse, etc.) that you can model with roll-based voting
- Player's vote weight depends on seat — and persuasion via earlier 1:1 lobbying

### Recommending Strategies
- At ≥20% private / ≥5% public, the player can submit *recommendations*: a new product line, a hiring push, an acquisition target, a market exit
- Management evaluates recommendations based on fit, founder relationship, board support, and current company state
- Successful adoption = you helped steer a company you don't fully control. This is where the *influence* fantasy lives.

---

## 9. Personal Wealth & Lifestyle

The "magnate" leg of the stool. Treat these as collectibles + status systems, not just money sinks.

### Real Estate
- **Properties:** Apartments, houses, mansions, ranches, private islands across global cities (NYC, SF, LA, London, Singapore, Dubai, Aspen, Hawaii)
- **Each property:** Purchase price, current market value (fluctuates with city's market), maintenance cost, prestige score
- **Flipping & appreciation:** Real estate as an investment class with its own cycle
- **Functional bonuses:** Owning property in a city unlocks easier deal flow there (you have a base of operations)

### Vehicles & Toys
- **Cars:** From Civic to Bugatti to Pagani. Some appreciate (collector market for limited editions).
- **Yachts, jets, helicopters:** Massive ongoing costs; pure status purchases with mild functional bonuses (faster travel between cities = more meetings per game-month).
- **Art collection:** Auction events, appreciation, prestige.

### Personal Development
- **Education:** MBA at Stanford / Harvard / Wharton — boosts certain stats (negotiation, finance, network)
- **Skill points:** Earned by experience, allocated to operator / investor / dealmaker / public-figure trees

### Status Effects (the secret sauce)
Lifestyle isn't just vanity — high status unlocks:
- Better deal flow (top founders pitch *you*, not cold inbound)
- Lower interest rates on personal loans
- Invites to Davos / Sun Valley / Allen & Co. (annual events that gate certain plot beats)
- Press coverage that swings stock prices when you speak

---

## 10. Philanthropy

Underrated mechanic that ties everything together.

- **Recipients:** Universities, hospitals, churches, museums, foundations, political causes, scientific research, climate, AI safety, etc.
- **Mechanics:** Lump sum donation, endowment, named building/wing, foundation creation
- **Reputation:** Each donation builds long-term reputation in specific spheres (academic, religious, political, medical)
- **Tax efficiency:** Donations reduce taxable income; donor-advised funds and foundations let you defer/optimize
- **Naming rights:** "The [Player Name] Center for Computational Biology at MIT" — these persist across save file as visible legacy
- **Mission alignment:** Donating to AI safety while running an AI company gives you talent recruiting bonuses; donating to gene therapy research unlocks academic partnerships

---

## 11. Procedural Events Engine

The engine that keeps every save unique. Events fire at multiple scales:

### Macro (global, affects everything)
- Recessions, expansions, rate cycles, oil shocks, pandemics, wars, election cycles
- Each has duration, severity, sector-specific impact multipliers
- Long-tail rare events (financial crisis, AI winter, pandemic) reshape the world for 1–3 game years

### Industry-level
- **Space:** Launch failures from competitors, new propulsion breakthroughs, asteroid mining IPO wave
- **AI:** Open-source releases that commoditize moats, copyright rulings, breakthrough scaling laws, talent exoduses
- **Gene editing:** FDA approval waves, ethical scandals, breakthrough modalities (mRNA-style step changes)

### Company-specific
- Founder scandal, product launch reception, key hire poached, lawsuit, partnership, acquisition offer

### Personal
- Health events, marriage/divorce (divorce should genuinely sting financially), media exposes, legal trouble, kidnapping (rare, late-game ultra-wealth tax)

### Engineering Approach
- Event templates with parameter ranges (severity, scope, duration, affected entities)
- Weighted scheduler with cooldowns to prevent same event spamming
- Player choices in early events influence later event probabilities (consequence chains)
- A "world memory" of past events keeps the simulation coherent

---

## 12. Economy Simulation — The Dynamic World Model

This is the core spine of replayability. The goal is a world where:

- **Some forces are persistent** (always influence good/bad outcomes — interest rates always affect valuations, FDA always slows biotech)
- **Some forces are procedural** (vary every save — which industries are hot right now, when the next recession hits, what black swans show up)
- **Forces interact via feedback loops** (capital flows toward hot sectors → valuations inflate → mediocre companies get funded → eventually the bubble pops)

The result: every game has the same physics, but a different weather pattern.

### Design Goals

1. **Realistic enough** that finance/sim players respect it
2. **Variable enough** that no two games feel the same
3. **Forgiving enough** that good decisions reliably outperform bad luck over a long playthrough
4. **Legible** — the player can read the environment and adapt; the world isn't a black box

The third point is the key tension. Total realism means most startups fail — that's not fun. Total fairness means everyone wins — that's not interesting. The right answer: **skill compounds, RNG creates texture but doesn't dominate over a 20–30 year game.**

---

### The Three-Layer Model

#### Layer 1: Persistent Forces (the "physics" — always on)

These never change between saves. They give the world consistency and let players build intuition.

- **Interest rates compress/expand multiples.** Low rates → higher valuations across the board. Always.
- **Capital intensity is industry-fixed.** Space is always expensive. Software is always cheap.
- **Regulatory drag is industry-fixed.** Biotech trials always take years. AI always moves fast.
- **Talent scarcity has industry-specific shape.** Top AI researchers are always rare; top mfg engineers are abundant but specialized.
- **Binary risk is industry-fixed.** Rocket launches always have failure probability. Phase III trials always have ~50% pass rate.
- **Public market mean-reverts.** P/E ratios always pull toward historical norms over time.
- **Macro feedback loops always work.** Inflation → rate hikes → valuation compression → harder fundraising.
- **Reputation compounds.** Whether you're playing in a boom or bust, having credibility always helps you raise.

These give the player something stable to learn. After a few games, they internalize "low rates = raise more, high rates = focus on revenue."

#### Layer 2: Procedural Variables (the "weather" — varies every save)

These are randomized at game start and evolve over time. They're what makes save 1 feel different from save 2.

**Set at game start:**
- **Macro starting state:** boom / mid-cycle / late-cycle / recession (weighted toward mid-cycle)
- **Industry hype scores** (0–100 each) for all 8 industries — independently rolled
- **Industry cycle phases** — each industry is in cold / heating / peak / cooling
- **VC climate score** (0–100) — global capital availability
- **IPO window state** — open / cracking / closed
- **Public market valuation level** — undervalued / fair / overvalued
- **Pre-scheduled macro events** — the next 1–3 major events (recession, war, pandemic) have rough timing slotted at game start

**Evolve over time:**
- All scores drift via mean reversion + event impacts
- Cycles transition based on duration + triggers
- New procedural events get scheduled as old ones expire

The pre-scheduling matters. If you randomly roll "is there a recession?" every tick, the macro feels jittery and incoherent. Instead: at game start, schedule "recession in year 7–9 of magnitude moderate." Build toward it with leading indicators players can read. This creates narrative coherence.

#### Layer 3: Dynamic Feedback Loops (how the weather changes)

These are what make the world feel alive over time.

**Capital reflexivity** *(the most important loop)*
1. Industry has a string of big exits → hype score rises
2. VCs raise more sector-focused funds → capital available rises
3. Valuations inflate → more founders enter the space
4. Quality of new companies degrades (everyone gets funded, including marginal ones)
5. Some marginal companies fail spectacularly → hype drops
6. Capital exits → valuations compress → bubble deflates
7. Survivors emerge stronger → cycle restarts

This loop runs on a 4–7 year period per industry, asynchronously. At any given time, some industries are heating, some peaking, some cooling.

**Talent migration**
- Hot sector pulls engineers from cold sectors
- Salaries in hot sector inflate (AI researchers at $5M/yr in peak hype)
- Cold sectors can hire talent cheap if they can convince anyone to come
- When hype rotates, talent flows back

**Regulatory backlash cycle**
- Industry has scandal/failure → regulators tighten
- New rules slow companies for 1–3 years
- Industry adapts, lobbies, regulators eventually loosen
- Cycle repeats

**Macro cycle**
- 8–12 year economic cycle (boom → late-cycle → recession → recovery)
- Drives interest rates, IPO windows, VC climate
- Each phase has different optimal player strategy

---

### The Five Master Variables (Player-Visible)

Most of the underlying state is hidden, but the player should see five top-line indicators that summarize the world:

| Variable | Range | What it does | Where shown |
|---|---|---|---|
| **Macro Cycle Phase** | Boom / Mid / Late / Recession | Drives everything indirectly | Macro dashboard |
| **VC Climate** | 0–100 | Capital availability for fundraising | Fundraising screen, dashboard |
| **IPO Window** | Open / Cracking / Closed | Whether public exits are viable | Exit planning screen |
| **Industry Hype** | 0–100 per industry | Sector multiples, fundraising ease, talent costs | Sector heat map |
| **Interest Rate** | 0–15% | Discount rate for everything | Macro dashboard |

These five are the player's "weather report." Reading them well is a skill that compounds across playthroughs.

---

### Master Variables: Full Formulas

The five master variables form a dependency hierarchy with explicit formulas. These numbers are starting points; playtest will tune them, but they should converge faster from these anchors than from scratch.

```
Macro Cycle Phase (prime mover)
  ↓
Interest Rate (Fed responds to macro)
  ↓
VC Climate (responds to macro + rates + recent exits)
  ↓
IPO Window (responds to VC Climate + public market state)

Industry Hype × 8 (responds to macro + events + cross-industry contagion)
```

#### 1. Macro Cycle Phase

**Range:** `Boom` / `Mid` / `Late` / `Recession` / `Recovery` (5 discrete states)

**Underlying continuous state (hidden):**
- `gdpGrowth` (annualized): `-5%` to `+6%`
- `inflation`: `0%` to `12%`
- `unemployment`: `3%` to `12%`
- `consumerConfidence`: `30` to `130`

**Update cadence:** Monthly tick with quarterly settling. Continuous variables drift monthly; phase reassignment evaluated quarterly.

**Phase definitions (rules-based):**

```
Boom:       gdpGrowth > 3.5% AND consumerConfidence > 100 AND unemployment < 5%
Mid:        gdpGrowth 1.5-3.5% AND unemployment 4-6%
Late:       gdpGrowth 1-3% AND inflation > 4% AND unemployment < 5%
Recession:  gdpGrowth < 0% AND unemployment > 6%
Recovery:   gdpGrowth 0-3% AND unemployment trending down AND previous phase = Recession
```

**Phase duration** is procedurally drawn at game start from ranges modulated by the **Cycle length sub-slider** (see Section 12 Difficulty Sliders for the table).

**Transition logic:** When a phase nears its scheduled end, leading indicators appear in the news feed. Phase transitions are *gradual* — continuous variables shift over 4–8 weeks rather than flipping overnight.

**Black swan handling:** Procedural shocks (recessions, wars, pandemics) can force phase transitions outside the schedule. Pre-scheduled at game start with rough timing windows.

**Player sees:** Current phase as a badge + brief description. Hover shows the four continuous variables as small sparklines over the last 24 months. Easy news mode shows plain-language inputs; Hard mode just the phase badge.

#### 2. Interest Rate

**Range:** `0%` to `15%` (clamped, realistic gameplay range `0–8%`)

**Update cadence:** Quarterly. Matches real Fed meeting cadence. Mid-quarter changes only via shock events.

**Formula (Taylor-rule-derived):**

```
targetRate = neutralRate
           + 1.5 × (inflation - inflationTarget)
           + 0.5 × (gdpGrowth - potentialGrowth)

Where:
  neutralRate     = 2.5%
  inflationTarget = 2%
  potentialGrowth = 2%

Then clamp: max(0%, min(15%, targetRate))
```

**Movement rules:**
- Quarterly change at most `0.75 pts` either direction (matches real Fed pacing)
- The Fed moves gradually toward `targetRate`
- In Recession phase, rate can cut faster (up to `1.5 pts/quarter`)

**What it modulates:**
- VC Climate: low rates raise it
- Public market valuations: low rates raise P/E multiples
- IPO Window: rate spikes can crack it
- Personal/company borrowing costs

**Player sees:** Current rate as a number with trend arrow + 24-month sparkline. Easy news mode adds Fed reasoning narrative.

#### 3. VC Climate

**Range:** `0–100`

**Update cadence:** Weekly drift with monthly settling.

**Formula:**

```
vcClimate = 50 (baseline)
         + macroPhaseModifier      // -25 to +25
         + interestRateModifier    // -15 to +10 (inverse: low rates boost)
         + recentExitsModifier     // -10 to +15
         + sentimentMomentum       // -10 to +10
         + recentScandalModifier   // -10 to 0
         + clamp(weeklyNoise, -3, +3)

Then clamp 0-100
```

**Modifier ranges:**
- **Macro phase:** Boom +25, Mid +5, Late -5, Recession -25, Recovery +5
- **Interest rate:** rate 0–2% → +10; 2–4% → 0; 4–6% → -5; 6–8% → -10; >8% → -15
- **Recent exits:** rolling 12-month IRR average. High returns boost; failed IPOs/down rounds drag.
- **Sentiment momentum:** 8-week momentum on the score itself — creates trends
- **Recent scandals:** major industry scandals pull down for 4–12 weeks

Sub-slider modulations from "Bull market intensity" and "Bear market severity" set the baseline floors and ceilings (e.g., Frothy bull mode raises Boom baseline to +35; Severe bear mode floors Recession at 5 instead of 15).

**Categorical display:**
- 0–25: "Frozen" (red)
- 25–45: "Cool" (amber)
- 45–60: "Normal" (neutral)
- 60–80: "Hot" (light green)
- 80–100: "Frothy" (green with bubble-warning vibe)

**What it modulates:** Fundraising difficulty, valuation multiples, round closing speed, term harshness (per Section 6 fundraising design).

**Player sees:** Categorical label + numeric gauge with current position. Easy news mode reveals modifier breakdown on click. Hard mode shows current value only.

#### 4. IPO Window

**Range:** `Open` / `Cracking` / `Closed`

**Update cadence:** Event-driven, with weekly evaluation of trigger conditions.

**Trigger logic:**

```
Rolling 6-month signals:
  successRate     = % of IPOs trading above issue price at +30 days
  avgFirstDayPop  = average first-day return across recent IPOs
  volatility      = public market volatility index

Open conditions:
  successRate ≥ 60% AND avgFirstDayPop > 0% AND volatility < 25
  AND macroPhase ∈ {Boom, Mid, Recovery}

Cracking conditions:
  successRate 40-60% OR avgFirstDayPop -10% to 0% OR volatility 25-35

Closed conditions:
  successRate < 40% OR avgFirstDayPop < -10% OR volatility ≥ 35
  OR macroPhase = Recession
```

**State persistence:** Once a state is reached, must hold for at least 8 weeks before transitioning. Prevents whiplash.

**Cold-start state:** Game starts with state seeded by Decision F (procedural + difficulty-aware).

**What it modulates:** Whether players can IPO at all, and at what discount/premium. Closed window doesn't fully prevent IPOs — underwriter quotes drop 40–60% so players face the choice between bad terms or waiting.

**Player sees:** Big colored badge in dashboard. Easy mode shows recent IPO stats and trigger conditions. Hard mode just the badge.

#### 5. Industry Hype (one per industry)

**Range:** `0–100` per industry

**Update cadence:** Weekly drift; major events can shock it.

**Formula:**

```
For each industry:
hype_t = hype_(t-1)
      + (baseline - hype_(t-1)) × meanReversionRate
      + macroPhaseModifier
      + recentExitsModifier
      + recentEventsModifier
      + crossIndustryContagion
      + clamp(weeklyNoise, -2, +2)

Then clamp 0-100
```

**Mean reversion rates by industry** (different cycle speeds per Section 5):

| Industry | Mean Reversion Rate | Phase Duration |
|---|---|---|
| AI | 0.015 | 2–3 yr (fast) |
| Manufacturing | 0.012 | 3–4 yr |
| Mobility | 0.012 | 3–4 yr |
| Defense | 0.010 | 3–5 yr |
| Space | 0.008 | 4–5 yr |
| Energy & Climate | 0.007 | 6–8 yr |
| Biotech | 0.006 | 5–7 yr (slowest) |
| Quantum | 0.005 | 8+ yr (mostly stable, rare spikes) |

These are modulated by the **Mean reversion speed** sub-slider — Slow setting halves these rates, Fast setting doubles them.

**Baseline values:** All start at `50` baseline by default. Sustained sector-defining events can drift baseline ±5–10 points permanently (a fundamental breakthrough; structural regulatory shift).

**Modifier sources:**
- **Macro phase:** Boom +10, Mid 0, Late 0, Recession -10, Recovery +5
- **Recent exits in industry:** big exit pushes +5 to +15; failed IPO -3 to -8
- **Recent events:** industry-specific (breakthrough +10 to +20; scandal -8 to -15; regulatory crackdown -10)
- **Cross-industry contagion:** ~30% of changes in correlated industries spill over

**Cross-industry contagion pairs:**
- AI ↔ Quantum (technical correlation)
- Space ↔ Defense (customer/contract overlap)
- Energy ↔ Mobility (battery/infrastructure correlation)
- AI ↔ Biotech (computational drug discovery)
- AI ↔ Manufacturing (AI chips and automation)

**Categorical display:**
- 0–20: "Cold"
- 20–40: "Cool"
- 40–60: "Warm"
- 60–80: "Hot"
- 80–100: "Peak" (bubble-warning vibe)

**What it modulates:**
- Fundraising valuations within that industry: Hot = 1.4× comps; Cold = 0.6× multiplier
- IPO premium/discount for that sector
- Talent acquisition cost (Hot = higher salaries)
- Customer demand for products in that sector
- Public market sector P/E ratios

**Player sees:** Sector heat map showing all 8 industries with hype category + trend arrow. Hovering shows score + recent driving events. Easy mode adds plain-language input summary.

#### Inter-Variable Cascade Example

A typical recession cascade:

```
1. Recession scheduled to fire Y8 (set at game start)
2. Y7 W30: Leading indicators surface — yield curve inverts, late-cycle signals
3. Y7 W45: gdpGrowth crosses 0%, unemployment ticks up
4. Y8 W2: Macro Phase transitions to Recession
5. Y8 W6: Interest Rate begins cutting (1.5 pts/quarter pace)
6. Y8 W8: VC Climate drops from 65 to 30 over 4 weeks (recent exits dry up, sentiment crashes)
7. Y8 W12: IPO Window transitions Open → Cracking, then Y8 W20: Cracking → Closed
8. Y8 W4–Y8 W20: Industry Hype across most sectors drops 15–30 points
   — Defense and Biotech less affected (counter-cyclical)
   — AI and Mobility hit hardest (consumer-discretionary tech)
9. Y9–Y10: Bottom; survival mode for the player
10. Y10–Y11: Recovery phase begins as variables rebuild
```

This cascade isn't scripted — it emerges from the formulas. Different black swans produce different cascade shapes.

#### Hidden vs. Visible Recap

| State | Always Visible | Hover | Click | Hidden in Hard Mode |
|---|---|---|---|---|
| Macro Phase | Badge | 24-mo sparkline | Easy: input breakdown | Exact GDP/inflation/unemployment values |
| Interest Rate | Current % + arrow | 24-mo history | Easy: Fed reasoning | Target rate calculation |
| VC Climate | Categorical + gauge | 12-mo trend | Easy: modifier list | Exact 0-100 score |
| IPO Window | Badge | Recent IPO stats | Easy: trigger conditions | Exact thresholds |
| Industry Hype | Heat map (categorical) | Score + events | Easy: input breakdown | Mean reversion math |

This serves finance-curious players satisfying depth and casual players a clean read.

---

### Procedural Black Swans (Layered on Top)

In addition to the macro cycle, ~10–15 black swan events are seeded at game start with rough timing windows:

- Pandemic
- Major war
- Financial crisis
- Energy shock
- Major sector crash (one industry's bubble bursts)
- Geopolitical realignment (sanctions, trade war)
- Surprise breakthrough (one sub-industry leaps forward)
- Surprise failure (a darling sub-industry collapses)
- Regulatory hammer (one industry hit hard)
- Cultural backlash (one industry becomes politically toxic)

Across a 30-year game, expect 4–8 of these to actually fire. Each has industry-specific impacts. Variance in *which* black swans fire and *when* is a major driver of replayability.

**Rule:** The game schedules these at game start with rough windows but doesn't pre-tell the player. Leading indicators surface in news feeds 6–18 months before fire. Attentive players can prepare; inattentive players get surprised.

---

### Three Sample Game Narratives

These should all be possible from the same systems:

**Game A — "Bubble Founder."** You start in late-cycle euphoria. AI hype is 92, VC climate is 88. You found a frontier model lab and raise a $400M Series A at $4B post — terms that would be insane in any other environment but look normal here. Year 4: the AI bubble pops (scheduled black swan), sector hype crashes to 35. You'd burned aggressively, but you raised so much in good times that you survive. By year 8, AI is heating again and you IPO at $25B.

**Game B — "Recession Founder."** You start in a recession. Every score is depressed. You bootstrap an AI vertical SaaS for 18 months because no one will fund you. By year 3 macro recovers, you raise a Series A at unimpressive terms but with strong revenue. The recession-trained discipline becomes your moat — you reach $100M ARR while bubble-era competitors flame out.

**Game C — "Defense Cycle."** Year 2: war breaks out (procedural). Defense Tech hype rockets from 45 to 85. You pivot your AI company into defense AI. Government contracts pour in — $200M in year 3 alone. By year 5 you're a major prime contractor. Year 7: peace treaty. Defense budgets get cut. You've already used the war years to diversify into civilian autonomy.

If your systems can't produce all three of these from the same rule set, the design isn't dynamic enough.

---

### What the Player Sees (UI Surfaces)

To make the world legible without overwhelming, expose state through six specific screens:

1. **Sector Heat Map** — 8-cell grid, color + trend arrow per industry. The single most useful screen.
2. **Macro Dashboard** — GDP / inflation / rates / unemployment as 5-year sparklines. Cycle phase badge.
3. **Comparables Widget** — "Recent Series A in your sub-industry: median $8M / $32M post." Updated continuously based on procedural events.
4. **News Feed** — Headlines that telegraph shifts. ("Sequoia raises $5B AI-focused fund" = AI hype rising. "Three biotech IPOs delayed" = window cracking.)
5. **VC Climate Indicator** — Single 0–100 gauge with directional arrow, on the fundraising screen.
6. **Comp Tearsheet** — When fundraising, show recent comparable rounds in your sub-industry as anchor data.

Together these let a thoughtful player read the room. A casual player can ignore them and just react to events.

---

### Difficulty: Sliders + News Cycle Selector

Rather than locked Easy/Medium/Hard presets, give players **independent sliders** to tune world variance, plus a **dedicated news cycle selector** that controls how clearly the world telegraphs what's coming. These are orthogonal axes — a player can want a brutal world but still want clear news, or a forgiving world with cryptic news. Both should be possible.

#### World Variance Sliders (per save, locked once started)

A **hierarchical** slider system with progressive disclosure: 8 top-level sliders are always visible; each expands to reveal 2–4 sub-sliders for power users who want to dial in their exact world.

##### Top-Level Sliders (default view)

Eight continuous sliders, each roughly 1–10 with sensible defaults at 5:

| Slider | Low end | High end | What it controls |
|---|---|---|---|
| **Macro Volatility** | Mild | Brutal | Recession depth, cycle severity, interest rate swings |
| **Black Swan Frequency** | Rare | Constant | How often pandemics, wars, crises, sector crashes fire over 30 years |
| **Sector Volatility** | Stable | Wild | Magnitude of industry hype swings; how fast bubbles form and pop |
| **Fundraising Difficulty** | Founder-Friendly | Investor-Friendly | Term harshness, valuation generosity, close rates |
| **Operating Difficulty** | Forgiving | Punishing | Burn rate sensitivity, customer demand stickiness, churn rates |
| **Binary Event Variance** | Predictable | Random | Launch and trial outcomes closer to expected odds vs. wild |
| **Starting Capital** | $5M | $25K | Direct cash floor — biggest single difficulty lever |
| **Tax & Cost Burden** | Light | Heavy | Corporate tax, personal tax, overhead, regulatory compliance costs |

**Three preset bundles** for players who don't want to fiddle:
- **Forgiving** — sliders biased low; for casual or first-time players
- **Realistic** — defaults across the board; the recommended experience
- **Brutal** — sliders biased high; for sim veterans who want to suffer

##### Sub-Sliders (revealed via "Advanced" expand)

Each top-level slider expands into a card showing its sub-sliders. The top-level slider's position determines the *defaults* for its sub-sliders, but each sub-slider can be independently overridden. Adjusting a sub-slider adds a small "(custom)" indicator next to its parent top-level slider.

This serves three player segments without forcing complexity on anyone:
- **Casual:** picks a preset, starts game
- **Engaged:** adjusts top-level sliders, starts game
- **Power user:** dives into sub-sliders, tunes the exact world they want, starts game

**Macro Volatility expands to:**
- **Cycle length** — Short (5–7 yr) / Realistic (8–12 yr) / Long (12–18 yr)
- **Bull market intensity** — Mild / Realistic / Frothy
- **Bear market severity** — Mild recessions / Realistic / Severe
- **Recovery speed** — Fast (V-shaped) / Realistic (U-shaped) / Slow (L-shaped, 1990s/2008-style)

**Black Swan Frequency expands to:**
- **Recessions** — Rare / Realistic / Frequent
- **Wars / geopolitical shocks** — Rare / Realistic / Frequent
- **Pandemics / disasters** — Rare / Realistic / Frequent
- **Industry-specific shocks** — Rare / Realistic / Frequent

**Sector Volatility expands to:**
- **Hype amplitude** — Stable / Realistic / Wild swings
- **Mean reversion speed** — Slow / Realistic / Fast
- **Cross-sector contagion** — Isolated / Realistic / Strong contagion
- **Bubble formation likelihood** — Rare / Realistic / Frequent

**Fundraising Difficulty expands to:**
- **Investor patience** — Patient / Realistic / Demanding
- **Term harshness** — Founder-friendly / Realistic / Investor-friendly
- **Comp anchoring strength** — Loose / Realistic / Strict (how rigid comparable rounds are as anchors)

**Operating Difficulty expands to:**
- **Customer demand stickiness** — High / Realistic / Volatile
- **Burn rate sensitivity** — Forgiving / Realistic / Punishing
- **Talent retention** — Easy / Realistic / Hard (affects flight risk and poaching frequency)

**Binary Event Variance expands to:**
- **Launch success rates** (Space) — Predictable / Realistic / Wild
- **Other binary events** (regulatory approvals, etc.) — Predictable / Realistic / Wild
- **(Future)** Trial outcomes for Biotech industry (arrives with Frontier DLC)

**Starting Capital expands to:**
- **Personal cash** — Continuous slider $25K to $5M
- **Network strength** — Cold start / Average / Well-connected (affects investor warmth)
- **Industry experience** — None / Some / Veteran (affects starting reputation)

**Tax & Cost Burden expands to:**
- **Corporate tax** — Continuous slider 15% to 35%
- **Personal tax** — Continuous slider 20% to 50%
- **Regulatory compliance cost** — Light / Realistic / Heavy
- **Office/facility costs** — Cheap / Realistic / Expensive

##### Specific Modulation: How Cycle and Bull/Bear Sub-Sliders Affect the Macro Engine

The **Cycle length** sub-slider modulates phase duration ranges:

| Position | Boom | Mid | Late | Recession | Recovery | Total |
|---|---|---|---|---|---|---|
| Short (5–7 yr) | 1–2 yr | 2–3 yr | 0.5–1 yr | 0.5–1 yr | 0.5–1 yr | 5–7 yr |
| Realistic (8–12 yr) | 1.5–3 yr | 3–5 yr | 1–2 yr | 0.5–2 yr | 1–2 yr | 8–12 yr |
| Long (12–18 yr) | 2–4 yr | 5–8 yr | 1.5–3 yr | 1–3 yr | 1–3 yr | 12–18 yr |

The **Bull market intensity** sub-slider modulates Boom phase variables:

| Position | GDP growth | VC Climate baseline | Hype baseline modifier |
|---|---|---|---|
| Mild | 2.5–4% | +15 | +5 |
| Realistic | 3.5–5% | +25 | +10 |
| Frothy | 4–6% | +35 | +18 |

The **Bear market severity** sub-slider modulates Recession phase variables:

| Position | GDP contraction | Unemployment peak | VC Climate floor | Hype crash magnitude |
|---|---|---|---|---|
| Mild recessions | -1 to -2% | 6–8% | 25 | -15 |
| Realistic | -2 to -4% | 7–10% | 15 | -25 |
| Severe | -3 to -6% | 9–12% | 5 | -40 |

The **Recovery speed** sub-slider modulates Recovery phase pace:

| Position | Recovery duration | GDP rebound | Unemployment decline rate |
|---|---|---|---|
| Fast (V-shaped, 2020-style) | 0.5–1 yr | sharp | -1 pt/quarter |
| Realistic (U-shaped) | 1–2 yr | gradual | -0.5 pt/quarter |
| Slow (L-shaped, 1990s/2008-style) | 2–4 yr | sluggish | -0.25 pt/quarter |

##### UI Pattern

The new-game setup screen and the in-game difficulty panel:

- **Default view:** 8 top-level sliders + three preset buttons (Forgiving/Realistic/Brutal) + a "Random world" button that procedurally generates a coherent slider set
- **Advanced toggle:** Each top-level slider expands into a card showing its sub-sliders. Sub-sliders can be reset to top-level defaults with one click.
- **Visual feedback:** As player adjusts sliders, a small "world preview" panel shows projected cycle length, expected recessions in 30 years, expected fundraising difficulty tier — so players know what they're picking before they start

Sliders **lock when a save begins** so players can't crank to Easy mid-recession. Want different difficulty? Start a new game.

#### News Cycle Difficulty (separate selector — Easy / Medium / Hard)

This controls how much help the player gets reading the world. It scales *strategic* difficulty without making RNG harsher. Even on Hard News, the underlying world is the same — you just have less help interpreting it.

**Easy News** *(for players who want clear signals)*
- Headlines explicitly telegraph events 9–12 months out: "Analysts Warn of Recession Within a Year"
- Hype shifts get plain-language coverage: "Investors Cool on AI as Valuations Stretch"
- VC climate changes narrated: "Capital Pulls Back as Rates Rise"
- Comparable rounds widely advertised with full terms
- Black swans get clear warning shots: "Tensions Rising in Eastern Europe"

**Medium News** *(realistic mix)*
- Some headlines clear ("Sequoia Closes $5B AI-Focused Fund") and some ambiguous ("Analysts Divided on Tech Outlook")
- Leading indicators present but require interpretation
- Comparable rounds reported but with selective detail
- Black swans get partial telegraphing — the careful reader can spot it
- Mix of signal and noise

**Hard News** *(for sim veterans)*
- Subtle hints only
- Headlines often misleading or noisy ("Strong Quarter Despite Headwinds" two weeks before a crash)
- Have to actually read fundamentals — track sector ETFs, watch comparable round trends, monitor public market valuation indicators
- Black swans get minimal warning (1–2 months) or none
- The world isn't lying, but it isn't helping either

This separation matters. A player can run **Brutal world variance + Easy news** to get harsh-but-readable difficulty, or **Forgiving variance + Hard news** for a chill game where you still feel smart for predicting things. Both are valid play styles.

#### Hidden vs. Visible State

Hype scores, event schedules, and underlying calculations stay **hidden from the player at all difficulties**. The five master variables (Macro Phase, VC Climate, IPO Window, Industry Hype gauge, Interest Rate) are always visible — but their *causes* are not. The news cycle selector controls how much narrative interpretation the player gets, not whether the underlying numbers are exposed.

---

### Realistic But Not Punishing — Five Specific Rules

To hit "realistic but not too hard":

1. **No instant death from RNG.** Bad timing slows you, but a careful player can always survive. Even a closed IPO window doesn't kill you — you can stay private and grow revenue.
2. **Strategic counterplay always exists.** In bad climates: pivot to government contracts, focus on profitability, slow burn, M&A targets become cheap. The losing strategy is *not adapting*, not bad luck.
3. **Concentration risk is what kills you, not cycles.** A player who put 90% of net worth in one Space company is vulnerable to a launch failure. A player with portfolio breadth survives anything.
4. **Leading indicators always exist.** Black swans show up in the news feed before they fire. Macro shifts have lead time. Players who watch can prepare; players who don't, can't complain.
5. **Skill > luck over 30 years.** A good player should outperform a bad player ~85% of the time on equal seeds. RNG creates texture and stories, not outcomes.

---

### Architecture Recommendation (For When You Build)

**World state object** — single source of truth. Updated each tick (1 game-week or 1 game-month, your call — I'd start with 1 week).

```
WorldState {
  macro: { gdp, inflation, rates, unemployment, confidence }
  cyclePhase: enum
  industries: [8x { hype, cycleStage, capitalAvailable, talentCost }]
  vcClimate: float
  ipoWindow: enum
  scheduledEvents: [{ year, type, magnitude, sectors[] }]
  publicMarket: { p_e_avg, volatility, sentiment }
}
```

**Update loop each tick:**
1. Fire any scheduled events whose time has come
2. Update macro variables via Taylor-rule-ish function
3. Mean-revert hype scores; apply event impacts
4. Recompute derived signals (VC climate, IPO window)
5. Generate procedural news headlines based on what changed
6. Update all UI bindings

**Save format includes the full schedule** so reloading a game gives identical futures (deterministic from seed). Players who learn to read indicators feel rewarded; the world isn't lying to them.

**Tuning is the actual job.** Once the architecture is in place, you'll spend 3–6 months tuning: how fast does hype mean-revert, how big are event impacts, how often do black swans fire, how harsh are recessions. Ship-blocking work. Budget for it.

---

## 13. Progression & Meta Systems

### Net Worth Milestones (the spine)
$1M → $10M → $100M → $1B → $10B → $100B → $1T

Each milestone unlocks:
- Cosmetic title ("Millionaire" → "Centibillionaire")
- New starting options on next save (start with a small VC fund, start in a different decade, etc.)
- New endgame mechanics (private island, sovereign wealth involvement, geopolitical influence)

### Achievements
- "First IPO," "Unicorn Founder," "Decabillionaire," "Pulled an Elon" (run 3 companies simultaneously, each $10B+), "Pulled a Madoff" (?? — probably leave this one out)

### Steam Achievements & Leaderboards

- **50+ achievements** covering progression milestones, signature plays, and easter eggs (e.g., "First Unicorn," "Decabillionaire," "Pulled an Elon" for running 3 simultaneous unicorns, "Buffett Mode" for holdco capital allocator runs, "Clean Hands" for 30+ years without an ethics violation)
- **Steam-native leaderboards:** highest net worth at game year 10 / 20 / 30, fastest billion, largest exit, most companies founded, longest holdco-conglomerate streak
- Achievements seeded across difficulty tiers — some accessible to all players, some that require Brutal sliders + Hard news cycle so committed players have status to chase

### New Game Plus
- Carry over a percentage of net worth, or a starting investment portfolio
- Unlock harder difficulty modes

---

## 14. UI/UX (Steam-First Desktop)

Steam players expect data density. Reference the UIs they already love: Crusader Kings III (info-dense panels, character portraits), Football Manager (the apex of data density in any genre), Stellaris (galaxy view + drill-down), Bloomberg Terminal (the godfather of dense financial UI), Frostpunk (mood plus information). Embrace the desktop. Use the screen real estate.

### Layout: The Workspace Model

Single primary window divided into resizable panels. Players can rearrange to taste; we ship a sensible default.

**Default layout:**

- **Top bar (~50px):** Net worth ticker, current date, time controls (Advance Week / Month / Event), key world indicators (Macro Phase, VC Climate, IPO Window) as compact gauges.
- **Left sidebar (~250px, collapsible):** Navigation — Dashboard, Companies, Investments, Life, World. Expand a section to drill in.
- **Center workspace (the hero area):** The current view — a company dashboard, the cap table, the sector heat map, the M&A pipeline, etc. Can be split into two side-by-side panels for power users.
- **Right context panel (~300px, collapsible):** Active alerts, recent news, current decision queue, quick stats relevant to the center view.
- **Bottom bar (~30px):** Scrolling news ticker (always live), status indicators (autosave, current speed, modifier flags).

Think Civilization VI's left-panel + main-stage layout, but applied to spreadsheet-shaped data.

### Information Architecture

Five primary modes (sidebar sections):

1. **Dashboard** — net worth, alerts, weekly news feed, links to active decisions, big Advance Week button
2. **Companies** — your operating companies, drill into any
3. **Investments** — public + private holdings, watchlist, your VC fund (if you have one)
4. **Life** — properties, vehicles, philanthropy, personal stats, ethics tracker
5. **World** — macro dashboard, sector heat map, public companies index, news archive, "Who Owns What" / Cap Map graph, AI rivals roster

Each section opens with an overview and lets you drill in. Multi-window support — open two companies side-by-side, or pop the news feed into its own window on a second monitor.

### Pacing & Time

Same as before — turn-based, click to advance:

- **Advance Week** — primary action; persistent button + Spacebar
- **Advance Month** — Shift+Space
- **Advance to Next Event** — Ctrl+Space; fast-forward until something needs attention
- **Auto-pause** on any decision-required event regardless of speed

### Design Principles (Desktop)

- **Information density first.** This audience wants Bloomberg, not a phone. A typical screen should show 3–5x more information than a mobile equivalent. Use it.
- **Tables with teeth.** Every list is sortable, filterable, exportable to CSV. Keyboard navigation with arrow keys.
- **Charts everywhere, interactive.** Stock prices, company revenue, net worth, sector performance, comparable rounds. Hover to brush, click to drill, scroll to zoom.
- **Hover states matter.** Hover any number → see context, source, history. This is where desktop shines vs. mobile.
- **Right-click context menus.** Right-click any company → buy stock, research, add to watchlist, set alert. Right-click any executive → review, fire, transfer, lobby.
- **Keyboard shortcuts everywhere.** Power users will use them; everyone else won't notice. Examples:
  - `Space` — Advance Week
  - `Shift+Space` — Advance Month
  - `Ctrl+Space` — Advance to Next Event
  - `Tab` — Cycle workspace panels
  - `Ctrl+1–5` — Jump to sidebar section
  - `/` — Quick search any company, person, asset
  - `?` — Cheat sheet overlay
- **Saved layouts.** Players save custom panel arrangements as named layouts (e.g., Operator Mode, Investor Mode, Magnate Mode).
- **Multiple monitors welcomed.** Detachable panels can pop out into their own windows.

### Tone

Newsroom-meets-Bloomberg, unchanged. Headlines like "Q3 Earnings Beat Sends [Company] Stock Soaring" — not gamey notifications. Treat players as adults role-playing executives.

**No voice acting, ever.** All character communication is text-based — in-game messages, news quotes attributed to characters, text dialogue threads, CEO log entries. This is a permanent design constraint: it locks content from being easily patched, costs significantly more than text content, creates accent/localization complexity, and constrains the procedural variety we want from named characters. Genre convention is text (Crusader Kings, Football Manager, Plutocracy). Music, ambient effects, and UI feedback sounds are fine; character voices are out forever.

### Polish Touches Steam Players Notice

- **Smooth animations** on number changes, panel transitions
- **High-quality typography** — Inter or IBM Plex Sans for body, JetBrains Mono for numbers/code
- **Sound design** — subtle audio cues for events, market shifts, notifications. Mute toggle, individual sound category sliders
- **Theme support** — dark mode default (sim audience preference), light mode option, accent color chooser
- **Localization-ready** — design with multi-language in mind from day one. EFIGS + Russian + Simplified Chinese covers ~80% of the Steam sim audience
- **Accessibility** — colorblind-friendly palettes, scalable UI, full keyboard navigation, high-contrast mode

### Mobile Port (V2.0+) — The Adapted Experience

When the mobile port comes after Steam launch, it should not try to cram the desktop UI onto a phone. Instead, it's a **focused, simpler experience** built around the most engaging core loops:

- **Founder mode emphasis** — the start → grow → exit arc, beautifully rendered for touch
- **Portfolio check-in optimized** — quick glance at companies, key alerts, weekly summary
- **Tab-bar IA** (5 tabs instead of sidebar) — the original mobile design from earlier doc versions still mostly applies here
- **Cut features** for mobile: probably no "Who Owns What" graph, simplified holdco view, fewer financial instruments, possibly fewer industries at launch
- **Cross-save with Steam** via cloud sync — players can run their Steam empire on the train via mobile
- **Casual session focus** — 60-second sessions feel complete on mobile, hour-long sessions feel right on Steam

The mobile audience is broader and more casual. Don't try to win the hardcore on mobile; serve the curious sim-adjacent player who'd never download Wall Street Raider but loves Game Dev Tycoon.

---

## 15. Tech Stack (Steam-First, Mobile-Port-Ready, Claude-Code-Optimized)

The tech choice matters more than usual because you're building with Claude Code, and Claude Code's strengths should shape the stack — picking a stack it's weaker in costs you 2–3x in iteration speed.

### Recommended: Tauri + React + TypeScript

**Why this stack specifically for a Claude-Code build:**

- Claude Code is exceptional at TypeScript and React — meaningfully more so than at GDScript or C#. For a solo or small-team build, this is the single biggest velocity multiplier available.
- The game is **UI/data-density heavy, not graphics heavy**. React + Tailwind + shadcn/ui + Recharts is exactly the toolset built for this kind of dense, interactive, table-and-chart UI. You'll write less custom UI code than in any game engine.
- **Tauri** ships native desktop binaries (Windows, Mac, Linux) with much smaller footprints than Electron — final game binary around 5–15 MB vs. Electron's 100+ MB.
- **Hot reload** during development. Save a file, see the change instantly. This iteration speed is decisive for a content-heavy sim where you'll be tuning constantly.
- **The mobile port path is short.** React Native or Capacitor can reuse most of the game logic; only UI components need redesign. Going Steam-first with Tauri/React positions the mobile port as a sibling project, not a rewrite.

**The toolchain:**

- **Tauri** — Rust-based desktop app shell (Steam-friendly, lightweight, fast)
- **React 18+** — UI framework
- **TypeScript** — type safety, especially valuable for cap table / financial logic where bugs eat hours of debugging
- **Tailwind CSS** + **shadcn/ui** — design system; gets you to good-looking dense UI fast
- **Recharts** or **visx** — interactive charts
- **TanStack Table** — for the dense, sortable, filterable data tables you'll have everywhere
- **Zustand** — state management (simpler than Redux Toolkit, plenty powerful for a single-player sim)
- **SQLite** (via Tauri's bundled support) — local saves, simple, robust
- **Vite** — build tool, fast dev server

**The risk to acknowledge:** some Steam users are skeptical of "web-tech games." Tauri mitigates this significantly (it's not Electron — final binaries are small, launch fast, feel native), but the perception risk exists. Counter it with polish: smooth animations, native-feel keyboard handling, proper window chrome, fast launch time. Most players won't know or care; the Steam reviewers who would are a small minority.

### Alternative: Godot 4 (C#)

If the web-tech perception risk feels unacceptable, **Godot 4 with C#** is the strongest "real game engine" alternative.

- Free, open source, no royalties or runtime fees
- Native UI tooling that's surprisingly capable for 2D dense interfaces
- C# is well-supported by Claude Code (better than GDScript)
- Built-in scene management, signal system, save/load primitives
- Smaller learning curve than Unity
- Mobile port via Godot's Android/iOS targets (a nice property)

Trade-offs vs. Tauri+React: slower iteration (compile times), smaller ecosystem of UI components and charting libraries (you'll build more from scratch), Claude Code is meaningfully less productive in C# than in TypeScript.

### Alternative: Unity (C#)

Industry standard. Works fine. **Probably overkill for a 2D UI-heavy sim.** Strong asset store and large community. The 2023 runtime-fee saga spooked many indies; the policy was reversed but trust took a hit. If you already know Unity, it's reasonable. If not, the others are faster paths.

### Why Not Native (Rust + egui or C++ + Dear ImGui)

You could write this in raw Rust + egui or C++ + Dear ImGui. Maximum performance, single tiny binary. But for a 2D data-heavy sim, you don't need the performance, and the iteration speed cost is severe — Claude Code is meaningfully less productive in these languages than in TypeScript. Skip unless you have a strong reason (existing codebase, team expertise).

### Recommended Decision Matrix

| Priority | Pick |
|---|---|
| Maximum velocity with Claude Code | **Tauri + React + TS** |
| Maximum "this is a real game" Steam perception | Godot 4 + C# |
| Best mobile port path while staying in one codebase | **Tauri + React + TS** (with React Native for mobile) |
| Existing team experience in C# | Godot 4 or Unity |
| Existing team experience in web tech | **Tauri + React + TS** |

For most readers of this doc, **Tauri + React + TypeScript** is the answer.

### Saves & Persistence

- **Local SQLite** for save files — robust, fast, queryable for late-game stats screens
- **JSON export/import** so players can share saves and back them up
- **Steam Cloud** sync for cross-machine play
- **Save versioning from day one** — design save format with version numbers. You'll change the schema dozens of times during development; backwards compatibility matters or you'll burn players whose saves break

### Data-Driven Architecture (Critical for Modding & Iteration)

Define industries, sub-industries, events, rivals, properties, archetypes — all in editable config files (TOML or YAML), not hardcoded.

- Speeds up your tuning iteration massively (no recompile to change a number)
- Enables **Steam Workshop modding later** without architectural rework
- Makes content-pack DLCs trivial to ship
- Lets you hire a content designer who doesn't code

This is the single most important architectural decision after picking the language. **Get it right from day one** or it's expensive to retrofit.

### Steam-Specific Tech

- **Steamworks SDK** — achievements, leaderboards, cloud saves, Steam Workshop
- **Tauri has community Steamworks bindings** — usable but rougher than Unity/Godot's first-party support
- **Build pipeline** — use Steamworks' depot upload tools; automate via GitHub Actions for nightly builds

### Anti-Cheat / DRM

Don't bother. Steam's audience is hostile to invasive DRM, and the kind of player who pirates a $19 sim isn't going to buy it anyway. Ship Steam-DRM-free or with the lightest Steam wrapper. Save cycles for actual game features.

---

## 16. Monetization

### Steam Launch — Premium Upfront

**Recommended: $14.99 launch (or $19.99 if scope at launch is generous).**

- Sits comfortably alongside reference titles. Plutocracy is around $20; Capitalism Lab is in the $40s; Game Dev Tycoon launched at $8 and rose. Wall Street Raider's remaster is expected in similar territory.
- Steam sim audience pays well for depth. The complaint isn't price; it's shallow content at any price.
- Plan a **15% launch-week discount** to spike wishlist conversions.
- Roll into seasonal sales (Summer, Winter, Autumn) at 25–40% off. Steam's algorithm rewards titles that engage with sales cycles.
- A **free demo** in Steam Next Fest before launch is essentially mandatory for this genre — wishlist conversion in sim/strategy is heavily demo-driven.

### Long-Term: Content Updates + Optional DLC

- **Free V1.5 / V2.0 content updates** for the first 12–18 months. Steam reviewers reward post-launch support; the score lifts.
- **Paid DLC at year 2+** ($4.99–9.99 each) — additional industries, scenarios, or eras. Examples: a Climate Tech expansion, a 1990s-era starting decade pack, a Geopolitical Crisis scenario pack.
- Avoid: microtransactions, lootboxes, time-skip purchases. The audience will eviscerate you in reviews.

### Mobile Port Pricing (V2.0+)

When the focused mobile port ships, a different pricing model fits the broader mobile audience:

- **Premium $4.99–6.99** (the Coffee Inc 2 / Game Dev Tycoon pattern), or
- **Free with one-time $4.99 unlock** of full content (the "try before you buy" path)
- No subscription, no ads, no IAP grinding

Cross-buy logic: players who own the Steam version get a discount or free unlock on mobile. Sells goodwill, costs little.

### Soft Launch Strategy

- **Steam Playtest** (free, invite-only) 2–3 months before launch — recruit testers from r/incremental_games, r/gamedev, r/Games, sim Discords
- **Steam Next Fest** demo — time the demo to coincide with one of these events for free visibility
- **Wishlist campaign** — start collecting wishlists 6+ months before launch; high wishlist counts trigger Steam algorithmic visibility at launch
- Mobile port follows similar pattern with TestFlight (iOS) and Play Console internal testing (Android)

---

## 17. V1 Scope + Post-Launch Roadmap

**Design philosophy:** V1 ships a focused, polished, exceptional core experience. Every system in V1 must be excellent — no half-finished features, no bloat that dilutes polish. Future content rolls out as **Sections**, each with one substantial paid DLC plus periodic free QOL/minor-feature updates.

This pattern is proven (Stardew Valley, Cities Skylines, RimWorld): players feel ongoing care via free updates, paid DLCs feel substantial, and momentum compounds over years.

---

### V1.0 — "Founder" (Launch)

**The core fantasy at full strength: found a frontier-tech company, raise capital, grow it, exit.**

Everything in V1 must be exceptional. If a feature can't be polished to launch quality, it gets cut and shipped later as a free update.

**Two playable industries: AI and Space**

Two industries gives V1 genre identity as a *business sim with frontier-tech texture*, not a single-industry sim. The pair was chosen because AI and Space share the same fundamental business loop (build product, acquire customers, scale, exit) but feel mechanically distinct via cycle speed, capex, and signature events. Biotech is deliberately deferred because its clinical-trial-pipeline mechanic is a separate system, not a content variation — it earns its own dedicated DLC slot.

**Sub-industries (3 per playable industry, 6 total):**

*AI sub-industries:*
- **Frontier Model Lab** — massive compute capex, tiny revenue, top-talent war, binary breakthrough moments
- **Vertical AI SaaS** — predictable B2B SaaS metrics (ARR, churn, NRR), enterprise sales motion, faster cycles
- **AI Chips / Silicon** — long fab cycles, customer concentration, hardware margins, supply chain

*Space sub-industries:*
- **Launch Services** — cadence-driven; revenue per successful launch; failures destroy customer payloads (lawsuits, insurance hikes)
- **Satellite Constellations** — massive upfront capex, then recurring subscription revenue from data/comms customers
- **Space Stations** — real-estate-like; lease modules to research, tourism, and in-space manufacturing tenants

The other Space sub-industries (mining, in-space mfg, tourism, lunar logistics) and the other AI sub-industries (infrastructure, robotics, autonomy, creative tools) ship as free updates over time.

**Industry mechanical distinctions:**

| Aspect | AI | Space |
|---|---|---|
| Cycle speed | Fast (2–3 yr phases) | Slow (4–5 yr phases) |
| Capex | High but lumpy (compute) | Extreme and sustained |
| Time to first revenue | Months | Years |
| Signature mechanic | Talent + compute as twin constraints | **Launch events** (binary outcomes) |
| Regulatory drag | Light, rising | Heavy (FAA licensing, ITAR) |
| Customer mix | B2B / B2C / enterprise | Government anchor + commercial |

These aren't cosmetic differences. They produce genuinely different playthroughs — a Space launch company has 18 months of pure burn before its first revenue rocket, with a real chance of explosion; an AI vertical SaaS has revenue in month 3.

**Space Signature Mechanic: Launch Events**

The single biggest Space-specific addition. A launch attempt resolves probabilistically based on:
- R&D investment level (improves base success rate)
- Manufacturing quality (affects reliability)
- Weather conditions (small RNG modifier)
- Pad infrastructure level
- Cumulative launch experience (early launches are riskier; learn-by-doing improves odds)

Baseline success probabilities:
- First launch: ~50–70%
- Established cadence: ~85–95%

Failures destroy customer payloads, trigger lawsuits, raise insurance premiums for future launches, and dent company brand. Successes generate revenue and credibility, gradually improving subsequent launch odds. This creates a **risk-management gameplay layer Space companies have that AI companies don't** — should you launch the rocket now with 75% confidence, or spend three more months on testing for 88%?

**The Founder Arc**

- Idea → Pre-seed → Seed → Series A → Series B → Exit
- Single company at a time (no multi-company in V1)
- Player picks AI or Space at company creation
- The other 6 industries exist as backdrop only (public market, news ticker, world simulation)

**Cap Table System (Hero Feature)**

Beautifully rendered, live-updating, central to the experience. Founder %, investor stakes, ESOP, fully-diluted math, dilution previews before round commits, vesting visualization. **Must be perfect.**

**Fundraising Negotiation (Hero Feature)**

- 18 hand-crafted firms + procedural fill (~80–100 procedural at launch)
  - 9 AI-focused or generalist firms with AI flex
  - 5 Space-focused or generalist firms with Space flex
  - 4 stage-specialists across both sectors (early-stage angels, growth equity, late-stage)
- 5 hidden personality axes + visible trait tags
- Sector + stage specialization with flex
- NPC fund cycles + check size limits
- Two-tier relationship memory (event log on hand-crafted; numeric only on procedural)
- Stage-scaled syndication
- Hot Deal trigger for competing term sheets
- Three-mode investor competition (quiet / reactive / pre-emptive)
- Three discoverability tracks (procedurals visible / hand-crafted gated / cold-pitch always available)

The other 12 hand-crafted firms (rounding to 30 total target) ship in free updates post-launch.

**Two Exit Paths**

- **Traditional IPO** (full three-act process: underwriter selection → roadshow → pricing → first-day reveal)
- **Acquisition** (strategic or PE buyer; procedural offers + player-initiated outreach)

Stay-Private path with secondaries and late-stage rounds becomes the **"Dynasty" paid DLC**.

**Post-IPO (Light)**

- Stock volatility tied to sector hype, macro cycle, simple earnings outcomes
- Disclosure costs (small ongoing %)
- 180-day lockup with expiration moment
- Earnings auto-resolve with player-set tone (confident / cautious / aggressive); full guidance system arrives in free update

**Public Market (Investing)**

- ~70 procedural public companies across all 8 industries (skewed toward AI and Space since those are the playable sectors)
- Stocks only (no ETFs, no bonds, no options)
- Buy/sell, watchlist, basic charts

**Dynamic World Simulation**

Full strength — this is what makes replayability work and must not be diluted:

- 5 master variables (Macro Phase, VC Climate, IPO Window, Industry Hype, Interest Rate)
- 8 industry hype scores tracked dynamically (AI and Space playable; all 8 affect the world)
- Macro cycle, recessions, IPO windows opening/closing
- Pre-scheduled black swans with leading indicators
- Three-layer model (persistent forces + procedural variables + feedback loops)

**Difficulty System**

Full strength — multiplies replayability:
- 8 world variance sliders (Macro Volatility, Black Swan Frequency, Sector Volatility, Fundraising Difficulty, Operating Difficulty, Binary Event Variance, Starting Capital, Tax & Cost Burden)
- 3 preset bundles (Forgiving / Realistic / Brutal)
- News Cycle selector (Easy / Medium / Hard)
- Sliders lock at game start

**Personal Wealth (Light)**

- 5 properties (apartment, house, mansion tiers in 2–3 cities)
- 8 vehicles (Civic to McLaren range)
- Basic philanthropy (donate to 5 cause categories; tracks lifetime giving)

Deeper personal wealth (international properties, art, yachts, jets, foundations, status effects) becomes the **"Dynasty" paid DLC**.

**Procedural Events**

- 50 hand-crafted event templates at launch
  - ~15 macro / cross-industry
  - ~15 AI-specific
  - ~15 Space-specific
  - ~5 personal
- Additional events ship in free updates over time

**UI**

- Full Steam-first desktop layout (top bar, left sidebar, center workspace, right context, news ticker)
- All 5 sidebar sections functional (Dashboard, Companies, Investments, Life, World)
- Sector heat map, macro dashboard, comparable rounds widget, news feed
- Industry-specific UI elements (cap table is universal; launch event screen is Space-only; compute allocation panel is AI-only)
- Keyboard shortcuts, right-click menus, hover states
- Sound design pass
- Dark mode default + light mode

**Steam Integration**

- ~30 launch achievements (split across AI runs, Space runs, and cross-industry plays)
- Steam Cloud sync
- Multiple named saves with version migration
- Steam Workshop scaffolding (modding can launch in a later free update; the architecture supports it from day one)

**Localization**

- English at launch
- Localization-ready architecture (UTF-8, externalized strings)
- Additional languages roll out as free updates

**Estimated build:** 8–11 months focused work with Claude Code.

---

### What's Explicitly NOT in V1

These were considered for V1 and **deliberately cut** to protect polish on the core. Each ships later as either a free update or paid DLC.

- 4 additional AI sub-industries (Infrastructure, Robotics, Autonomy, Creative Tools) → **free update**
- 4 additional Space sub-industries (Mining, In-Space Mfg, Tourism, Lunar Logistics) → **free updates**
- 12 additional hand-crafted firms (rounding to 30 total) → **free updates**
- Stay-private path / secondary tenders → **Dynasty DLC**
- Multi-company simultaneous play → **Mogul DLC**
- Delegation / executive layer → **Mogul DLC**
- Holding companies → **Mogul DLC**
- Player's own VC fund → **Mogul DLC**
- Biotech & Gene Editing as playable → **Frontier DLC**
- Energy & Climate as playable → **Frontier DLC**
- Defense, Manufacturing, Mobility, Quantum as playable → **later DLCs**
- Activist investors / hostile takeovers → **Power Plays DLC**
- AI Rivals (named persistent capitalists) → **free update**
- Player ethics / karma system → **free update**
- ETFs, bonds, options, futures → **free updates over time**
- Direct Listing, SPAC merger → **free update**
- Full earnings call mini-game → **free update**
- iPad / mobile port → **separate companion product**
- Steam Workshop modding → **free update** (architecture in V1, UI later)

This list is deliberately long. **The discipline of cutting is what makes V1 great.**

---

### Section 1 — "Mogul" (Paid DLC)

**Theme:** Multi-company empire-building. Stop running one company; start running an empire.

**Estimated release:** 6–9 months post-launch.

**Big paid DLC adds:**

- **Multi-company simultaneous play** — found and run multiple companies at once
- **Delegation system** — escalation thresholds, auto-handle routine ops, executive layer with stats
- **Executive recruiting** — hire CEOs, CTOs, CFOs with personality stats; comp negotiation; scandals; retention dynamics; coup risk
- **Holding company structure** — unlocks at 3+ controlled companies; capital allocation across subs, shared services, synergies, tax efficiency, basic M&A platform
- **Player's own VC fund** — 2/20 economics, LP relations, deal flow, fund formation
- **Term Sheet expansion (bundled add-on)** — adds the 3 advanced negotiable terms (anti-dilution, pro-rata, protective provisions) plus Cap Table Pro mode with liquidation waterfall scenarios, dilution analysis across hypothetical future rounds, and exit-payout modeling under different term structures. The finance-power-user expansion.

**Pricing target:** $9.99–$12.99

**Free updates accompanying this section** (released between V1 launch and Mogul DLC):
- 4 missing AI sub-industries (Infrastructure, Robotics, Autonomy, Creative Tools)
- 4 missing Space sub-industries (Mining, In-Space Mfg, Tourism, Lunar Logistics)
- **Angel investing** — make small personal checks into procedural startups; first taste of the investor side of the table; also enables self-investing in your own companies once you have capital available
- 12 additional hand-crafted firms (rounding to 30 total)
- Direct Listing as alternative IPO path
- Full earnings call mini-game for special quarters
- Player ethics / karma system
- More events (target: 50 → 100)
- More properties and vehicles
- Quality-of-life UI improvements based on player feedback
- Performance optimizations
- Localization: French, German, Spanish, Russian

---

### Section 2 — "Frontier" (Paid DLC)

**Theme:** Two new playable industries. The conglomerate era goes wide into life sciences and energy.

**Estimated release:** 12–18 months post-launch.

**Big paid DLC adds:**

- **Biotech & Gene Editing** as fully playable — the clinical trial pipeline is its own signature system (Phase I → II → III with probabilistic outcomes), genuinely different gameplay loop from AI/Space
- **Energy & Climate industry** as fully playable (solar, wind, batteries, hydrogen, SMRs, fusion, DAC, smart grid, geothermal) — project finance economics
- **Cross-industry synergies** wired up across all four playable industries (AI + Energy data center deals, Biotech + AI for protein design, Space + AI autonomy, etc.)
- New industry-specific events, archetypes, mechanics
- Additional hand-crafted firms specialized in these sectors

**Pricing target:** $9.99–$12.99

**Free updates accompanying:**
- ETFs and bonds for the public market
- Updated dashboard for cross-industry portfolio view
- Steam Workshop modding UI (architecture has been in place since V1)
- AI Rivals system (named persistent capitalists)
- More events and content
- Localization: Simplified Chinese, Japanese, Korean

---

### Section 3 — "Dynasty" (Paid DLC)

**Theme:** The forever-private path and personal-wealth magnate fantasy. Build a multi-generational empire.

**Estimated release:** 18–24 months post-launch.

**Big paid DLC adds:**

- **Stay-private path** with late-stage rounds (Series E+) and **secondary tender offers** — the SpaceX/Stripe playbook
- **Personal wealth depth** — international properties, art collection with auction events, yachts, jets, helicopters, status effects affecting deal flow
- **Foundation creation** — endowments, named buildings, multi-decade philanthropic legacy that persists across save files
- **Generational mode** (optional) — player can age and die; heirs inherit empire; estate tax mechanics; multi-generation play
- **Family office layer** — Family Office Director, Estate Manager, Foundation Director
- **Personal status system** — invitations to Davos / Sun Valley / Allen & Co. as gameplay events

**Pricing target:** $9.99–$12.99

**Free updates accompanying:**
- Options trading
- Going-private transactions (LBO your own public company)
- Secondary stock offerings post-IPO
- More events
- More localizations as community demand surfaces

---

### Section 4 — "Power Plays" (Paid DLC)

**Theme:** Hostile takeovers, activist investing, and Wall Street drama.

**Estimated release:** 24–30 months post-launch.

**Big paid DLC adds:**

- **Activist investor mechanics** — accumulate 5%+ position; agitate for spin-offs, board seats, strategy changes
- **Hostile takeover system** — accumulate stakes quietly, force votes, tender offers
- **Antitrust mechanics** — FTC investigations at market share thresholds; DOJ lawsuits as multi-year proceedings; forced divestitures
- **Greenmail and corporate raider tactics** — Wall Street Raider-style aggressive plays
- **Defensive maneuvers** — poison pills, white knights, staggered boards
- **AI Rivals expanded** — rivals now actively raid your companies and you can raid theirs

**Pricing target:** $9.99–$12.99

**Free updates accompanying:**
- Futures trading
- Public holdco listing with dual-class shares + annual shareholder letter
- Refined news ticker with rival activity prominently surfaced
- More events

---

### Section 5 — "Hard Tech" (Paid DLC)

**Theme:** The remaining heavy industries. Defense, Manufacturing, Mobility.

**Estimated release:** 30–36 months post-launch.

**Big paid DLC adds (smaller scope per industry; Frontier already proved the framework, so each is faster to build):**

- **Defense Tech** as fully playable (programs of record, geopolitical event-driven demand)
- **Advanced Manufacturing** as fully playable (asset utilization, capacity planning)
- **Mobility & Autonomy** as fully playable (manufacturing ramp, regulatory unlock)

**Pricing target:** $9.99–$12.99

**Free updates accompanying:**
- More cross-industry synergies
- Distressed debt and exotic instruments
- More events, more rivals

---

### Section 6 — "Quantum Leap" (Paid DLC)

**Theme:** The longest-horizon bet. Quantum computing, plus future-frontier wildcards.

**Estimated release:** 36+ months post-launch.

**Big paid DLC adds:**

- **Quantum Computing** as fully playable (milestone-gated funding, multiple competing modalities, ultra-long horizon)
- **Neurotech & BCI** as fully playable (extreme regulatory + ethical tension)
- A community-voted wildcard industry

**Pricing target:** $12.99–$14.99 (slightly higher; richer content)

**Free updates accompanying:**
- Currency exposure
- Multiplayer leaderboard seasons
- Refinements based on years of player feedback

---

### DLC Strategy Principles

A few discipline rules to make this roadmap actually work:

1. **Free updates ship between paid DLCs continuously.** Don't go silent for months. The Stardew Valley pattern — small frequent free updates building toward big paid drops — keeps the community engaged and review scores rising.

2. **Each paid DLC is substantial.** $9.99–$12.99 should feel like real value. No $4.99 cosmetic packs. No microtransactions. No season passes. Steam sim audience hates that and the negative reviews compound.

3. **Free updates target QOL and minor features.** Localization, UI improvements, performance, additional events, additional firms, additional properties, additional sub-industries within existing playable industries. Anything that makes existing systems better.

4. **Paid DLCs add new systems or new content tiers.** Multi-company play (system), new industries (content), new exit paths (system), new mechanics like activist investing (system). Things that meaningfully expand the playable surface.

5. **Never paywall fixes.** Bug fixes and balance changes are always free, always for everyone.

6. **Free updates can be larger than expected.** If the AI Rivals system ends up being smaller than planned for a paid DLC, ship it as a free update instead. Generous free updates buy enormous goodwill.

7. **Don't promise specific DLC release dates.** Estimated quarters at most. Sim DLC takes longer than expected, every time.

8. **Cumulative pricing matters.** Six paid DLCs at $9.99 each = $60 on top of a $14.99 base = $75 total. That's a Witcher 3 GOTY total price for a sim game — totally fair, but worth knowing the math. The base game must feel like good value standalone.

---

### Why This Phasing Works

A few structural reasons this roadmap is well-shaped:

**V1 is small enough to actually ship.** No half-built systems, no scope-creep death. Six to nine months of focused work for one developer with Claude Code is realistic. Plutocracy's cautionary tale was trying to ship the full vision at once.

**Each Section has a clear theme.** "Mogul" is multi-company empire. "Frontier" is new industries. "Dynasty" is forever-private and lifestyle. Players know what they're buying.

**The roadmap is reactive.** If V1 finds an audience, you have 3+ years of substantial content already designed. If it doesn't, you've spent 6–9 months instead of 3 years finding out — and the design plan is reusable.

**Each DLC builds on the previous.** Mogul's holdco system makes Frontier's multi-industry play richer. Frontier's industries make Dynasty's diversified-portfolio fantasy work. Power Plays' activist mechanics give Hard Tech's industries something dramatic to face. The systems compound.

**Free updates between DLCs prevent staleness.** Players who don't buy every DLC still feel cared for. Steam reviews from "I haven't bought DLC but the base game keeps getting better" players are gold.

**Steam Workshop modding (free update during Frontier era) extends life indefinitely.** Modders will ship industries, scenarios, events, and reskins for years after your last paid DLC. This is how Cities Skylines stays alive.

---

## 18. Development Roadmap

| Phase | Duration | Goals |
|---|---|---|
| **Pre-production** | 4–6 weeks | Lock design doc; build clickable React prototype of cap table + fundraising negotiation; validate "is the math fun?" in a spreadsheet first |
| **Vertical slice** | 2–3 months | One industry (AI), one company, full lifecycle from founding to IPO playable end-to-end. Steam page goes up; wishlist farming begins |
| **Content & systems build-out** | 3–4 months | Public market, personal wealth, events engine, polish; build out remaining V1 features |
| **Closed Steam Playtest** | 4–6 weeks | Invite-only beta via Steamworks; private Discord for testers; balance pass; performance tuning |
| **Steam Next Fest demo** | 1–2 weeks event | Free demo with first-hour content; wishlist push; trailer drops |
| **Steam launch** | — | Public launch with 15% launch-week discount; community management mode |
| **Post-launch (V1.5–V2.0)** | 6–18 months | Free content updates: additional industries, multi-company play, basic delegation, holdco system. Patches and balance based on reviews |
| **Mobile port (V2.0+)** | 4–6 months | Adapted UI for iOS/Android; focused subset of features; cross-save with Steam via cloud sync |
| **Paid DLC (year 2+)** | per pack | Themed expansions: Climate Tech industry, Crisis Era scenario pack, etc. |

**Critical path risks:**

- Balancing fundraising negotiation — too hard and players bounce; too easy and the depth fantasy collapses
- Procedural event variety — you'll need many more events than you think; budget time for content
- Performance on weaker Steam machines if simulation tick gets heavy (test on Steam Deck explicitly — that audience overlaps heavily with sim players)
- Wishlist count at launch — sim genre lives or dies on launch-day visibility, which is wishlist-driven; underinvesting in pre-launch marketing is the most common indie failure mode
- Save format breakage during development — version your saves from day one; bad backwards compatibility burns players whose 30-game-year empire becomes unloadable

---

## 19. Open Questions & Decisions Needed

### Decisions Made

- ✅ **Pacing model:** Turn-based, click-to-advance. Player advances 1 week per click by default, with Advance Month and Advance-to-Next-Event skip options. Auto-pause on any decision-required event. No real-time pressure anywhere.
- ✅ **Difficulty system:** Eight independent world-variance sliders (Macro Volatility, Black Swan Frequency, Sector Volatility, Fundraising Difficulty, Operating Difficulty, Binary Event Variance, Starting Capital, Tax & Cost Burden), locked once a save begins. Three preset bundles (Forgiving / Realistic / Brutal) for players who don't want to fiddle.
- ✅ **News cycle:** Separate three-mode selector (Easy / Medium / Hard) controlling how clearly the world telegraphs upcoming events. Orthogonal to world variance — any combination is valid.
- ✅ **Hidden state:** Hype scores, event schedules, and underlying simulation math stay hidden from the player at all difficulties. The five master variables (Macro Phase, VC Climate, IPO Window, Industry Hype, Interest Rate) are always visible.
- ✅ **Auto-decisions during skip-ahead:** Solved by the delegation system. Whatever the player has delegated runs automatically; whatever they haven't surfaces as a pause. Engine-critical events (term sheets, FDA decisions, board votes, market shocks) always pause regardless of delegation settings.

### Still to Decide

1. **Single life or generational?** Does the player age and die (Bitlife-style), or play indefinitely? *Recommendation: indefinite by default, with optional "mortal mode" where you live ~40 game-years.*
2. **Real-world references or fully fictional?** Can the player buy "Apple" stock, or is everything procedurally named? *Recommendation: fully fictional companies with archetype hints; avoids legal risk and keeps each save fresh.*
3. **Save file approach?** One save vs. multiple? *Recommendation: multiple named saves, cloud-synced.*
4. **Tutorial design?** This is a deep game — a guided first company is essential. Can the tutorial *feel* like the game rather than a chore?

---

## 20. Lessons from Plutocracy & Wall Street Raider

Two reference titles worth studying in depth. Plutocracy is a contemporary indie business sim covering the late 19th / early 20th century robber-baron era. Wall Street Raider is a 40-year-old cult financial simulator originally written by a Harvard-trained lawyer/CPA in 1986, now being remastered for a new generation. Both have devoted niche audiences. Both have lessons worth stealing — and pitfalls to avoid.

### Plutocracy — What Works

- **Character-driven shareholder system.** The game models around 15,000 characters — shareholders, officials, politicians — each with personal interests, fears, ambitions, and traits that can be leveraged. Negotiation isn't with a faceless market; it's with a specific person whose psychology matters.
- **Multi-channel power.** Players can pursue economic dominance through fair competition, political influence (lobbyists, sponsoring elections, bribery), media manipulation, or covert sabotage (organizing strikes against competitors, blocking production, blackmail). Multiple paths to the same outcome.
- **Region-level economic differentiation.** Different US states have different prices, laws, and conditions. Cross-regional play creates real geographic strategy.
- **Holding company drives vertical integration** across regions — players have specifically called this out as a motivating mechanic.
- **Real-world economic effects at scale.** Once large enough, the player can influence GDP, unemployment, and prices at the country level.
- **Manual + automatic management.** The dev team explicitly built delegation in to combat micromanagement fatigue.

### Plutocracy — What Fails

The complaints are remarkably consistent across player reviews:

- **Repetitive negotiation grind.** A common late-game complaint: "talking to 4/5 people per company, negotiate, make holding, expand" turns into a slog once you're scaling. Players literally describe wanting the system replaced with fixed probabilities.
- **Punishing influence economy.** Failed negotiations burn global influence. Chains of failures can leave the player in a state where no one will deal with them — an unrecoverable corner.
- **Weak AI competition.** Reviewers note effectively one good way to play; competitors aren't actively in your way; risk of failure is low.
- **No real endgame.** Once you've bought everything in a state, the question becomes "what now?" Players actively ask this.
- **Information gaps make stocks feel like gambling**, not analysis.
- **Per-unit decisions for routine ops.** A memorable critique compares it to "deciding for every Age of Empires soldier whether his training succeeds" — granular RNG that should be abstracted.

### Wall Street Raider — What Works

WSR has been refined over four decades — the depth is real:

- **Astonishing simulation depth.** Around 1,590 simulated companies across ~70 industry groups, with consolidated tax accounting modeled on actual IRS regulations.
- **Hidden karma system.** Player ethical violations are tracked silently; the more you cheat, the higher your probability of getting caught. Real cost for shady tactics without forbidding them.
- **Living news ticker.** A constantly-running scroll of market events and headlines creates the feeling that the world exists without the player.
- **Complete corporate raider toolkit.** Hostile takeovers, greenmail, leveraged buyouts, junk bond financing, mergers, spin-offs, antitrust lawsuits as harassment, IPOs, private offerings — a full vocabulary.
- **Auto-pause on critical events.** At higher game speeds, the engine halts on hostile bids, SEC investigations, and critical banking events. (This validates a design we already chose.)
- **Sticky bull/bear regimes with mean reversion.** Macro variables (GDP growth, inflation) drift toward long-run averages; sentiment runs on momentum. Realistic and gameplay-friendly.
- **Multiple instruments.** Stocks, options, bonds, ETFs, commodities, crypto, interest rate swaps — players can express any thesis financially.
- **AI rivals competing for the same opportunities.** Named computer opponents acting in the same world, building empires alongside (and against) you.
- **"Who Owns What" tool** for mapping ownership relationships across the simulation.

### Wall Street Raider — What Fails

The challenges (and what to avoid):

- **Forbidding UI.** The classic version was famously dense and required a ~270-page strategy manual sold separately. The remaster aims to fix this — the lesson is don't ship the original UI.
- **Steep learning cliff.** Decades of accreted features means new players face an enormous ramp.
- **Starting too rich.** Reviewers historically noted the game starts the player with such a fortune that the rational move feels like retiring rather than competing. No founding arc, no scrappy beginning.
- **Niche audience by necessity.** Pure finance-sim depth caps audience size.

### Specific Mechanics to Adopt

#### A. Player Ethics / Karma System (from WSR)

Add a hidden integrity score (0–100) tracking shady actions: insider trading, accounting tricks, regulatory violations, executive scandal cover-ups, lobbying excesses, cap-table manipulation. Effects:

- **Probability of getting caught** scales with violation count
- **Recruiting friction** — high-integrity executives won't join low-integrity players
- **Reputation loop** — exposure causes news cycle damage, stock drops, board pushback
- **Investigation events** — SEC, DOJ, FTC, FDA inquiries trigger procedurally based on score
- **Strategic counterplay** — players can cut corners but face compounding risk; clean players build slower but face no ceiling

This adds an "ethics dimension" that complements net worth. Some players will min-max ethics; others will optimize speed. Both valid.

#### B. AI Rivals (from WSR + Plutocracy)

Beyond procedural companies, add a small roster (~20–40) of **named, persistent rival capitalists** competing across decades. Each rival has:

- A signature industry focus
- A strategy archetype (Buffett-style allocator, Musk-style operator, Icahn-style activist, Soros-style trader)
- Personality stats (aggressive, ethical, ambitious)
- A net worth that grows alongside yours
- Visible public actions reported in the news

Rivals appear in fundraising rounds (competing investors), M&A (counter-bidders), recruiting (poaching execs), public markets (taking opposing positions), and procedural events. Some become collaborators on co-investments; others adversaries. Tracking their net worth becomes a metagame.

#### C. Antitrust & Regulatory Scrutiny (from WSR + Plutocracy)

At scale, regulators come for you. Track market share within industries; trigger investigations at thresholds (e.g., 30% market share in a single sub-industry, 60% control via holdco):

- **FTC investigations** block proposed acquisitions
- **DOJ antitrust lawsuits** as multi-year proceedings; outcomes can force spin-offs
- **Forced divestitures** if you lose — sub spun off at fire-sale prices
- **Regulatory inquiry** as a live event that drives news, stock impact, distraction cost

This creates a real ceiling on uncontrolled empire-building. Combined with conglomerate discount, big holdcos face natural pressure to stay focused.

#### D. Character-Driven Negotiation (from Plutocracy, fixed)

We have personality stats for executives. Extend to:

- **VC investors** — each named, with traits, prior portfolio, prior relationship with you
- **Board members** — beyond the exec layer; named members with voting patterns
- **Government officials** — specific regulators, judges, legislators

**Critical fix vs. Plutocracy:** avoid the "negotiate with 4–5 people per company × every company" grind. Solutions:

- Default delegated relationships handled by your Chief of Staff
- Only key counterparties surface for direct interaction
- Relationships persist across deals — a VC who funded your last company comes back; no need to re-introduce
- Procedural variety in negotiations driven by counterparty personality + macro context, so no two negotiations feel identical

This gets the texture without the slog.

#### E. Live News Ticker (from WSR)

An always-on scrolling feed in the World tab. Even on weeks the player skips, the ticker shows what the world did. Headlines about rivals' moves, sector shifts, macro events, scandals. Creates the "world is alive without me" feeling that's critical for replayability.

The ticker should explicitly surface rivals' moves ("Marcus Vale acquires GenoPharma for $3.2B") so the world feels populated, not abstract.

#### F. Multiple Financial Instruments (from WSR, phased)

Our plan has stocks. Expand progressively:

- **V1** — Stocks + ETFs
- **V1.5** — Corporate & government bonds (fixed income for risk-off periods)
- **V2** — Options (calls, puts) for leverage and hedging
- **V2.5** — Index futures (macro bets)
- **V3** — Distressed debt, currency exposure, advanced derivatives

This pacing matches when players actually need them. Don't ship V1 with all of WSR's instruments; that's a learning cliff. Add as the player's sophistication grows.

#### G. "Who Owns What" Visualization (from WSR)

A dedicated screen showing the ownership graph: your holdings, holdco structure, board seats, cross-positions with rivals. Visual node graph, not a spreadsheet. At scale this becomes essential — without it, complexity collapses.

Add to the World tab as a "Cap Map" view.

#### H. Light Company Relationship System (from WSR's interconnected economy)

WSR's economy feels alive because companies are *interconnected* — control of one affects others, monopolies form across linked firms, and "quiet monopolies" become discoverable strategic opportunities through the news ticker. Our ~70 procedural companies should not be 70 independent entities in a list. They need a **light relationship graph** — legible and consequential, not deep and emergent.

**Four relationship types for V1:**

1. **Competitors (within sub-industry)** — the most important relationship. Companies in the same sub-industry compete over customers, talent, and investor attention. A competitor's big win (launch, raise, IPO pop) pressures the others — relative hype shifts, talent gets more expensive, customers get poached. A competitor's stumble (failed launch, scandal, down round) frees up their customers and talent. **The player's company is one competitor among several in its sub-industry** — they're inside this web, not above it.

2. **Customers ↔ Suppliers (cross-sub-industry, light)** — a few clear vertical links: AI Chips companies supply Frontier Model Labs; Launch Services supply Satellite Constellations and Space Stations; Frontier Model Labs supply Vertical AI SaaS. Events cascade legibly — a chip shortage raises Frontier Lab costs; a launch failure delays a constellation buildout.

3. **Sector peers (within industry, looser)** — all AI companies share AI hype, AI regulation, AI talent markets; all Space companies share Space dynamics. Already exists via the hype system; this just makes it explicit that companies "know" they're sector peers.

4. **Investor overlap (shared cap tables)** — procedural companies have procedural investors. When the same VC firm backs multiple companies, that's a visible relationship. An overexposed firm behaves differently (conservative, pushes portfolio toward exits). Creates the "my investor also backs my competitor" tension.

**Deliberately excluded from V1** (later DLC/updates): common ownership / holding structures between procedural companies (WSR's "quiet monopoly" — Power Plays DLC era), deep multi-tier supply chains, contagion cascades through creditors, procedural M&A between NPC companies (AI Rivals free-update feature). **The V1 relationship graph is static per playthrough** — relationships influence events, news, hype, and fundraising, but the graph itself does not mutate (no NPC-to-NPC mergers, no companies appearing or disappearing). This is deliberate: a player who watches NPCs do something they cannot do (buy companies) reads it as a missing feature, not a living world. V1 keeps the player firmly in the founder→raise→run→IPO loop; dynamic M&A arrives when the player can also participate in it.

**How the player experiences it:** a "Relationships" section on any company's detail page (competitors, suppliers/customers, shared investors — all clickable); events that reference relationships ("Your chip supplier had a fab yield problem — training run costs rose 15%"); news that frames competitor moves relationally ("Rival lab raised $200M — analysts say it intensifies the talent war"); fundraising friction when an investor backs your competitor.

**Architectural note:** the relationship graph must exist in the data model from day one — even though V1 only uses four light types, the structure should support deeper ones without a rewrite. A simple typed edge list between company entities: `{ from, to, type, strength }`. Cheap to build, expensive to retrofit.

#### I. Lessons From WSR's 40-Year Near-Death (what NOT to do)

WSR is the cautionary tale that validates our entire UI-first approach. It had — by reputation — the deepest financial simulation ever made, proven educational value (players got finance careers from it), and devoted fans. It stayed an obscure cult game for **40 years** for one reason: the interface. Multiple well-funded teams (a Denver legal-software company; a studio that did Disney work, spending a year and hundreds of thousands of dollars on an iPad port) tried to modernize it and *all failed*. The Steam remaster's whole thesis is "if it had a Bloomberg-terminal UI, the game is done."

Concrete takeaways, beyond the anti-patterns list:

- **Depth is necessary but not sufficient.** WSR proves a brilliant simulation with a bad interface is a cult game, not a hit. UI-first development is the correct strategy — never let it slip when build pressure hits.
- **"Read the manual" is a failure state.** WSR's onboarding is a 300-page strategy ebook; players report reading the whole manual and still being terrible. Depth must be discoverable *through play* — this is why the new-game setup flow, the news-cycle difficulty setting, layered hidden/visible information, and in-context decision surfacing all exist.
- **A motivational arc the player understands.** A 1989 review noted WSR was "a little dry as a solo game; you start with a fortune and the temptation is to say '$250,000 is enough, I'll emigrate to the Bahamas.'" Starting rich lacks a *why*. Our founder→magnate arc is the motivational spine WSR never had.
- **"Productive losing."** The thing WSR fans love: every loss teaches something you didn't know was in the game. Losing should never feel arbitrary — every failure should be legible in hindsight. Tune black swans and events so the player can always reconstruct "what I missed."

### Six Anti-Patterns to Avoid

1. **Don't punish failure unrecoverably.** Plutocracy's influence cliff (3 failed negotiations = no one will deal with you) is brutal. Always give players a path back, even if slow.
2. **Don't make the same mini-game appear hundreds of times.** Players will tolerate a great mini-game once per session, not once per turn. Fundraising should vary by counterparty + macro state. Negotiations should not reduce to repetitive clicks.
3. **Don't ship a manual-required UI.** WSR's classic version is unplayable without docs — and that kept the best financial sim ever made obscure for 40 years. Depth must be discoverable through play. Watch information density throughout playtest; every system needs an in-context path to understanding.
4. **Don't start the player rich.** Founder mode at $50K is the right call. The arc from scrappy founder to capital allocator is our distinctive identity.
5. **Don't let one strategy dominate.** Plutocracy criticism: "only one good way to play." Our dimensions (8 industries × 8 difficulty sliders × news cycle × 3 holdco structures × ethics axis) should provide path diversity, but watch for accidental dominant strategies during playtest.
6. **Don't forget the late game.** Plutocracy's "owned the state, now what?" trap. Our holdco system, antitrust, activist pressure, rivals catching up, and procedural late-game events all need careful tuning. The plan has scaffolding; tuning will determine whether late game stays interesting.

### What Makes Moonshot Inc Different

Drawing on these learnings, our distinct positioning:

- **WSR's depth, modernized for mobile.** Cap tables, fundraising mechanics, governance — all rendered for turn-based, phone-friendly play.
- **Plutocracy's living world, future-forward.** Characters, politics, dynamic economy — set in space/AI/biotech rather than steel/oil/railroads.
- **The founder arc neither game has.** Both start you wealthy. We start you with $50K and a dream. Founder → executive → owner → capital allocator is where our identity lives.
- **Mobile-first turn-based pacing.** Both reference titles assume a desk and time. Ours assumes a phone and 90 seconds.

The combination is genuinely novel. Both reference games target the same psychographic; neither has aged well or scaled to mobile. There's a real opening.

---

## 21. What to Do This Week

If I were you, I'd spend the first week on three things:

1. **Play the references for 5+ hours each.** Coffee Inc 2, Trading Game, Game Dev Tycoon, Capitalism Lab, Software Inc, **Plutocracy**, and **Wall Street Raider** (the new remaster on Steam, or the free classic version on itch.io). Take notes on what feels good and what frustrates.
2. **Prototype the cap table + fundraising loop in a spreadsheet.** Forget code. Can you build a fundraising negotiation in Excel that *feels fun*? If yes, the game's core works. If no, redesign before writing a line of Swift.
3. **Lock the name and reserve everything.** Do a Steam name search and a US trademark search for "Moonshot Inc" (and your shortlist alternatives). Register the **Steamworks account** ($100 one-time fee — required to publish). Reserve the **Steam app ID and store page** (just a placeholder is enough — the wishlist count starts accumulating from day one and Steam's algorithm rewards long wishlist histories at launch). Buy the **domain** (moonshot-inc.com or similar). All cheap, all save headaches later.

If you're committed to building this, also start a **public devlog** — a Twitter/X account, a Discord, or a development blog. Sim audiences love watching games being built. Crusader Kings, Frostpunk, Stardew Valley all built audiences before launch via devlog content. Three months of consistent devlog posting before your Steam page goes live is worth more than any single marketing push.

Good luck. This is a great concept — the "moonshot industries" framing genuinely differentiates it from existing tycoon games, and the operator + investor + magnate three-leg design is the kind of thing that builds a cult audience. Build the cap table beautifully, get the fundraising negotiation right, and the rest follows.
