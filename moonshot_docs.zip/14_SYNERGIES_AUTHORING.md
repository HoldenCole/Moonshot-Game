# Moonshot Inc — Synergies: Design & Authoring Spec

*The cross-front bonus web — the keystone that makes "a titan, not a conglomerate" real. This is the final content doc: it consumes the synergy tags every other system emits (sub-economies `13`, megaprojects `10`, R&D `09`) and turns them into concrete empire-wide bonuses. Authoring this closes the last dangling-reference category across the entire content set. Conventions: `$M`, weeks, snake_case, content/code boundary.*

> **The thesis it delivers:** a conglomerate owns separate businesses that happen to share a logo. A *titan* owns businesses that **multiply each other** — its chips make its AI better, its AI accelerates all its research, its asteroid mine feeds its fabs, its orbital ring makes all its space ventures cheap. Synergies are the explicit, mechanical reward for spanning fronts as one integrated company. They're why expanding across areas beats staying focused — and why money, late-game, is best spent on *integration.*

---

## Part 1 — What a synergy IS

A **synergy** is a concrete, named bonus that activates when you own/operate two or more parts of your empire that reinforce each other. "Own chips + own AI → your AI R&D is 25% faster." "Operate the asteroid mine → your chip and launch build costs drop." Each synergy is a legible rule: a *source* (something you've built or are producing) → an *effect* (a specific bonus to a specific system).

**The design intent (from `08` §8):** synergies are **explicit and mechanical**, never vague. The player should be able to point at a synergy and say "I get +X to Y because I own Z." That legibility is what makes integration a *strategy* — you can plan toward synergies, see them stack, and feel the empire becoming more than the sum of its parts.

**Two activation models** (the system handles both):

1. **Presence synergies** — activate when you simply *own/operate* the required fronts or have completed the required research. Binary: you have it or you don't. These mostly come from the **R&D tree's cross-domain nodes** (`09`) and **megaproject completions** (`10`). Example: completing `ai_designed_silicon` (which needs both a lab and a chip business) grants the `ai_chip_codesign` synergy — a flat bonus, on as long as you hold it.

2. **Flow synergies** — activate when a **sub-economy produces a resource**, and the bonus **scales with how much it produces** (`13`). The bigger your asteroid operation, the cheaper your chips. These are the dynamic ones — they grow as your sub-economies grow. Example: `asteroid_materials` producing `raw_materials` powers the `cheap_raw_materials` synergy, scaled by output.

Both resolve to the same thing: a named modifier applied to a system you already have.

---

## Part 2 — Why synergies exist (the purpose)

- **They make spanning fronts pay off — the core "titan not conglomerate" mechanic.** Without synergies, owning chips + AI + launch is just three separate businesses. With them, the combination is *worth more than the parts* — which is the entire late-game thesis and the reason to integrate rather than focus.
- **They give the trivial late-game money its best sink: integration.** When cash is easy (`08`), the highest-value spend is often *buying/building the piece that unlocks a synergy* — acquire the supplier, complete the cross-domain research, finish the megaproject whose sub-economy feeds your other fronts. Synergies make "what do I spend on" answerable: *the thing that multiplies everything else.*
- **They're the payoff that closes the loop on sub-economies.** Sub-economies (`13`) *produce*; synergies *consume and amplify.* A Mars colony making materials is interesting; those materials making your entire space program cheaper is the *point.* Synergies are why a sub-economy's output matters beyond its own revenue line.
- **They reward the cross-domain research the R&D tree set up.** The `09` cross-domain nodes (`ai_designed_silicon`, `space_based_compute`, etc.) exist *to grant synergies.* This doc is where those tags become real effects.
- **They make the empire feel like a machine.** When the player sees their orbital solar lowering every division's costs, their AGI speeding every research line, their ring making every launch cheap — the empire stops feeling like a portfolio and starts feeling like an *organism* where everything feeds everything. That's the endgame feeling.

**Design rule — synergies reward integration, never trivialize it.** A synergy should make the combined empire *meaningfully* stronger, but not so strong that not-integrating is unviable or that the bonuses spiral. They're a thumb on the scale toward integration, tuned so a focused player is still competitive and an integrated one is rewarded for the complexity they took on.

---

## Part 3 — How synergies work (the mechanics)

### 3.1 A synergy resolves to a modifier
Every synergy, once active, applies one or more **named modifiers** to existing systems:
- `build_cost_mult` on a set of products/megaprojects (cheaper to build)
- `rd_speed_mult` on a set of R&D lines or all of them (faster research)
- `opex_mult` (lower operating costs)
- `power_bonus` (ongoing strategic importance)
- `retention_bonus` / `share_defense` (market moat)
- `exec_load_relief` / `ops_cost_mult` (AGI running divisions)
- ...the modifier vocabulary the engine knows.

The synergy doesn't invent new systems — it *modifies systems that already exist.* Same philosophy as executives: a layer of multipliers over the running engine.

### 3.2 Presence activation
```
if (required fronts owned) AND (required research complete) AND (required megaprojects complete):
    synergy active → apply its modifiers (flat)
```
On as long as the conditions hold. Most `09`/`10` synergies are these.

### 3.3 Flow activation (scales with sub-economy output)
```
synergy_strength = f(sub_economy resource output)   # more output → bigger bonus, with diminishing returns toward a cap
apply modifiers scaled by synergy_strength
```
The bonus *grows as the feeding sub-economy grows* — your asteroid mine at scale 5000 makes chips much cheaper than at scale 50. Capped so it can't spiral. Most `13` synergies are these.

### 3.4 Stacking & caps
- Multiple synergies can hit the same system (asteroid materials *and* near-free launch both lower space build costs). They **stack multiplicatively** with a **floor** (costs can't go to zero) — so integration compounds but stays bounded.
- Each synergy has a `cap` on its individual contribution. The engine enforces the global floor.

### 3.5 Visibility (the legibility requirement)
The synergy web is a **first-class UI surface** (`08` §9): the player sees every active synergy, its source, its effect, and what's *available but not yet unlocked* ("own a launch business to activate near-free-launch on your satellites"). Synergies are meant to be *planned toward*, so they must be visible and explicit. This is the "explicit and mechanical" requirement made literal.

---

## Part 4 — What you author

**Drop-in path:** `content/synergies/<group>.toml` (grouped: space, intelligence, economic, cross_industry). Tuning in `_tuning.toml`.

```toml
# content/synergies/space.toml
[cheap_raw_materials]
id = "cheap_raw_materials"
name = "Off-world raw materials"
activation = "flow"              # flow | presence
description = """The metals and volatiles your asteroid operation returns feed \
straight into your fabs and your rockets — at a cost no Earth-bound miner can \
touch. The more the belt produces, the cheaper everything you build becomes."""
icon = "gem"

[cheap_raw_materials.source]
# FLOW: powered by a sub-economy resource (13). strength scales with output.
fed_by_resources = ["raw_materials", "quantum_advantage"]   # which sub-economy outputs power it
# (raw_materials from asteroid_materials; quantum_advantage contributes via materials simulation)

[cheap_raw_materials.effect]
build_cost_mult = { ai_chips = 0.85, launch_services = 0.9, space_stations = 0.9 }
# scaled by flow strength toward these floors; cap below.
cap = 0.7                        # this synergy alone can cut cost to at most 70% (×0.7)

[cheap_raw_materials.tuning]
strength_curve = "diminishing"   # how output maps to bonus (diminishing returns)
full_strength_at = 3000          # sub-economy scale at which the bonus ≈ maxes
```

```toml
# content/synergies/cross_industry.toml  — PRESENCE example (from 09 cross-domain)
[ai_chip_codesign]
id = "ai_chip_codesign"
name = "AI–chip co-design"
activation = "presence"
description = """Your own models design your own silicon, and your silicon is built \
for your models — a feedback loop no company renting either half can run. Each \
generation of chips and models makes the next one better."""
icon = "circuit"

[ai_chip_codesign.source]
# PRESENCE: active when these conditions hold.
requires_fronts = ["frontier_model_lab", "ai_chips"]
requires_research = ["ai_designed_silicon"]      # the 09 cross-domain node that emits this tag
requires_megaprojects = []

[ai_chip_codesign.effect]
rd_speed_mult = { ai_chips = 1.25, frontier_model_lab = 1.1 }   # both fronts research faster
cap = 1.4

[ai_chip_codesign.tuning]
# presence synergies are flat — no strength curve needed.
```

### Field reference
- **`activation`** — `flow` (scales with a sub-economy's resource output) or `presence` (binary on conditions).
- **`source`** — for flow: `fed_by_resources` (the `13` outputs that power it). For presence: `requires_fronts` / `requires_research` / `requires_megaprojects` (the `09`/`10` conditions).
- **`effect`** — the named modifiers (`build_cost_mult`, `rd_speed_mult`, `opex_mult`, `power_bonus`, etc.) on which systems, each with a `cap`.
- **`tuning`** — for flow: `strength_curve` + `full_strength_at` (the sub-economy scale where the bonus maxes).

---

## Part 5 — `content/synergies/_tuning.toml`
```toml
[global]
# Global multiplicative floors so stacked synergies stay bounded.
min_build_cost_mult = 0.45       # combined synergies can't cut build cost below 45%
min_opex_mult = 0.5
max_rd_speed_mult = 2.5          # combined R&D speed bonus caps at 2.5×
max_power_from_synergies = 6     # synergies contribute at most +6 power total
[flow]
default_strength_curve = "diminishing"
# diminishing: strength = output / (output + full_strength_at)  → asymptotes toward 1
```

---

## Part 6 — The synergies to author

Two sets. **Set A** = the 13 fed by sub-economies (`13`) / megaprojects (`10`) — these are the flow + completion synergies. **Set B** = the presence synergies from the R&D cross-domain nodes (`09`).

### Set A — the 13 sub-economy / megaproject synergies (mostly flow)

| synergy | activation | fed by / required | effect (intent) |
|---|---|---|---|
| `cheap_raw_materials` | flow | raw_materials, quantum_advantage | ↓ chip/launch/station build cost |
| `off_world_resources` | flow | mars/orbital/asteroid materials | ↓ space megaproject + space product cost |
| `cislunar_logistics` | flow | mars_logistics cislunar_capacity | ↓ space ops cost / faster space builds |
| `mars_manufacturing` | flow | mars_colony materials + research | unique production + research boost |
| `abundant_clean_energy` | flow | space_power clean_energy | ↓ opex empire-wide |
| `near_free_launch` | flow | ring_access launch_access | ↓↓ all launch/space costs (big) |
| `space_native_civilization` | presence | orbital_city + ring_access (capstone) | large power + space-wide cost/▲ |
| `agi_accelerates_all_rd` | flow | agi_services + discovery_engine research_speed | ↑ ALL R&D speed |
| `all_rd_compounding` | flow | discovery_engine research_speed | ↑ R&D speed (compounding) |
| `quantum_advantage_all_rd` | flow | quantum_services quantum_advantage | ↑ materials/optimization R&D |
| `agi_runs_divisions` | flow | agi_services + autonomous_economy division_automation | ↓ exec load / ops cost |
| `economic_gravity` | flow | platform_tolls + autonomous_economy | + power + defensive moat |
| `industry_lock_in` | flow | platform_tolls market_lock_in | + retention / share defense |

### Set B — the presence synergies from R&D cross-domain nodes (`09`)

These tags are emitted by `09` research/cross-domain nodes' `synergy_tags`. Author each as a `presence` synergy keyed to the node(s) that emit it:

| synergy | emitted by (`09` node) | effect (intent) |
|---|---|---|
| `ai_chip_codesign` | ai_designed_silicon | ↑ chip + AI R&D speed |
| `full_ai_stack` | vertically_integrated_ai | ↑ AI compute efficiency + R&D |
| `integrated_space_logistics` | reusable_satellite_launch | ↓ sat build cost + ↑ launch capacity |
| `orbital_construction` | orbital_construction_logistics | ↑ assembly speed + ↓ heavy build cost |
| `orbital_compute` | space_based_compute | ↑ AI compute efficiency + data value |
| `autonomous_space` | autonomous_space_ops | ↓ space ops cost + ↑ capacity |
| `ai_research_engine` | ai_accelerated_research | ↑ all R&D speed (the cross-front capstone) |
| `owns_advanced_fab` | advanced_lithography / node_leadership_program | ↑ AI compute (cheaper in-house silicon) |
| `cheap_launch` | rapid_reuse / heavy_lift / methalox / tether | ↓ all space/launch costs |
| `heavy_lift` | heavy_lift_program | enables/▼cost big space builds |
| (plus the single-front capability tags `09` emits — `alignment_leader`, `data_flywheel`, `mass_production`, etc. — author as small presence self-synergies or treat as capability modifiers; see note) |

> **Note on single-front capability tags:** `09` also emits within-front tags (`alignment_leader`, `data_flywheel`, `synthetic_data`, `mesh_network`, etc.) that aren't cross-front synergies — they're capability modifiers local to one business. Author the genuinely cross-front ones as synergies (Set B); let the local ones resolve as plain capability modifiers in the product/R&D engine (they already warn-gracefully). The validation in Part 7 distinguishes: a synergy needs ≥2 fronts or a sub-economy feed; a single-front tag is just a capability.

**Worked flow example — `near_free_launch`:**
```toml
[near_free_launch]
id = "near_free_launch"
name = "Near-free launch"
activation = "flow"
description = """The orbital ring has turned reaching space into something close to \
an elevator ride. Every satellite you loft, every station module, every ton bound \
for Mars now costs a fraction of what it did. The single greatest cost lever in \
your entire space empire."""
icon = "circle-dashed"

[near_free_launch.source]
fed_by_resources = ["launch_access"]

[near_free_launch.effect]
build_cost_mult = { launch_services = 0.6, satellite_constellations = 0.7, space_stations = 0.7 }
megaproject_cost_mult = { space = 0.75 }     # even megaprojects get cheaper
cap = 0.55

[near_free_launch.tuning]
strength_curve = "diminishing"
full_strength_at = 20000
```

---

## Part 7 — Validation checklist

- [ ] Every flow synergy's `fed_by_resources` is produced by some sub-economy (`13`).
- [ ] Every presence synergy's `requires_fronts` are real sub-industries; `requires_research` are real `09` nodes; `requires_megaprojects` are real `10` ids.
- [ ] Every synergy id is emitted by *something* — a sub-economy `feeds_synergies`, a megaproject `on_complete.synergies`, or a `09` `synergy_tags`. **No synergy with no source. No emitted tag with no synergy** (the closing check — every dangling synergy reference across `09`/`10`/`13` now resolves).
- [ ] Every `effect` modifier key is engine-known; every system it targets (sub-industry, branch, "all") is real.
- [ ] Every synergy has a `cap`; flow synergies have `strength_curve` + `full_strength_at`.
- [ ] Cross-front requirement: each *synergy* (Set B) requires ≥2 fronts OR a sub-economy feed (single-front tags are capabilities, not synergies).
- [ ] `_tuning.toml` global floors present.

> **This is the terminal validation.** When it passes, every synergy tag emitted anywhere in the content set (`09` research, `10` megaprojects, `13` sub-economies) resolves to an authored synergy with a real effect. The entire reference graph — products → R&D → frontier → megaprojects → sub-economies → synergies, with execs gating megaprojects — is closed in both directions. No dangling references remain anywhere.

---

## Part 8 — What I (Claude) build — not authoring

- The synergy engine: presence-condition evaluation, flow-strength computation from sub-economy output (the diminishing curve), modifier application to the product/R&D/finance/ops/megaproject systems, multiplicative stacking with the global floors/caps.
- The resource-pool → flow-synergy wiring (reads what `13` produces).
- The ongoing power contribution from `power_bonus` synergies (`08` §4).
- The Synergy Web UI surface — active synergies (source + effect), and *available-but-locked* ones with what unlocks them — in the `UI_LANGUAGE.md` language. This is the legibility requirement; it's a first-class screen.
- Loader + Part 7 terminal validation → `ContentDB.warnings`.

---

## Part 9 — Suggested authoring order

1. **`_tuning.toml`** — the global floors/caps first (frames how strong synergies can get).
2. **Set A flow synergies** (the 13) — author against the `13` sub-economy outputs you just wrote; the resource feeds are already defined, so these are mechanical.
3. **Set B presence synergies** — author against the `09` cross-domain nodes; each keyed to its emitting node.
4. **Sweep the `09` capability tags** — confirm which are genuine cross-front synergies (author) vs. local capabilities (leave as modifiers).

The feel to aim for: a player looking at their synergy web should see *the machine they built* — chips feeding AI feeding research feeding everything, the asteroid mine cheapening the fabs, the ring cheapening the cosmos — and understand, concretely, that their empire is worth more than the sum of its companies *because they integrated it.* That's the titan fantasy, made mechanical. And with this doc, the content is complete: every system authored, every reference resolved, ready to build.
