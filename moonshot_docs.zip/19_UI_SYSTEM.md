# Moonshot Inc — The UI System: Consolidated Spec

*The complete UI architecture — every tab, what's on it, how it unlocks, how it evolves across the four phases, the visual standard, and the cross-cutting interaction rules. This consolidates every decision from the UI design pass into one buildable document. Mocks referenced throughout are the visual proof of each pattern: `home_reframe.html`, `research_tab.html`, `build_tab.html`, `capacity_subview.html`, `megaprojects_tab.html`, `your_standing.html`, `capital_contracts.html` (v2 = the calibration standard).*

---

## Part 1 — The visual standard (the Contracts-v2 calibration)

The instrument aesthetic, calibrated **bolder, bigger, filterable** (locked on `capital_contracts.html` v2):

**Base language (carried from the existing build):**
- Near-black background (`#0a0d12`), hairline dividers (`#1e2632`) — no card boxes except intentional emphasis panels.
- Uppercase muted micro-labels, white primary values, monospace figures.
- Restrained accents, now with a **firm color code**: **green = money/revenue**, **purple = power/megaprojects/government channel**, **amber = entanglement/warning/bottleneck**, **blue = commercial/action/your-company**, muted grey = locked/off.
- Live ticker, four-zone frame (top bar / icon rail / workspace / narrative rail).

**The calibration (what v2 fixed — apply everywhere):**
- **Bigger:** base type ~14px (was ~12-13). Key values **18-20px bold** — a money figure, a capability score, a power number should be scannable from across the room. Generous row heights (~16px vertical padding) and section spacing.
- **Bold tables over bespoke cards** for anything list-like (contracts, sub-economies, fronts, infrastructure). Big readable names, clean columns, the key figure per row large and colored.
- **Filter pills** on every data-heavy surface — narrow to the slice you want (channel, sector, front, status).
- **View toggles** — re-sort/re-lens the same data by different metrics (the Market tab's "Market cap / Revenue / Growth / Quality" pattern, generalized). E.g. contracts: By value / By entanglement / By term.
- **Roomy drill-in detail** — click a row → a spacious inline panel (or sub-view for big systems) with the full breakdown. Never cram the detail into the list view. One focused decision at a time.

**Anti-density rule:** if a surface needs more data, add a *filter or view toggle*, don't shrink the type. The player chooses their lens; the values stay big.

---

## Part 2 — The tab system

**Left icon rail, in order:** Dashboard → Build → Research → Market → World → Capital → Team → Megaprojects → Empire.

**Unlock model: locked-and-visible** for marquee tabs (Megaprojects, Empire, Research pre-split) — greyed with a lock dot, foreshadowing the endgame. **No Info/Status tab** (dev scaffolding — removed). **Achievements are Steam-only**; in-game milestone *moments* still fire as narrative beats, but there is no in-game achievements grid.

| Tab | Unlock | Evolution |
|---|---|---|
| Dashboard | always | emphasis shifts (Part 3.1) |
| Build | always | hands-on → overview + delegation |
| Research | **splits out of Build** when the R&D tree deepens (first frontier program visible / tree > ~12 nodes). Before: tree lives inside Build. | 1 column → many |
| Market | always | as-is (already the calibration pattern) |
| World | always | mode 2 "Your Standing" populates with power |
| Capital | always | raise-money → full money surface |
| Team | always | early hires → executive suite |
| Megaprojects | **locked-and-visible from start**; unlocks at first completed frontier program | ambitions → in-flight → monuments |
| Empire | **locked-and-visible once Megaprojects unlocks**; unlocks when first megaproject completes | fills sub-tab by sub-tab |

Rail across phases: ~6 active icons (Founder) → ~9 (Sovereign).

---

## Part 3 — Tab-by-tab spec

### 3.1 Dashboard / Command (`home_reframe.html` — V2 approved)
Three bands, same skeleton all game, **emphasis shifts by phase** (never a different layout):
1. **Headline meter strip** — Stature · Capability · Power · Reach + money (cash/runway/revenue) as cells *in* the band. **Founder:** money cells lead (accent bar on Cash), stature/power read "—". **Titan:** stature leads, money demotes to two quiet cells. The money-inversion made literal by reorder/re-emphasis of the same cells.
2. **Operations band** — the state of **your own fronts** (one detailed front → a row of front health-cells + an active-megaprojects strip). The band that visibly widens with scale.
3. **Pulse band ("Needs you")** — pending decisions, exec escalations, the live beat. Founder: operational ("hire wants to talk"). Titan: strategic ("antitrust inquiry," "Mars now reachable"). The right narrative rail stays as the running log; pulse is its actionable distillation.

**No arc-position header** — phase/arc is an optional view elsewhere, never a home headline.

### 3.2 Build (`build_tab.html` v2 + `capacity_subview.html`)
The operating spine: **allocate · provision · ship.** Every decision comes with **concrete outcome-framed numbers + an exec recommendation.**
- **Research Stance (allocate):** no sliders. **Four preset stances** (Push capability / Balance / Harden reliability / All-in scaling), each showing its concrete outcome ("reach **Q40** in **~16wk**; reliability slips") with the mix shown small. An **exec advice strip** above: the CTO's pick + reasoning, one-click "Take advice." Manual per-line control behind an "advanced" link. Titan: **auto-accept** available (full delegation).
- **Capacity (provision):** a **summary line** on Build's main view with the bottleneck flag ("⚠ Compute-limited — throttled to 70%; your stance can't hit its numbers · Expand ▸") opening the **Capacity sub-view**: the bottleneck headline (teaches compute gates capability — "designed to reach Q40 in 16wk; at current compute, ~23wk"), per-type lever blocks (utilization, what it gates, **outcome-framed buys**: "+6 clusters · $7.5M → runs 2× bigger → fully unblocks"), exec read. **Titan: cross-front allocation** — utilization per front, marginal ROI per buy ("Chips is your bottleneck, not the Lab"). Same pattern for every capacity type (compute/fab/cadence).
- **Products (ship):** a **pipeline** (Ready to build | In build · shipped). Click a product → roomy specifics (cost / build time / ship date / revenue / slot / unlocks) + the relevant exec's read. The action button **states the breakdown**: "Build · $1.2M · 3wk · ships ~Q14" — never a bare "Commit."
- **Titan front model:** an **overview grid** of fronts (health + stance + who runs it: "advised by" = you steer, "auto" = delegated) that drills into one front's full three sections.

### 3.3 Research (`research_tab.html`)
The 82-node tree, **hybrid per-front-columns + decision-first**, with **target-and-path planning**.
- **Header:** research **slots** (used/available dots) — the scarcity headline.
- **Frontier Programs band** (elevated, purple): the marquee endgame research, locked-and-visible, each showing the megaproject it gates.
- **Cross-Domain band:** integration nodes; populates with multiple fronts.
- **Per-front columns:** each front's climb, leading with **Available now**, then locked-with-prereqs.
- **Goal mode:** click any node (even far-off) → "Set as goal" → the **path readout** (ordered route across columns, ✓done/in-progress/next with step numbers, total cost/time, **the blocker called out**: "chips lags — push neuromorphic") + on-path nodes highlighted amber, off-path dimmed to ~20%. Teaches two-pillar gates naturally. Browse mode = the landscape; goal mode = the plan.

### 3.4 Market — exists; already the calibration pattern (sector pills + metric view toggle + bold table). No redesign.

### 3.5 World — two-mode tab (`your_standing.html`)
Toggle: **The World | Your Standing.** Mode 1 (exists): master variables + sector hype — the weather acting on you. Mode 2 — the standing you've built:
- **Power:** always present, **de-emphasized early** (a quiet one-liner: dots + "On the map"), **dominant late** (the big purple headline block: "A Power in Your Own Right · 6"). The ladder shows **only the next rung** — never the full climb; "More Powerful Than the Government" appears only when close. The arc unfolds.
- **Identity:** commercial:gov revenue mix bar → label (Independent → Government Partner → National Champion → State-Entangled), next tier only.
- **Entanglement:** the meter + the **double-edged ledger** — "What it buys" (power, protection, revenue floor) vs. "What it costs" (scrutiny, export controls, can't exit). The contracts tension made visible.
- **Government relationships:** per-state standing + obligations ("Intelligence Service · Exposed · leak risk active"), linking to Capital ("manage contracts ▸").
- **Scrutiny:** the watched-ness meter + active pressure. **Sovereign standing** (late): the peer-power beats.

### 3.6 Capital — sub-tabbed money surface (`capital_contracts.html` v2)
Sub-tabs: **Overview / Fundraising / Contracts / Cap Table / Debt.** Reframed from "raising money" to *every way money flows.*
- **Contracts (the new one, fully designed):** filter pills (All/Commercial/Government) + view toggle (By value / By entanglement / By term) over a **bold table** (revenue big green; power purple; entanglement amber; commercial rows read "no strings"). Click → roomy detail: 5-cell breakdown + the exec framing government deals as an **identity choice** ("a step toward becoming a national champion — if that's who we want to be, take it"). Take button states the cost ("Take contract · +2 power, +12 entangle") vs. "Pass — stay independent." Locked rows show the clearance gate. Header ties **total entanglement → Your Standing.** Active contracts table shows each deal's revenue/power/entanglement/obligations.
- **Fundraising:** exists (the negotiation surface) — as-is.
- **Overview (spec):** the money-flow at a glance, inverting by phase — Founder: runway + raise (survival); Titan: the revenue firehose by source (products / contracts / sub-economies) and deployment by sink (R&D / megaprojects / infrastructure). Bold figures, one screen.
- **Cap Table / Debt:** existing surfaces, foldered in.

### 3.7 Team — exists (roster + comp). Light evolution: candidate quality reflects talent institutions; exec cards gain their advisory track record ("recommendations taken: 12 · outperformed: 9"). No structural redesign.

### 3.8 Megaprojects (`megaprojects_tab.html`)
Reads **ambition → action → history.** Cinematic weight within the language (purple, bigger type, more air).
- **In Flight:** the staged saga — **stage tracker** (done ✓ / current glowing / future), current-stage detail, **risk readout** (setback %/stage, catastrophe %), expandable **saga log** (the dramatic beats incl. setbacks: "wk 372 — a vehicle test anomaly cost 12 weeks and $400M").
- **Ready to Commit:** the briefed decision at civilizational register — "✓ Convergence reached" badge, spec row (capital / duration / stages / catastrophe tail / power), the payoff line (sub-economy + power + legacy victory), the exec's weighty read, "Begin ▸".
- **Ambitions:** the convergence-gate board — each locked megaproject a **checklist** ("4/6 requirements"), met ✓ vs. missing, **every missing item clickable to where you fix it** (Research ▸ / Capital ▸ / grow ▸). The planning heart.
- **Completed:** singular ones become **monuments**; repeatable ones show **"N built · build another"** with the marginal readout (below).

**Repeatable megaprojects (design addition — fold into the `10` megaprojects doc):**
- Flag: `repeatable: true/false`. **Singular** (achievement — complete once): AGI, Quantum Supremacy, Accelerated Science, Mars Colony, O'Neill Cylinder, Orbital Ring, Sector Dominance, Autonomous Economy. **Repeatable** (infrastructure — build a fleet): Orbital Solar Array, Asteroid Mining Operation, Mars Transit Line.
- **The firm math (mild diminishing with hard floors — no copy is ever worthless):**
  - Cost: copy n = `max(0.55, 1.00 − 0.15·(n−1))` × first cost (floor 55%).
  - Output added: copy n = `max(40, 100·0.80^(n−1))` (floor **+40**, 40% of first).
  - Power added: copy n = `max(0.5, 2.0·0.70^(n−1))` (fast decay — can't farm power by copy-spam).
  - **Copy 2 is the sweet spot** (85% cost, +80 output — better $/output than the first). Copies still consume a megaproject slot; each scales the sub-economy (step growth) rather than re-opening it.
- **Legibility requirement:** the build-another action shows the marginal value explicitly ("+64 grid capacity (your grid: 244 → 308) · +1.0 power · 15% cheaper — 3rd build") **plus the exec's diminishing-returns nudge** ("after the next one, I'd look at a new frontier instead"). The player always sees exactly what they're getting and when to diversify.

### 3.9 Empire — sub-tabbed cluster (spec; build in the calibration language)
One icon, three sub-tabs — the integrated late-game machine. Unlocks at first megaproject completion.
- **Sub-Economies:** a **bold table** of your frontiers — name, **scale** (big), output/yr (green), resources produced, posture, exec, events flag. Filter pills by branch; view toggle (By output / By growth / By power). Click → roomy drill-in: the scale curve, posture control (grow/harvest/balanced — the one lever, exec-run), produces/consumes flows (what feeds what — the inter-sub dependency made visible), invest-to-raise-cap action (outcome-framed), recent events.
- **Synergies:** the web made legible — **Active** (each: source → effect, with the *live bonus value*: "Near-free launch · fed by Ring Access · −38% space build costs") and **Available-but-locked** (what unlocks each: "own a launch business to activate…"). View toggle: By strength / By system affected. This is the `14` legibility requirement as a surface.
- **Infrastructure:** the buildout catalog — a bold table of the 7 types (built tier, next tier, cost, what it grants — **slot grants prominent**), filter by category. Click → tier detail with outcome-framed effects ("+1 research slot · R&D +15% · $280M · 70wk") + exec read. Build-slot scarcity headlined (like research slots).

---

## Part 4 — Cross-cutting rules

1. **Everything is clickable.** Every meter cell, front, megaproject strip, pulse row, and narrative-rail item navigates to its detail surface. Home meter cells → their tabs (Stature/Power → Your Standing, Capability → Research, money → Capital); convergence-gate items → where you fix them; entanglement readouts → Your Standing; locked products → their Research gate. Nothing is dead text.
2. **Exec advises, you decide.** Every significant decision (stance, product, capacity, contract, megaproject) carries the relevant exec's recommendation *with reasoning* — one-click accept, always overridable, auto-accept available late (the delegation spectrum). Advice quality reflects exec competence — execs earn their salary on-screen.
3. **Outcome-framed numbers.** Lead with what the player gets and when ("reach Q94 in ~18wk", "+64 grid capacity", "ships ~Q14 · ~$40K/mo"), rates on hover/expand. Never a bare percentage or a vague verb ("Commit").
4. **Same skeleton, shifting emphasis.** No tab restructures across phases; emphasis, density, and delegation shift. Money loud→quiet (home, Capital); power quiet→loud (Your Standing); Build hands-on→delegated; bands/columns/tables widen with fronts.
5. **Locked-and-visible foreshadowing** — marquee tabs, frontier programs, next-rung-only power, clearance-locked contracts: the future is glimpsed, not laid out.
6. **Filters + view toggles over density.** More data = another lens, never smaller type.

---

## Part 5 — What I (Claude) build (the UI implementation checklist)
- The rail with phase-gated + locked-and-visible tabs; the Build→Research split trigger.
- Dashboard bands (meter strip w/ phase re-emphasis, operations band, pulse) + full clickability wiring.
- Build: stance presets w/ computed outcomes, exec-advice strips (content from exec sim), capacity summary + sub-view w/ bottleneck computation, products pipeline w/ briefed detail.
- Research: column layout, slots header, frontier/cross-domain bands, **goal-mode pathfinding** (prereq-chain computation + highlight + readout).
- World mode toggle + Your Standing sections (power next-rung logic, identity thresholds, entanglement ledger, relationships, scrutiny, sovereignty beats).
- Capital sub-tabs; the Contracts market (filters, view toggles, briefed detail, entanglement tie); the Overview flow view.
- Megaprojects: stage tracker + saga log + risk, convergence-gate checklists w/ cross-tab links, repeatable build-another w/ marginal math.
- Empire sub-tabs (sub-economy table + drill-in, synergy web, infrastructure catalog).
- The shared calibration components: bold table, filter pills, view toggle, drill-in panel, exec-advice strip, outcome-framed action button.

> **Status: the UI system is fully specified.** Seven mocks prove the patterns; this doc + the content docs (`06`–`18`) + the game bible are the complete blueprint. What remains is implementation.
