# Moonshot Inc

A Steam-first business simulation game where you start a tech company in a future-forward industry, raise venture capital, grow to IPO, and eventually become a magnate running a holding company empire across multiple businesses.

**Core fantasy:** Founder → Executive → Owner → Capital Allocator. Bloomberg-grade financial depth, turn-based pacing, every save dynamic.

**Reference titles:** Coffee Inc 2, Plutocracy, Wall Street Raider, Capitalism Lab, Game Dev Tycoon.

**Full design vision:** see [`docs/game_design_plan.md`](./docs/game_design_plan.md). This document is the tactical implementation guide; the design plan is the long-term bible.

**UI/visual standard:** see [`docs/UI_LANGUAGE.md`](./docs/UI_LANGUAGE.md) — READ BEFORE BUILDING ANY SCREEN. It locks the borderless/flat visual language, the two-kinds-of-motion rule, narrative-as-load-bearing, desktop sizing (1920 baseline, works 1366→ultrawide), and the **hard no-dead-space rule** (regions flex, grids use `fr`/`auto-fit`, content count adapts to width, vertical fill required — a resize must never produce a blank rectangle). This is a Steam *desktop* game: build and judge every screen at real monitor width (1920px), never at a narrow preview width.

---

## Project Status

- **Current phase:** Pre-production / vertical slice
- **V1 scope:** Single industry (AI), founder mode, founding → seed → Series A → B → IPO arc
- **Target platform:** Steam (Windows / Mac / Linux) via Tauri
- **Target launch:** ~12–18 months from project start
- **Mobile port:** Follows Steam launch as V2.0+, focused subset using shared TypeScript core

---

## Tech Stack

| Layer | Choice | Notes |
|---|---|---|
| Desktop shell | **Tauri 2.x** | Rust-based, ~10 MB binaries, Steam-friendly |
| UI framework | **React 18+** | |
| Language | **TypeScript 5+ strict mode** | All financial logic must be typed |
| Build tool | **Vite** | |
| Styling | **Tailwind CSS** | + `shadcn/ui` components |
| Charts | **Recharts** | Use `visx` only if Recharts hits a wall |
| Tables | **TanStack Table** | Sortable, filterable, virtualized |
| State | **Zustand** | Sliced stores, not one monolith |
| Persistence | **SQLite** | Via `@tauri-apps/plugin-sql` |
| Content | **TOML** | Via `@iarna/toml` |
| Testing | **Vitest** | Sim engine has unit tests; UI has component tests |
| Steam | **Steamworks SDK** via Tauri plugin | Achievements, leaderboards, cloud saves |

**Why this stack:** Claude Code is meaningfully more productive in TypeScript/React than in any game engine language. The game is UI/data heavy, not graphics heavy — React + Tailwind + shadcn is exactly the right toolset. Tauri ships small, fast native binaries that Steam users won't sneer at the way they do at Electron.

---

## Quick Start

```bash
# First-time setup
npm create tauri-app@latest moonshot-inc -- --template react-ts
cd moonshot-inc
npm install
npm install zustand @tanstack/react-table recharts tailwindcss postcss autoprefixer
npm install @tauri-apps/plugin-sql @iarna/toml
npm install -D vitest @testing-library/react

# Initialize Tailwind
npx tailwindcss init -p

# Add shadcn/ui
npx shadcn@latest init

# Run dev
npm run tauri dev

# Build for distribution
npm run tauri build

# Run tests
npm test
```

---

## V1 Scope — What Ships First

**Design philosophy:** V1 is small, polished, exceptional. Every system in V1 must be excellent — no half-finished features. Future content rolls out as Sections (paid DLC + free updates). See `docs/game_design_plan.md` § 17 for the full roadmap.

### IN V1

- **Two playable industries: AI and Space.** Genre identity as a *business sim with frontier-tech texture*, not a single-industry sim. Biotech is deferred because its clinical-trial-pipeline mechanic is a separate system.
- **3 sub-industries per industry** (6 total):
  - **AI:** Frontier Model Lab, Vertical AI SaaS, AI Chips/Silicon
  - **Space:** Launch Services, Satellite Constellations, Space Stations
- **Space signature mechanic: Launch Events.** Probabilistic resolution based on R&D, manufacturing quality, weather, pad infrastructure, cumulative experience. Failures destroy payloads, trigger lawsuits, raise insurance. Successes generate revenue and improve future odds. Risk-management gameplay layer Space companies have that AI companies don't.
- **Founder mode** — one company at a time. Player picks AI or Space at company creation.
- **Full company lifecycle:** founding → pre-seed → seed → Series A → Series B → exit
- **Cap table** as a hero feature — beautifully rendered, live-updating, central. Must be perfect.
- **Fundraising negotiation** as the second hero feature. Must be perfect.
  - **~18 anchor firms + ~80–100 procedural firms at launch.** 7 anchors hand-authored (frontier_partners, helio_capital, atlas_growth, evergreen_capital, redwood_ventures, ironclad_capital, meridian_crossing — these cover the core archetypes and resolve all investor edges the authored companies reference). The **generator produces the remaining ~11 anchor-tier slots AND all procedural fill** by varying the hand-authored anchors as templates. See `docs/entity_vcs.md` for schema + generation rules. Target spread across the full roster: ~6 AI-primary, ~5 Space-primary, ~7 other/generalist; across all stages.
  - 5 hidden personality axes + visible trait tags
  - Sector + stage specialization with flex
  - NPC fund cycles + check size limits
  - Two-tier relationship memory
  - Stage-scaled syndication
  - Hot Deal trigger for competing term sheets
  - Three-mode investor competition (quiet / reactive / pre-emptive)
  - Three discoverability tracks
- **Two exit paths** in V1: Traditional IPO (full three-act process) and Acquisition. Stay-private path is Dynasty DLC.
- **Three-act IPO process** — underwriter selection → roadshow → pricing → first-day reveal as a designed moment
- **Post-IPO (V1):** stock volatility, disclosure costs, 180-day lockup with expiration moment, quarterly guidance, and the earnings-management trade-off (engineer short-term to hit the quarter vs. invest long-term and eat volatility; sustained engineering builds a hidden gap risking eventual miss/restatement, tied to ethics score). Deeper post-IPO (activists, analyst system, buybacks, restatement mechanics, earnings-call mini-game) is DLC/later.
- **Light delegation / executive layer (V1, core):** single-company. Player can hire a handful of key execs (CFO, COO, Head of Revenue, plus one sub-industry leader), set per-area autonomy (*Handle it* / *Recommend* / *I'll decide*), set simple escalation thresholds, and receive reports instead of decisions for delegated areas. Exec quality affects autonomy and decision quality. This is what makes cadence player-defined — fully hands-on (advance weekly, decide everything) through fully delegated (advance in big jumps, handle only escalations + strategy). Architecturally the same system the Mogul DLC extends; do NOT build a throwaway version.
- **Public market** with ~70 procedural public companies across all 8 industries (skewed toward AI and Space); **stocks only**
- **Personal wealth (light):** 5 properties, 8 vehicles, basic philanthropy with 5 cause categories
- **Procedural events:** 50 hand-crafted templates at launch (~15 macro / cross-industry, ~15 AI-specific, ~15 Space-specific, ~5 personal)
- **Dynamic world simulation at full strength** — 5 master variables, all 8 industry hype scores, macro cycle, pre-scheduled black swans, three-layer model. Don't dilute.
- **Difficulty system at full strength** — 8 top-level world variance sliders, each expanding to 2–4 sub-sliders behind an "Advanced" toggle (~25 sub-sliders total). Top-level slider position sets sub-slider defaults; sub-sliders can be independently overridden. Plus Easy/Medium/Hard news cycle selector, 3 preset bundles (Forgiving/Realistic/Brutal). All sliders lock at game start.
- **Industry-specific UI elements:** cap table is universal; launch event screen is Space-only; compute allocation panel is AI-only
- **Core UI:** Steam-first desktop layout with all 5 sidebar sections (Dashboard, Companies, Investments, Life, World)
- **Visual world layer (V1, static illustrations, low-risk):** static state-swapped illustrations as the visual backdrop of the "main screen." A building exterior that swaps across 4 company-stage tiers (garage → real office → big office → HQ tower/campus), plus static scaling vehicle/object illustrations for Space (ships/rockets/satellites) and per-sub-industry "establishing" images. ~20–40 static images total. **NO animation, NO characters, NO live simulation** — the engine just shows the right image for the current state, and clickable regions route to existing dashboards. Art is AI-generated against one locked style prompt + curation (no artist required for V1). **Build the state-swap system with colored-block placeholders FIRST** (Phase 1) so art can never block the build; illustrations drop in as pure enhancement. Keep click→region→dashboard routing as a seam.
- **Steam achievements:** ~30 at launch, split across AI runs, Space runs, and cross-industry plays
- **Steam Cloud sync, multiple named saves with version migration**
- **Steam Workshop scaffolding** (architecture only; modding UI ships in a later free update)
- **English at launch**, localization-ready architecture

### NOT IN V1 — Deliberately Cut

These were considered for V1 and cut to protect polish on the core. They ship later as free updates or paid DLC. Don't sneak them back in.

**Going to Paid DLC (Mogul):**
- Multi-company simultaneous play
- Deep executive layer (delegating whole companies to hired CEOs, exec poaching wars, coups, succession, exec equity at scale) — note: *light* single-company delegation IS in V1; Mogul extends it, doesn't replace it
- Holding companies
- Player's own VC fund

**Going to Paid DLC (Frontier):**
- Biotech & Gene Editing as playable (its own clinical-trial system)
- Energy & Climate as playable
- Cross-industry synergies

**Going to Paid DLC (Dynasty):**
- Stay-private path / secondary tenders / late-stage rounds
- Deep personal wealth (international properties, art, yachts, foundations, status effects)
- Generational play

**Going to Paid DLC (Power Plays):**
- Activist investor mechanics
- Hostile takeovers
- Antitrust mechanics

**Going to Paid DLC (Hard Tech):**
- Defense Tech as playable
- Advanced Manufacturing as playable
- Mobility & Autonomy as playable

**Going to Paid DLC (Quantum Leap):**
- Quantum Computing as playable
- Neurotech / BCI

**Going to Free Updates:**
- 4 missing AI sub-industries (Infrastructure, Robotics, Autonomy, Creative Tools)
- 4 missing Space sub-industries (Mining, In-Space Mfg, Tourism, Lunar Logistics)
- 12 additional hand-crafted firms (rounding to 30 total)
- Direct Listing as alternative IPO path
- Full earnings call mini-game for special quarters
- Player ethics / karma system
- AI Rivals (named persistent capitalists)
- ETFs, bonds, options, futures, distressed debt (rolled out progressively)
- Going-private transactions, secondary stock offerings
- Steam Workshop modding UI
- Additional localizations
- Additional events (50 → 100+ over time)

**The discipline of cutting is what makes V1 great.** When in doubt about scope, cut.

---

## Architecture — The Load-Bearing Decisions

These decisions are committed and shape everything else. Don't relitigate them in code without explicit discussion.

### 1. Turn-Based, Click-to-Advance

The game advances **only when the player clicks**. No real-time ticking, ever. Three advance buttons:

- **Advance Week** (default, 1 week): primary button + Spacebar
- **Advance Month** (4 weeks): Shift+Space
- **Advance to Next Event** (until something requires attention): Ctrl+Space

The simulation's tick unit is **1 game-week**. All durations and rates use weeks as the base.

Auto-pause triggers on any decision-required event regardless of speed: term sheets, board votes, FDA decisions, market shocks, employee crises, news that requires reaction.

### 2. Deterministic Simulation

Given a seed, the simulation produces **identical results**. This is critical for save/reload integrity, debugging, and testing.

- All randomness flows through a single seeded PRNG (use `seedrandom` or implement Mulberry32)
- The PRNG state is part of the save file
- No `Math.random()` anywhere in simulation code — that's a build-failing lint rule

### 3. Pure Simulation Engine, Reactive UI

The simulation engine (in `src/engine/`) is a **pure function**: `(WorldState, PlayerAction) => WorldState`. It has no UI dependencies, no React imports, no DOM access.

The UI subscribes to state via Zustand and dispatches actions. This separation is non-negotiable — it lets us:

- Unit test the simulation without rendering
- Run headless simulations for balance testing
- Port to mobile by swapping the UI layer
- Run rapid playtests via scripts

**Rule:** if you find yourself importing React in a file under `src/engine/`, stop. The logic belongs elsewhere.

### 4. Data-Driven Content

Industries, sub-industries, events, archetypes, properties, comparable rounds, exec roles — all defined in **TOML config files** under `content/`, not hardcoded.

Why this matters:

- Tuning iteration is 10x faster (edit TOML, reload — no recompile)
- Content DLC ships trivially
- Steam Workshop modding becomes possible
- A content designer can contribute without touching code

**Rule:** if a number or string represents game content, it lives in TOML. The TypeScript code reads and applies it.

### 5. Save Format Versioning

Every save file has a schema version. The save loader has migration functions for every version transition. Players whose 30-game-year empires become unloadable will leave Steam reviews; we will not let this happen.

### 6. Hidden vs. Visible State

Some state is shown to the player; some is intentionally hidden. The architecture should make this distinction explicit via the `WorldState` shape.

**Hidden:** industry hype scores (raw numbers), event schedules, exec integrity scores, ethics tracking, exact PRNG state.

**Visible:** macro cycle phase, VC climate gauge (0–100 categorical), IPO window state (Open/Cracking/Closed), industry hype gauges (categorical: Cold/Cool/Warm/Hot/Peak), interest rate.

The visible representations are **derived from hidden state at render time**, not stored separately.

---

## Project Structure

```
moonshot-inc/
├── src/                      # React frontend + game logic
│   ├── components/           # Reusable UI components
│   │   ├── ui/               # shadcn/ui primitives
│   │   ├── charts/           # Chart wrappers
│   │   ├── tables/           # Data table components
│   │   └── layout/           # Sidebar, top bar, panels
│   ├── routes/               # Top-level views (one per sidebar tab)
│   │   ├── Dashboard/
│   │   ├── Companies/
│   │   ├── Investments/
│   │   ├── Life/
│   │   └── World/
│   ├── stores/               # Zustand stores (sliced)
│   │   ├── worldStore.ts
│   │   ├── playerStore.ts
│   │   ├── uiStore.ts
│   │   └── settingsStore.ts
│   ├── engine/               # Pure simulation logic — NO React, NO DOM
│   │   ├── tick.ts           # Master tick function
│   │   ├── macro.ts          # Macro cycle simulation
│   │   ├── industries.ts     # Industry hype dynamics
│   │   ├── company.ts        # Company state evolution
│   │   ├── capTable.ts       # Cap table math, dilution, vesting
│   │   ├── fundraising.ts    # Round mechanics, negotiation outcomes
│   │   ├── events.ts         # Event scheduling and firing
│   │   ├── publicMarket.ts   # Stock price evolution
│   │   ├── prng.ts           # Seeded random
│   │   └── index.ts          # Public engine API
│   ├── types/                # Shared TypeScript types
│   │   ├── world.ts
│   │   ├── company.ts
│   │   ├── player.ts
│   │   ├── events.ts
│   │   └── index.ts
│   ├── lib/                  # Utilities
│   │   ├── format.ts         # Number/currency formatting
│   │   ├── content.ts        # TOML content loader
│   │   └── save.ts           # Save/load logic
│   ├── content/              # Loaded TOML content (TS-importable)
│   ├── App.tsx
│   └── main.tsx
├── src-tauri/                # Tauri/Rust shell — minimal custom code
│   ├── src/
│   │   ├── main.rs
│   │   └── steam.rs          # Steamworks integration
│   ├── tauri.conf.json
│   └── Cargo.toml
├── content/                  # Source-of-truth TOML files
│   ├── industries/
│   │   └── ai.toml
│   ├── sub_industries/
│   │   └── ai_*.toml
│   ├── events/
│   │   ├── macro.toml
│   │   ├── ai.toml
│   │   ├── company.toml
│   │   └── personal.toml
│   ├── archetypes/
│   │   ├── investors.toml
│   │   ├── executives.toml
│   │   └── public_companies.toml
│   ├── properties.toml
│   ├── vehicles.toml
│   └── strings/              # User-facing strings (i18n later)
│       └── en.toml
├── tests/
│   ├── engine/               # Sim engine unit tests
│   └── integration/          # End-to-end scenarios
├── docs/
│   ├── game_design_plan.md   # The full design vision
│   ├── architecture.md       # Deeper architecture notes
│   └── content_authoring.md  # How to write events, archetypes, etc.
├── CLAUDE.md                 # This file
├── README.md
└── package.json
```

---

## Core Data Models

These are the key TypeScript types. Define them in `src/types/` early — they shape everything.

```typescript
// types/world.ts

export type IndustryId =
  | 'space' | 'ai' | 'biotech' | 'energy'
  | 'defense' | 'manufacturing' | 'mobility' | 'quantum';

export interface GameDate {
  year: number;       // game year, 1-indexed
  week: number;       // 1–52
}

export type CyclePhase = 'boom' | 'mid' | 'late' | 'recession' | 'recovery';
export type IPOWindow = 'open' | 'cracking' | 'closed';

export interface MacroState {
  phase: CyclePhase;
  gdpGrowth: number;        // -0.05 to 0.06 typical
  inflation: number;        // 0.00 to 0.10 typical
  fedFundsRate: number;     // 0.00 to 0.08 typical
  unemployment: number;     // 0.03 to 0.12 typical
  consumerConfidence: number; // 30 to 130
}

export interface IndustryState {
  id: IndustryId;
  hype: number;             // 0–100, hidden from player
  cyclePhase: 'cold' | 'heating' | 'peak' | 'cooling';
  capitalAvailable: number; // multiplier vs baseline
  talentCostMultiplier: number;
}

export interface WorldState {
  date: GameDate;
  prngState: number;        // serializable PRNG state
  saveSchemaVersion: number;
  macro: MacroState;
  industries: Record<IndustryId, IndustryState>;
  vcClimate: number;        // 0–100
  ipoWindow: IPOWindow;
  publicMarket: PublicMarketState;
  scheduledEvents: ScheduledEvent[];
  newsLog: NewsItem[];      // scrolling ticker, last 200 items
}
```

```typescript
// types/company.ts

export type CompanyStage =
  | 'idea' | 'pre-seed' | 'seed'
  | 'series-a' | 'series-b' | 'series-c' | 'series-d'
  | 'pre-ipo' | 'public';

export interface Company {
  id: string;
  name: string;
  industry: IndustryId;
  subIndustry: string;      // e.g. 'ai-frontier-lab'
  stage: CompanyStage;
  founded: GameDate;
  capTable: CapTable;
  financials: Financials;
  team: TeamMember[];
  metrics: Metrics;
  customers: number;
  productMaturity: number;  // 0–100
  brand: number;            // 0–100
  isPublic: boolean;
  ticker?: string;          // if public
}

export interface CapTable {
  authorizedShares: number;
  shareholders: Shareholder[];
  optionPool: { authorized: number; granted: number; available: number };
  rounds: FundingRound[];
}

export interface Shareholder {
  id: string;
  name: string;
  type: 'founder' | 'employee' | 'investor' | 'esop' | 'public';
  shares: number;
  shareClass: ShareClass;
  vesting?: VestingSchedule;
}

export type ShareClass = 'common' | 'preferred-a' | 'preferred-b' | 'preferred-c' | string;

export interface VestingSchedule {
  startDate: GameDate;
  totalWeeks: number;       // typically 208 (4 years)
  cliffWeeks: number;       // typically 52 (1 year)
  vestedSoFar: number;      // cached for display
}

export interface FundingRound {
  series: 'pre-seed' | 'seed' | 'a' | 'b' | 'c' | 'd' | 'pre-ipo';
  date: GameDate;
  preMoney: number;
  raised: number;
  postMoney: number;
  pricePerShare: number;
  newSharesIssued: number;
  leadInvestorId: string;
  participants: { investorId: string; amount: number }[];
  terms: RoundTerms;
}

export interface RoundTerms {
  liquidationPref: number;  // 1.0 = 1x, 2.0 = 2x
  participating: boolean;
  antidilution: 'broad-based-weighted' | 'narrow-based-weighted' | 'full-ratchet';
  proRataRights: boolean;
  boardSeatsForLead: number;
  optionPoolTopUp: number;  // % of post-money
}

export interface Financials {
  cash: number;
  monthlyBurn: number;
  monthlyRevenue: number;
  runwayWeeks: number;       // derived: cash / weeklyBurn
  arr: number;               // annualized run rate
  // ... extend as needed
}
```

```typescript
// types/player.ts

export interface Player {
  name: string;
  cash: number;
  netWorth: number;
  reputation: number;        // 0–100, visible
  ethics: number;            // 0–100, hidden (V1.5+)
  ownedCompanyIds: string[];
  publicHoldings: PublicHolding[];
  privateHoldings: PrivateHolding[];
  properties: PropertyOwned[];
  vehicles: VehicleOwned[];
  donations: Donation[];
  achievements: string[];    // achievement IDs unlocked
}

export interface PublicHolding {
  ticker: string;
  shares: number;
  avgCost: number;
  currentValue: number;      // derived
}
```

---

## V1 Build Priorities (Ordered)

Build these in order. Each phase produces something runnable; later phases build on earlier ones.

### Phase 1 — Foundation (Week 1–2)
1. Project scaffolding (Tauri + React + TS + Tailwind + shadcn)
2. Core data types in `src/types/`
3. Seeded PRNG (`src/engine/prng.ts`) + tests
4. TOML content loader (`src/lib/content.ts`)
5. Initial layout shell (top bar, sidebar, center, right panel) with placeholder content
6. Routing between five main sections
7. Zustand stores skeleton

### Phase 2 — Cap Table Hero (Week 3–4)
1. `src/engine/capTable.ts` — share math, dilution calculations, vesting
2. Cap table view component (the hero screen) — beautifully formatted table showing founder %, investor stakes, ESOP, fully-diluted math
3. Visual polish — this is the screen that sells the game
4. Unit tests for cap table math

### Phase 3 — Time Advancement (Week 5)
1. `src/engine/tick.ts` — master tick function
2. Advance Week / Month / Event buttons functional
3. Date display, time controls in top bar
4. World state updates on tick (macro variables drift, news items append)

### Phase 4 — Fundraising Negotiation (Week 6–7)
The second hero feature, and the most replayable mini-game.

1. `src/engine/fundraising.ts` — round triggering, negotiation logic, 5 negotiable terms (valuation, round size, liquidation preference, board seats, option pool)
2. Investor archetype generation (procedural, from TOML pool)
3. Term sheet UI with three-layer evaluation help: color-coded terms, Comparable Rounds widget, live cap table preview
4. Negotiation flow — up to 3 rounds (opening offer → counter → final response)
5. Soft reaction signals (qualitative tags, NOT probability percentages)
6. Investor counter-logic combines: company metrics + macro state + 5 personality axes + relationship history
7. Walk-away mechanics with single-walk + serial-walk consequences
8. Lead negotiation + recommended-followers approval flow for Series A+
9. Hot Deal trigger logic for competing term sheets (~3% of rounds, gated by metrics + hype)
10. Inbound offers system — hot companies receive unsolicited term sheets
11. Outcome resolution updates cap table; relationship score and event log updated

**Architectural note:** The investor type system must support a `'self'` investor type from day one even though V1 has no self-investing. Angel investing arrives in a free update; player's own VC fund arrives in Mogul DLC. When those land, self-investing in your own rounds should plug in without rework. Design the `Investor` type with this in mind.

### Phase 5 — World Simulation (Week 8–9)
1. `src/engine/macro.ts` — macro cycle simulation with 5 phases (Boom/Mid/Late/Recession/Recovery)
2. `src/engine/interestRate.ts` — Taylor-rule-derived quarterly rate updates
3. `src/engine/vcClimate.ts` — weekly drift with multiple modifier inputs
4. `src/engine/ipoWindow.ts` — event-driven 3-state machine (Open/Cracking/Closed)
5. `src/engine/industries.ts` — hype dynamics per industry with mean reversion + cross-industry contagion
6. World tab: sector heat map, macro dashboard
7. Five master variables visible; underlying scores hidden (per news cycle setting)
8. News feed (procedural generation from world state changes)

**Critical reference:** see `docs/game_design_plan.md` § 12 "Master Variables: Full Formulas" for exact formulas, ranges, modifier values, update cadences, and modulation effects. All numerical constants in that section should be defined in TOML config files (under `content/world/`) — NOT hardcoded — so they can be tuned without recompiling.

Sub-slider modulations from the difficulty system (Macro Volatility expand, Sector Volatility expand, etc.) override the default formula parameters. See § 12 Difficulty Sliders for the sub-slider → parameter mapping tables.

**The 6 master variable update functions are pure** — they take current `WorldState` + the seeded PRNG and return new state. No side effects. This is critical for save determinism and unit testing.

### Phase 6 — Public Market (Week 10–11)
1. ~70 procedural public companies across 8 industries (skewed toward AI and Space)
2. `src/engine/publicMarket.ts` — stock price evolution
3. `src/engine/companyGraph.ts` — light company relationship graph. Typed edge list `{ from, to, type, strength }` with 4 relationship types in V1: competitors (within sub-industry), customer↔supplier (cross-sub-industry), sector peers (within industry), investor overlap (shared cap tables). **Build the graph structure to support deeper relationship types later without a rewrite** — it's cheap to build now, expensive to retrofit. See `docs/game_design_plan.md` § "Light Company Relationship System" for the full spec.
4. Investments tab: stock list, individual stock view, charts
5. Company detail page includes a "Relationships" section (competitors / suppliers-customers / shared investors, all clickable to navigate)
6. Buy/sell flow
7. Watchlist

### Phase 7 — Events Engine (Week 12)
1. `src/engine/events.ts` — scheduling and firing
2. 50–80 event templates in TOML
3. Auto-pause integration on critical events

### Phase 8 — Personal Wealth (Week 13)
1. Properties (purchase, value tracking)
2. Vehicles (collector value)
3. Philanthropy (donations, reputation effects)
4. Life tab UI

### Phase 9 — Operating Loop + Light Delegation (Week 14–15)
1. Hiring decisions (engineers, executives)
2. Strategic decisions surfaced periodically (events + thresholds + player-initiated mix)
3. Quarterly company review
4. Operating choices affecting metrics
5. Multi-phase signature processes (commit → anticipate → resolve): training runs, launches, tape-outs, enterprise deals, deployments, module builds — each sub-industry's signature mechanic plays out over multiple ticks with a resolution moment
6. **Light delegation / executive layer** — `src/engine/delegation.ts`. Hire key execs; per-area autonomy settings (*Handle it* / *Recommend* / *I'll decide*); escalation thresholds; report generation for delegated areas; exec quality affecting autonomy and decision quality. **Delegation IS the auto-decisions system**: whatever is delegated resolves automatically on time-advance; whatever isn't surfaces as a pause. This is the mechanism behind player-defined cadence. Build the data model so the Mogul DLC's deep executive layer extends it without rework. See `docs/game_design_plan.md` § "Delegation & the Executive Layer."
7. "This week" recap generation (procedural CEO log from the tick's events) + smart advance hints (suggest "jump to next decision" on quiet stretches; warn before overshooting a pending resolution)

### Phase 10 — IPO + Exit Paths + Steam Achievements (Week 16)
1. Three-act IPO process (underwriter selection, roadshow, pricing)
2. First-day trading reveal as a designed moment
3. Post-IPO quarterly guidance system
4. **Earnings management trade-off** — engineer short-term (pull revenue forward, cut R&D/hiring, defer investment) vs. invest long-term; hidden engineered-vs-real gap that builds restatement/miss risk; ties into ethics/integrity score. See `docs/game_design_plan.md` § "Earnings Management."
5. 180-day lockup + lockup expiration event
6. Late private rounds + secondary tender offers (stay-private path)
7. Acquisition offers as procedural events
8. ~30 achievements wired up
9. Cosmetic polish, sound design pass

### Phase 11 — Closed Steam Playtest Prep (Week 17–20)
1. Save/load with version migration
2. Steam Cloud integration
3. Performance optimization
4. Balance pass on numbers
5. Bug fixes, UX polish

This is roughly 5 months of focused work. Reality: budget 6–9 months for a solo dev with Claude Code. Steam page goes up around Week 8 (Phase 5 complete) so wishlist farming starts as soon as the game has presentable screenshots.

---

## Coding Conventions

### TypeScript

- **Strict mode always.** `tsconfig.json` has `"strict": true`. No `any` without an inline justification comment.
- **Numeric IDs are bad.** Use string IDs (`'company_001'`) not numbers — easier debugging, no collision risk.
- **Currency as cents.** Store all money as integer cents (`number`) to avoid float errors. Format for display only.
- **Dates as `GameDate` objects.** Never use `Date` objects for in-game time.
- **Discriminated unions for state.** When something has multiple shapes (e.g., `Company` while private vs public), use discriminated unions, not optional fields.

### React

- **Function components only.** No classes.
- **Hooks at the top.** Custom hooks in `src/hooks/`.
- **No game logic in components.** Components dispatch actions to Zustand stores; stores call into `src/engine/`.
- **Props are typed explicitly.** No prop spreading without type checks.
- **Avoid prop drilling** beyond two levels — use a store or context.

### Zustand Stores

- **Sliced.** Multiple small stores, not one giant store.
- **Selectors.** Components subscribe to slices via selectors to minimize re-renders.
- **Actions are explicit.** No mutating state outside the store's actions.

### Engine Code (`src/engine/`)

- **Pure functions only.** No side effects, no React, no DOM, no I/O.
- **Input → output.** Take state and inputs, return new state. Never mutate.
- **All randomness via PRNG.** Importing `Math.random` in this directory should fail the build.
- **Test everything.** Engine functions get unit tests in `tests/engine/`.

### File Naming

- Components: `PascalCase.tsx`
- Hooks: `useThing.ts`
- Utilities: `camelCase.ts`
- Engine modules: `camelCase.ts`
- Types: `camelCase.ts`
- TOML content: `snake_case.toml`

---

## Data-Driven Content

### Format

All content in TOML. Loaded at startup, validated against schemas, made available via typed accessors.

### Example: Industry Definition

```toml
# content/industries/ai.toml

id = "ai"
display_name = "Artificial Intelligence"
icon = "brain"
description = "..."

# Cycle parameters
[cycle]
phase_duration_weeks_min = 100
phase_duration_weeks_max = 150
hype_baseline = 55
hype_volatility = 1.2

# Sub-industries are in separate files under content/sub_industries/
sub_industries = [
  "ai_frontier_lab",
  "ai_vertical_saas",
  "ai_chips",
  "ai_infrastructure",
  "ai_robotics",
  "ai_autonomy",
  "ai_creative_tools",
]
```

### Example: Event Template

```toml
# content/events/ai.toml

[[event]]
id = "ai_breakthrough_scaling"
category = "industry"
industry = "ai"
weight = 5
cooldown_weeks = 200

# Conditions for firing
[event.conditions]
min_hype = 40
max_hype = 80
phase = ["heating", "peak"]

# Effects
[event.effects]
hype_delta = 12
news_template = "Breakthrough in [model_class] training shows [percent]% efficiency gains, sending [sector_name] valuations soaring."

[event.player_decision]
required = false
```

### Schema Validation

Use Zod or io-ts to validate TOML at load time. Bad content should fail loudly during development, not at runtime in front of a player.

---

## Save System

### Schema Version Migration

```typescript
const CURRENT_SAVE_VERSION = 3;

const migrations: Record<number, (save: any) => any> = {
  1: (save) => ({ ...save, vcClimate: 50, schemaVersion: 2 }),
  2: (save) => ({ ...save, prngState: hashSeed(save.seed), schemaVersion: 3 }),
  // Add migration on every schema change
};

function loadSave(raw: any): WorldState {
  let save = raw;
  while (save.schemaVersion < CURRENT_SAVE_VERSION) {
    save = migrations[save.schemaVersion](save);
  }
  return save as WorldState;
}
```

**Rule:** every schema change ships with a migration. No exceptions.

### Save Storage

- SQLite database in user data directory (Tauri provides path)
- Multiple named saves
- Steam Cloud sync for cross-machine play
- Manual export/import to JSON for backup

---

## Working with Claude Code

Tips that make Claude Code dramatically more productive on this codebase:

### Reference the Right Doc

- For **what to build** → this file (`CLAUDE.md`) and `docs/game_design_plan.md`
- For **why we made a decision** → `docs/architecture.md` (write this as decisions accumulate)
- For **how a mechanic should work** → `docs/game_design_plan.md` sections by topic

### Constrain the Surface Area

When asking Claude Code to implement something, point it at:

- The relevant types in `src/types/`
- Any existing similar engine module
- The relevant content TOML schema

This dramatically improves output quality vs. a vague request.

### Engine vs. UI Work

Engine work is the higher-leverage place to use Claude Code — it's pure logic, easy to test, and a wrong implementation is caught fast by tests. UI work is also a good fit but iterate visually.

### Tests First for Financial Math

Cap table math, dilution calculations, fundraising outcomes — write the tests first. These are the places where bugs cause player-facing wrongness that destroys trust. Claude Code is good at writing both the test and the implementation; do the test first, validate the test logic, then have it generate the implementation.

### Don't Let It Skip Migrations

When changing a save-relevant type, Claude Code may or may not remember the migration rule. Check every schema change has a corresponding migration in `src/lib/save.ts`.

### Don't Let It Use `Math.random()`

There should be a lint rule banning `Math.random()` in `src/engine/`. If Claude Code reaches for it, redirect to the seeded PRNG.

---

## Steam Launch Context

### What Needs to Exist Before Launch

- Game itself (V1 scope above)
- Steamworks account ($100 fee, paid)
- Steam page live with screenshots, description, tags
- Trailer (60–90 seconds)
- Press kit (downloadable from store page)
- Achievements implemented
- Steam Cloud working
- At least one localization (English)
- Tested on Steam Deck (the audience overlaps heavily)
- Wishlists built up over months — aim for 20K+ before launch

### Pre-Launch Marketing (Build in Parallel with Game)

- Devlog (Twitter/X, Bluesky, or YouTube) — start early, post consistently
- Discord server — opens with the Steam page
- Reddit presence in r/incremental_games, r/gamedev, r/games, r/SimulationGames
- Submit to Steam Next Fest (a free festival, do at least one before launch)
- TikTok / YouTube Shorts of cap table dilution math (the audience exists)

### Launch Day Logistics

- Launch discount: 15% off launch week (Steam algorithm rewards this)
- Be available on Discord for first 48 hours — community management matters
- Respond to every review in the first week
- Day-one patch ready for any obvious issues

---

## Where to Find More

| Topic | Document |
|---|---|
| Full design vision | `docs/game_design_plan.md` |
| Industry mechanics in depth | `docs/game_design_plan.md` § 5 |
| Cap table and fundraising | `docs/game_design_plan.md` § 6 |
| Dynamic world simulation | `docs/game_design_plan.md` § 12 |
| Lessons from reference games | `docs/game_design_plan.md` § 20 |
| UI principles | `docs/game_design_plan.md` § 14 |

---

## Open TODOs (Living List)

- [ ] Decide final game name (current: Moonshot Inc — verify trademark)
- [ ] Reserve Steamworks app ID
- [ ] Buy domain
- [ ] Set up devlog (Twitter/X account, blog, or both)
- [ ] Decide art direction — commission illustrator for capsule art OR develop in-house
- [ ] Decide save file location and Steam Cloud paths
- [ ] Decide localization roadmap
- [ ] Set up CI (GitHub Actions for builds + tests)

---

## License

TBD — likely proprietary commercial. Decide before any code is public.
