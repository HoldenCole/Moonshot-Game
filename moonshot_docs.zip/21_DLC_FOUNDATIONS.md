# 21 — DLC Foundations

*The expansion roadmap, and — the important half — the hooks the base game builds NOW so every DLC is an additive content pack + one new engine, never a fork. Base-game principle: ship nothing that blocks these; ship the cheap stubs that enable them.*

---

## Part I — The Lines

### DLC 1: **The Holding Company** (conglomerate / holdco play)
**Fantasy:** stop running a company; run the *structure that owns companies*. Moonshot Group, with your divisions spun into subsidiaries that have their own CEOs, P&Ls, cultures, and agendas — including agendas about you.
**Pillar systems:** subsidiary entities (each a mini-GameSlice: own cash, execs, contracts); the internal capital market (allocate between children, force dividends, starve or feed); spin-offs & subsidiary IPOs (sell 30% of the launch business to fund the AI lab — the market prices your children separately); cross-subsidiary politics (two of your CEOs feuding over transfer pricing is an event chain, not a bug); conglomerate discount/premium mechanics on stature.
**Content families:** `dlc_holdco/` — subsidiary charters, internal-market events, CEO-conflict event chains, activist "break up the group" campaigns.
**Base hooks needed:** subsidiary stub on GameSlice (§III), exec engine already per-domain (maps to per-subsidiary), contracts already tagged by sub_industry (maps to subsidiary books).

### DLC 2: **The High Frontier** (deep-future space & colonies)
**Fantasy:** the megaprojects stop being endings and become *places*. First Light City has factions, a mayor, teenagers, and — eventually — an independence question with your name in it.
**Pillar systems:** colony society sim (population cohorts, factions: Company Loyalists / Homesteaders / Sovereigntists; native-born generation with different loyalties); interplanetary politics (Earth blocs open embassies; your transit line is a border crossing); terraforming tracks as century-scale mega-megaprojects; the Independence Arc — the endgame where your colony wants to be a country, and you choose between empire, federation, or letting go (each a distinct victory).
**Content families:** `dlc_frontier/` — colony factions, society events (three eras: outpost → town → polity), independence event chains, terraforming stages.
**Base hooks:** sub-economy instances already persist per-colony; event pools per sub-economy already exist (society events slot straight in); `ext` bag carries faction state (§III).

### DLC 3: **The Intelligence Age** (deep-future AI & economy — the Frontier's sibling)
**Fantasy:** the equivalent deep-future for the intelligence/economic branches. The Mind isn't a product anymore; it's a demographic. What does the company become when its best employees, sharpest rivals, and loudest critics are systems?
**Pillar systems:** machine-labor economy (AI workforces as a capacity type with rights pressure instead of wages); model-personhood arc (courts, the first AI witness, your own systems petitioning); the post-labor society track (UBI politics, your platforms as the pension system); cognitive-security (model theft, weight exfiltration, alignment incidents as late-game crises).
**Content families:** `dlc_intelligence/` — personhood event chains, machine-labor economics, society-response arcs mirroring The High Frontier's structure.
**Base hooks:** none beyond §III — this is pure content + one engine on existing sub-economies (agi_services, autonomous_economy, discovery_engine already exist as substrates).

### DLC 4: **Dynasty** (legacy, family, succession)
**Fantasy:** the founder is mortal; the company isn't. Play the *family* across generations — heirs raised, groomed, disappointing, brilliant; the succession as the ultimate boss fight; your legacy victories becoming the family's inheritance and burden.
**Pillar systems:** the founder's clock (age, energy, a soft cap on personal attention that makes delegation mechanical, then existential); heirs as generated characters (the exec system pointed inward — traits, competence, *relationships with you*); succession crisis (boards, wills, sibling rivals, the market pricing your mortality); generational play (continue as the heir with the founder's reputation as a modifier); the Biography system — the game's events writing the founder's life story, rendered at death as an obituary the player reads.
**Content families:** `dlc_dynasty/` — heir archetypes, family events (weddings, feuds, prodigals), succession chains, obituary fragments.
**Base hooks:** founder stub with age + founded_week (§III — added now); exec generator already produces characters (heirs reuse it); reports history already exists (the Biography's raw material).

### DLC 5: **The Deal** (VC, PE, M&A, activism)
**Fantasy:** the other side of the table. You've been raising money all game — now *deploy* it: venture arms, buyouts, hostile raids, and eventually acquiring the rivals themselves.
**Pillar systems:** the deal engine (targets generated with real financials; diligence as information-buying; structures: minority / control / merger); your venture arm (seed the startups that become your acquisition pipeline — or your future rivals); PE mode (buy broken companies, install your execs, apply your platforms — the turnaround as gameplay); hostile actions (tender offers, proxy fights, and defending against the same when Praxis comes for *you*); rival acquisition endgame — buying Helion Dynamics is a victory the current game can only imply.
**Content families:** `dlc_deal/` — target company generator tables, deal events, activist campaigns, integration-hell event chains.
**Base hooks:** rivals already have stature (= price); the exec quality feed already models the "install your operators" thesis; companies content family already exists from the early game.

### My additions
- **DLC 6: Shadow Games** (espionage): rivals spy on you and you on them — R&D theft, poach-and-debrief, leak warfare, counter-intelligence as a budget line. Gives the intelligence contracts teeth and the rivals a covert layer. *Cheap: rivals + events + one espionage engine.*
- **DLC 7: The Commons** (public opinion, labor, politics): unions across your empire (the Meridian One strike, generalized), media ownership, elections you can influence and be blamed for, reputation becoming a simulated public rather than a number.
- **Scenario Packs** (small, recurring): authored starts — *The Crash* (begin in a funding winter), *The Incumbent* (begin as a bloated giant being disrupted), *The Race* (a rival starts 2 megaprojects ahead). Pure content on the existing seed/state system.

**Suggested order:** The Deal → Dynasty → The Holding Company → High Frontier → Intelligence Age → Shadow Games / Commons. (Deal and Dynasty deepen the existing mid-game; the deep-future pairs land after players have seen the base endgame.)

---

## Part II — Foundation Rules (base game, effective now)

1. **Everything is a content pack.** DLC = a directory with a `manifest.toml` + the same TOML families the base uses. The loader merges packs additively; new ids append, id collisions are a validation error (no silent overrides).
2. **Namespaces.** Pack content prefixes ids: `dlc_deal_*`, `dyn_*`. Event pools, customers, rival defs, exec domains, effect keys are all open registries — engines iterate what content declares; they never hardcode the list.
3. **Save compatibility.** `GameSlice.schema_version` from day one; all DLC state lives in `GameSlice.ext[pack_id]` — the base serializer never learns DLC internals.
4. **Stable turn phases.** The turn processor's phase order (synergies → research → megas → sub-economies → contracts → power → rivals/world → cash) is a published contract; DLC engines register against named phases rather than patching `advanceTurn`.
5. **Stubs now, systems later.** The base carries cheap fields DLCs will need: `founder { age_years, founded_week }`, `subsidiaries: []`, `deals_log: []`. Costs nothing; means Dynasty/HoldCo/Deal never migrate saves.

## Part III — Implemented with this document
- `mergeContentPacks()` in the loader: additive merge + collision detection, tested with a sample pack.
- `GameSlice`: `schema_version`, `ext`, `founder`, `subsidiaries`, `deals_log` (optional stubs; store initializes).
- This roadmap.
