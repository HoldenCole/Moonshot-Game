# 22 — Pacing, Eras & The Feel Contract

*The turn-by-turn experience is now a designed, MEASURED system. Three engines create the arc; a harness enforces it. "Smooth with ups and downs" is a test suite, not a hope.*

## The three arc engines (`pacing.ts` + `content/eras`, `content/pressures`)

**Eras** — the Founder→Sovereign arc made explicit. Four eras with entry thresholds (Garage <$2B; Scale-Up $2B+; Titan $15B+; Sovereign $45B or power 5) each carrying texture prose and an authored transition moment rendered as a banner in the feed ("The analysts have run out of comparisons…"). Eras traverse strictly forward.

**Macro cycles** — the sine wave under the exponential. steady → (boom | winter) → steady, durations 40–90 weeks, with an alternation bias (the coin leans against repeating the last swing) so every campaign reliably gets both. Booms: +15% on all revenue, +10% growth, a richer contract market. Winters: −20% revenue, −15% growth, a thinner market. Phase shifts arrive as authored beats ("The funding winter arrives the way they always do…").

**Pressures** — the downs that *last*. Five authored multi-turn adversity arcs (Regulatory Crackdown, Supply Crunch, Talent Exodus, Public Backlash, Program Review), each triggered by specific events (the trigger map is validated content), each squeezing real numbers (build costs, R&D speed, contract payments) for 20–39 weeks, each opening and closing with prose. A crisis is no longer a one-click delta — it's weather.

**The texture floor** — the world-news roll is adaptive: a turn that would otherwise be silent gets an 85% chance of a world beat; a busy turn only 25%. Quiet weeks feel like a living world's quiet, not a dead one.

## The feel contract (pacing_test.ts — 24 seeded campaigns × 800 weeks, 6/6 passing)
| Target | Result |
|---|---|
| T1 Dead turns (zero visible beats) < 12% | **5.3%** |
| T2 Noisy turns (>6 beats) < 15% | **0.3%** |
| T3 ≥2 winters AND ≥1 boom in EVERY campaign | **24/24** |
| T4 Pressure arcs reach ≥60% of campaigns | **24/24** |
| T5 Eras strictly ordered; Sovereign reached | **24/24** |
| T6 Winters bite: winter net/turn < 80% of boom | **$11M vs $19M** |

Any future tuning change reruns this harness; the feel cannot silently regress.

## Knobs (all TUNING ANCHORS)
Cycle durations/mults (`content/eras/cycles.toml`), pressure durations/modifiers/triggers (`content/pressures`), the texture floor chances (0.85/0.25 in `turn.ts`), era thresholds (`content/eras/eras.toml`), harness targets themselves (`pacing_test.ts`).
