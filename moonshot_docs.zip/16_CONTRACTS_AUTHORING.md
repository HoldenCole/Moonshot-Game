# Moonshot Inc — Contracts: Design & Authoring Spec

*The converter that turns ordinary business into power. This is the mechanical heart of "more powerful than the government as an emergent consequence" (`08` §5) — the system that lets power begin accumulating in the **mid-game** through a choice about *how you do business*, long before the endgame megaprojects. Written to be understood fresh. Conventions: `$M`, weeks, snake_case, content/code boundary.*

> **The one-line frame:** every business can sell to the open market (commercial) or to governments (government/defense). Commercial is clean, flexible, and earns money. Government work pays well and stably **and builds power** — but it *entangles* you: scrutiny, clearances, obligations, political dependency, reputational exposure. The *mix* you choose is a strategic identity. A pure-commercial titan stays nimble and free; a government-entangled one becomes strategically essential — and the path to eclipsing the state runs through the very contracts that first made you depend on it.

---

## Part 1 — What contracts ARE

Right now your products earn revenue from "the market" abstractly. **Contracts** make *who you sell to* a real, recurring decision with consequences beyond the money. A contract is an agreement to deliver something (your products/capacity) to a **customer** over time, for **payment** — and government customers carry **strategic weight** that commercial ones don't.

**Two channels:**
- **Commercial** — sell to businesses and consumers. Clean: take it or leave it, no strings, switch freely. Earns money and nothing else. The default way a startup grows.
- **Government / defense** — sell to states, militaries, space agencies, intelligence services. Pays well and *stably* (multi-year, reliable), and **raises your power/strategic importance** — but it comes with **entanglement**: security clearances, oversight, delivery obligations you can't walk away from, political dependency, and reputational exposure when the work is controversial.

**The mental model:** a contract is a *relationship with a customer that has terms.* Commercial relationships are transactional. Government relationships are *entangling* — they make you matter to the state, which is the seed of power, and also make the state matter to you, which is the cost.

**Contracts are the mid-game power source.** Megaprojects and sub-economies (`10`/`13`) generate power in the *endgame*. Contracts let the power meter start moving much earlier, through a choice available as soon as you have something a government wants to buy. They're how a player *positions for* the sovereign era from the mid-game (`08` §1) — the seeds planted early.

---

## Part 2 — Why contracts exist (the purpose)

- **They convert business success into power — the core thesis made mechanical.** Without contracts, "power as an emergent consequence of business" has no early/mid-game mechanism; power only appears at the megaproject tier. Contracts are the missing converter: an ordinary commercial decision (who do I sell to?) that *accrues* into geopolitical weight. This is the elegant center of `08`'s vision.
- **They make the commercial-vs-government choice a strategic identity.** Two players with identical products play differently based on their contract mix — one a free-floating commercial giant, one a defense-entangled national champion. That's replayability and roleplay from a single recurring decision.
- **They give power a *cost*, so it isn't free.** Government entanglement brings scrutiny, obligations, and reputational risk. Power you earn through contracts is power you *paid* for in independence — which is what makes the "eclipse the state" arc dramatic rather than a free ride.
- **They're a stable-revenue counterweight to volatile commercial markets.** Government contracts are reliable income (good in downturns), trading upside and freedom for stability — a real financial-strategy lever, like the aggressive-vs-cautious CFO choice.
- **They feed the late game.** High government entanglement is a prerequisite-flavor for parts of the sovereign era — executives working directly with the state (`08` §3), the "more powerful than government" power-meter top (`08` §4), and the events that ramp scrutiny as you grow (the power/government events, a later doc). Contracts seed all of it.

**Design rule — neither channel is strictly better.** Commercial keeps you free and nimble; government makes you powerful but entangled. The game must never make one dominant — the choice is a genuine fork in identity, tuned so a pure-commercial player and a government-entangled player are *both* viable, playing different games. Power has a price; freedom has a ceiling.

---

## Part 3 — How contracts work (the mechanics)

### 3.1 The contract market
A pool of available **contracts** surfaces over time, gated by what you can deliver (your products, capacity, tech level, stature). Each is an offer: *this customer wants this deliverable, for this payment, over this term, with these conditions.* You **bid/accept** or decline. Commercial contracts are plentiful and low-friction; government contracts are rarer, bigger, and conditional.

### 3.2 Anatomy of a contract
- **Customer** — commercial (a firm/sector) or government (a named agency archetype: defense ministry, space agency, intelligence service, allied bloc).
- **Deliverable** — what you supply: a product, capacity, a service, exclusivity.
- **Payment** — upfront + recurring (`$M`), often above commercial market rate for government (they pay for priority and secrecy).
- **Term** — duration (`weeks`); government contracts are long and binding.
- **Requirements** — what you must have/do to qualify: tech level, capacity, a security clearance, sometimes an exec (a government-interface exec, `08` §3).
- **Effects** — beyond payment: `power` gain (government), `entanglement` gain (government), reputation shifts, and obligations.

### 3.3 The entanglement axis (the heart of it)
Each player has an **entanglement** level (0–100) — how bound up you are with government/state interests. Government contracts raise it; it decays slowly if you stop taking them.

Entanglement is **double-edged**:
- **Benefits:** raises power/strategic importance (you matter to the state); unlocks bigger government contracts and the sovereign-era government interface; favorable treatment (lighter commercial regulation, inside access, protected status); a stable revenue floor.
- **Costs:** **scrutiny** (your moves are watched; oversight events fire more); **obligations** (you can't freely exit government work or pivot; breaking a government contract is costly and reputation-damaging); **political dependency** (a change in administration or a geopolitical shift can hurt you); **reputational exposure** (controversial defense/surveillance work damages your public/commercial reputation and ethics).

So entanglement is the *price of power-through-contracts*: the more you take, the more powerful and the more bound.

### 3.4 Clearances & gating
Some government contracts require a **security clearance** — a one-time investment (money + time + sometimes an exec) that unlocks a tier of classified/defense work. Clearances are a commitment: getting cleared is itself an entanglement step (you've let the state vet you). Higher clearance tiers unlock the biggest, most powerful (and most entangling) contracts.

### 3.5 Strategic-importance override
As your products/projects become **humanity-critical** (you supply the chips everyone needs, you run critical infrastructure), strategic weight rises **regardless of contract channel** — even a pure-commercial titan becomes strategically important if the world can't function without them (the Apple/TSMC effect). Contracts are the *deliberate* path to power; strategic-criticality is the *emergent* one that happens to any dominant-enough company. The engine grants power from both.

### 3.6 The mix as identity
The game tracks your **commercial : government revenue mix** and your entanglement, and surfaces it as a readable identity ("Independent" / "Government Partner" / "National Champion" / "State-Entangled"). This mix gates and colors late-game content — a National Champion's sovereign era looks different from an Independent's. The mix is a thing you *steer over the whole game*, not a one-time pick.

---

## Part 4 — What you author

**Drop-in path:** `content/contracts/_customers.toml` (customer archetypes), `content/contracts/<industry_or_group>.toml` (contract templates), `content/contracts/_clearances.toml` (clearance tiers), `content/contracts/_tuning.toml`.

Contracts are largely **procedural** (like procedural companies/execs): you author **customer archetypes** and **contract templates** the generator instantiates against the player's current products/stature, plus the clearance ladder and tuning.

### 4.1 Customers — `content/contracts/_customers.toml`
```toml
[commercial_enterprise]
id = "commercial_enterprise"
name = "Enterprise customer"
channel = "commercial"
description = "Businesses buying your products at market. Clean, flexible, no strings."
entanglement_per_contract = 0
power_per_contract = 0
reputation_effect = 0

[defense_ministry]
id = "defense_ministry"
name = "Defense Ministry"
channel = "government"
description = """The military procurement arm of a major power. Pays a premium for \
capability and priority, demands clearance and discretion, and binds you to \
delivery. Working for them makes you matter — and makes you watched."""
entanglement_per_contract = 12
power_per_contract = 2
reputation_effect = -1            # defense work carries public/ethics exposure
requires_clearance = "defense_secret"
escalation_flavor = ["a classified capability request", "a wartime priority order"]

[space_agency]
id = "space_agency"
name = "National Space Agency"
channel = "government"
description = """A government space program that contracts your launch, satellite, \
or station capability. Prestigious, stable, less ethically fraught than defense — \
and a strong, visible source of strategic standing."""
entanglement_per_contract = 8
power_per_contract = 2
reputation_effect = 1             # space-agency work is prestigious
requires_clearance = ""

[intelligence_service]
id = "intelligence_service"
name = "Intelligence Service"
channel = "government"
description = """The shadow customer — wants your compute, your models, your \
satellites pointed where they say, and your silence about it. The deepest \
entanglement and the highest reputational risk if it ever surfaces."""
entanglement_per_contract = 18
power_per_contract = 3
reputation_effect = -2
requires_clearance = "intelligence_ts"

[allied_bloc]
id = "allied_bloc"
name = "Allied Government Bloc"
channel = "government"
description = """A coalition of allied states contracting at scale — the biggest \
government money and the broadest strategic standing, available only to a company \
of real stature and clearance."""
entanglement_per_contract = 15
power_per_contract = 3
reputation_effect = 0
requires_clearance = "defense_secret"
```

### 4.2 Contract templates — `content/contracts/<group>.toml`
```toml
[defense_chip_supply]
id = "defense_chip_supply"
customer = "defense_ministry"
name = "Defense chip supply contract"
description = """A standing order for your most advanced silicon, hardened and \
prioritized for military systems. Lucrative, long, and binding — and it makes your \
fabs a national-security asset."""
sub_industry = "ai_chips"          # who can take it
requires = { rd_levels = { process_node = 50 }, product_tier = 2, stature_min = 6000 }
payment = { upfront = 80, recurring_per_year = 120, term_weeks = 156 }
deliverable = "priority_supply"    # consumes capacity/output
effects = { power = 2, entanglement = 12, reputation = -1 }
obligations = "Cannot reduce supply or exit without a major reputation + power penalty."

[space_agency_launch]
id = "space_agency_launch"
customer = "space_agency"
name = "National launch services contract"
description = """A multi-year contract to fly a government space program's payloads \
— prestige, stable revenue, and a visible badge of strategic standing."""
sub_industry = "launch_services"
requires = { rd_levels = { reliability = 45 }, product_tier = 1, stature_min = 4000 }
payment = { upfront = 60, recurring_per_year = 90, term_weeks = 130 }
deliverable = "launch_capacity"
effects = { power = 2, entanglement = 8, reputation = 1 }

[intel_compute_access]
id = "intel_compute_access"
customer = "intelligence_service"
name = "Classified compute & model access"
description = """Priority access to your frontier models and compute for an \
intelligence service — for purposes you're not allowed to ask about. Enormous \
money, enormous entanglement, and a reputational time bomb if it leaks."""
sub_industry = "frontier_model_lab"
requires = { rd_levels = { scaling = 60 }, product_tier = 3, stature_min = 14000, clearance = "intelligence_ts" }
payment = { upfront = 200, recurring_per_year = 300, term_weeks = 208 }
deliverable = "priority_model_access"
effects = { power = 3, entanglement = 18, reputation = -2 }
obligations = "Leak risk: a scoped event can expose this contract for major reputation damage."

# ... commercial templates too (channel=commercial, entanglement 0, power 0, plentiful)
[enterprise_saas_deal]
id = "enterprise_saas_deal"
customer = "commercial_enterprise"
name = "Enterprise platform deal"
description = "A large commercial customer adopts your platform. Clean money, no strings."
sub_industry = "vertical_ai_saas"
requires = { product_tier = 1, stature_min = 0 }
payment = { upfront = 10, recurring_per_year = 30, term_weeks = 104 }
deliverable = "deployment"
effects = { power = 0, entanglement = 0, reputation = 0 }
```

### 4.3 Clearances — `content/contracts/_clearances.toml`
```toml
[defense_secret]
id = "defense_secret"
name = "Defense Secret clearance"
description = "Vetting that unlocks classified defense contracts."
cost = 40                          # $M + time to obtain
weeks = 26
entanglement_on_grant = 8          # getting cleared is itself an entanglement step
requires = { stature_min = 5000 }

[intelligence_ts]
id = "intelligence_ts"
name = "Intelligence Top Secret clearance"
description = "The deepest vetting — unlocks intelligence-service work."
cost = 90
weeks = 39
entanglement_on_grant = 15
requires = { stature_min = 12000, prior_clearance = "defense_secret" }
```

### 4.4 Tuning — `content/contracts/_tuning.toml`
```toml
[global]
commercial_pool_size = 8          # commercial contracts available at once (plentiful)
government_pool_size = 3          # government contracts rarer
market_refresh_weeks = 13
entanglement_decay_per_year = 6   # entanglement falls if you stop taking gov work
[mix_identity]
# commercial:government revenue ratio → identity label (engine reads)
thresholds = [
  { gov_share_below = 0.1, label = "Independent" },
  { gov_share_below = 0.35, label = "Government Partner" },
  { gov_share_below = 0.6, label = "National Champion" },
  { gov_share_above = 0.6, label = "State-Entangled" },
]
[strategic_criticality]
# emergent power from being humanity-critical, regardless of channel
market_share_for_criticality = 0.4   # dominate >40% of a critical market → power even if pure-commercial
criticality_power = 2
```

---

## Part 5 — Validation checklist
- [ ] Every contract template's `customer` is a real customer archetype.
- [ ] Every `requires.clearance` (and customer `requires_clearance`) is a real clearance id; clearance `prior_clearance` resolves; clearance graph acyclic.
- [ ] Every `sub_industry` is real; `requires.rd_levels` reference real lines; `product_tier` exists.
- [ ] Government customers have `entanglement_per_contract` > 0 and `power_per_contract` > 0; commercial have both 0.
- [ ] Every contract `effects` uses engine-known keys (`power`, `entanglement`, `reputation`).
- [ ] ≥1 commercial + ≥1 government contract template per sub-industry (so the channel choice exists everywhere).
- [ ] `_tuning.toml` present with mix-identity thresholds + strategic-criticality.

## Part 6 — What I (Claude) build — not authoring
- The contract engine: the contract market (procedural generation from templates against current products/stature), bid/accept/decline, delivery (consuming capacity/output), payment over term, the binding/obligation enforcement and exit penalties.
- The **entanglement** meter (gain from gov contracts + clearances, slow decay) and its double-edged effects (power up, scrutiny/obligation/dependency).
- The **clearance** ladder (obtain → unlock contract tiers).
- The **strategic-criticality** computation (emergent power from market dominance, channel-independent).
- The **mix identity** tracking (commercial:government ratio → label, gating late-game content).
- Power-meter integration (`08` §4) from both contracts and criticality.
- Hooks for the power/government events (scrutiny/obligation/leak events — the later doc).
- The Contracts UI (the market, your active contracts, entanglement/clearance status, your mix-identity) in the `UI_LANGUAGE.md` language.
- Loader + Part 5 validation → `ContentDB.warnings`.

## Part 7 — Suggested authoring order
1. **`_customers.toml`** — the 5–6 customer archetypes (commercial + the government tiers) first; they define the channels.
2. **`_clearances.toml`** — the 2-tier clearance ladder.
3. **Contract templates** — ≥1 commercial + ≥1 government per sub-industry (≈12–18 templates), each tied to a customer, with sensible pay/term/effects. Government ones premium-priced and entangling; commercial plentiful and clean.
4. **`_tuning.toml`** — pool sizes, decay, the mix-identity thresholds, criticality.

The feel to aim for: every time a juicy government contract appears, the player should feel the pull and the pause — *the money and the power are real, and so is the leash.* Taking it is choosing what kind of titan you're becoming. Over a whole game, those choices compound into an identity: the free commercial giant, or the national champion the state both relies on and fears — the company that took so many government contracts it became more powerful than the government that hired it.
