# Late-Game Integration (v2 systems)

The complete late-game stack now lives inside the repo and passes the full suite
(`npm run typecheck` clean under the strictest flags; `npm test` → 248/248).

## What was added
- **`src/engine/late/`** — ten pure engine modules: research (the 82-node tree),
  megaprojects (11, with the pinned repeat curves), contracts v2 (30 templates,
  entanglement, mix identity), empire (sub-economies + synergies), executives
  (generation/hiring/retention), rivals (6 reactive titans + legacy races +
  poaching), pacing (eras, boom/winter cycles, pressure arcs), advisory
  (noisy-lens exec recommendations), the turn processor, and the content loader.
- **`content/late/`** — 58 TOML files: research, megaprojects, sub-economies,
  synergies, contracts, executives, rivals, eras, pressures, infrastructure,
  113 events (sub-economy / power / world), loading lines.
- **Loaders** — `nodeContent.ts` (fs + smol-toml; used by tests/tooling) and
  `viteContent.ts` (import.meta.glob; used by the app). Identical output shape.
- **`bridge.ts`** — THE handoff. The base game stays the source of truth for
  valuation (→ stature), cash, rd.levels, product tiers, and operated subs;
  `initLateSlice(content, seed, snapshot)` births the late-game slice and
  `syncFromBase(slice, snapshot)` refreshes it each turn before `advanceTurn`.
- **`late.integration.test.ts`** — content loads through the repo's own
  smol-toml path, then an 800-week campaign on the bridge: the real research
  chain → The Sunfarm → space_power opens → synergies fire → contracts +
  entanglement → rivals claim legacies → cycles shift → the era advances.

## Wiring it into the app (next step, not yet done)
1. In the store: `content.late = buildContent(assembleLateContent())` (from
   `viteContent.ts` + `content_loader.ts`), create the slice via `bridge.ts`
   when valuation crosses the Scale-Up threshold (or at new-game for testing).
2. Each end-turn: `syncFromBase` → `advanceTurn` → merge `TurnReport` into the
   news feed. UI tabs for the new systems exist in the design pack
   (`moonshot_ui_kit.zip`) and bind to `GameSlice` + `GameContent` directly.

## Conventions honored
- Repo tsconfig (noUncheckedIndexedAccess, noUnusedLocals/Parameters) — all
  late modules comply. Tests use `node:test` + fs-based TOML like the rest.
- No base-game files were modified. The integration is purely additive.
