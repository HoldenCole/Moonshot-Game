// ============================================================================
// TitleScreen.tsx — the title screen. The signature is THE TRAJECTORY: the
// game's whole arc (Garage -> Sovereign) drawn as one gradient line through
// the game's own value-color language. Everything else stays quiet.
// Repo integration: replaces the NewGameScreen "welcome" step; see
// title_integration_notes.md. Styles: title.css (uses the repo's CSS vars).
// ============================================================================
import React, { useEffect, useRef } from "react";

export interface SaveSummaryLite {
  company: string; week: number; netWorthLabel: string;
  eraName?: string; contextLine?: string;          // e.g. "funding winter, wk 3"
}
export interface TitleStats { programs: number; megaprojects: number; rivals: number; version: string }

export function TitleScreen({ save, stats, onContinue, onNewGame, onScenarios, onSettings }: {
  save: SaveSummaryLite | null;
  stats: TitleStats;
  onContinue: () => void; onNewGame: () => void;
  onScenarios?: () => void; onSettings: () => void;
}) {
  const skyRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const sky = skyRef.current;
    if (!sky || sky.childElementCount) return;
    for (let i = 0; i < 90; i++) {
      const s = document.createElement("i");
      const t = Math.pow(Math.random(), 0.55);
      s.style.left = `${34 + t * 64 + Math.random() * 4}%`;
      s.style.top = `${Math.random() * (1 - t) * 55 + 2}%`;
      s.style.opacity = (0.25 + Math.random() * 0.6).toFixed(2);
      sky.appendChild(s);
    }
  }, []);

  return (
    <div className="ts">
      <div className="ts__traj" aria-hidden>
        <svg viewBox="0 0 1440 810" preserveAspectRatio="xMidYMid slice">
          <defs>
            <linearGradient id="ts-arc" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="var(--accent, #6f9cff)" />
              <stop offset="38%" stopColor="var(--up, #3ad29a)" />
              <stop offset="72%" stopColor="var(--power, #bd9dff)" />
              <stop offset="100%" stopColor="var(--gold, #e8c76a)" />
            </linearGradient>
          </defs>
          <path className="ts__ghost" d="M 120 760 C 560 745, 900 640, 1090 470 S 1330 170, 1400 88" />
          <path className="ts__path" d="M 120 760 C 560 745, 900 640, 1090 470 S 1330 170, 1400 88" />
          {[
            { x: 240, y: 752, c: "var(--accent, #6f9cff)", n: "The Garage", w: "wk 0", cls: "ts-era--1" },
            { x: 760, y: 672, c: "var(--up, #3ad29a)", n: "The Scale-Up", w: "$2B", cls: "ts-era--2" },
            { x: 1105, y: 452, c: "var(--power, #bd9dff)", n: "The Titan Age", w: "$15B", cls: "ts-era--3", above: true },
            { x: 1382, y: 106, c: "var(--gold, #e8c76a)", n: "The Sovereign Era", w: "power 5+", cls: "ts-era--4", end: true },
          ].map((e) => (
            <g key={e.n} className={`ts-era ${e.cls}`}>
              <circle cx={e.x} cy={e.y} r={e.end ? 5 : 4} stroke={e.c} />
              <text x={e.end ? e.x - 20 : e.x} y={e.above || e.end ? e.y - (e.end ? 18 : 24) : e.y + 26}
                textAnchor={e.end ? "end" : "middle"}>{e.n}</text>
              <text className="ts-era__week" x={e.end ? e.x - 20 : e.x}
                y={e.above || e.end ? e.y - (e.end ? 32 : 38) : e.y + 40}
                textAnchor={e.end ? "end" : "middle"}>{e.w}</text>
            </g>
          ))}
        </svg>
      </div>
      <div className="ts__sky" ref={skyRef} aria-hidden />

      <div className="ts__col">
        <div className="ts__wordmark">
          <div className="ts__main">MOONSHOT</div>
          <div className="ts__row">
            <div className="ts__main ts__main--inc">INC</div>
            <div className="ts__sub">FRONTIER · CAPITAL · POWER</div>
          </div>
          <p className="ts__tag">Found a frontier-tech company and take it from <b>a garage</b> to{" "}
            <b>more powerful than governments</b> — if the money, the rivals, and the physics let you.</p>
        </div>

        <nav className="ts__menu" aria-label="Main menu">
          {save && (
            <button className="ts-continue" onClick={onContinue}>
              <div>
                <div className="ts-continue__k">Continue the run</div>
                <div className="ts-continue__co">{save.company}</div>
                <div className="ts-continue__meta">
                  Week {save.week} · <b>{save.netWorthLabel}</b> net worth
                  {save.contextLine ? ` · ${save.contextLine}` : ""}
                </div>
              </div>
              <div>
                {save.eraName && <div className="ts-continue__era">{save.eraName}</div>}
                <div className="ts-continue__arrow">›</div>
              </div>
            </button>
          )}
          <button className="ts-row ts-row--primary" onClick={onNewGame} data-guide="title-new-game">
            <span className="ts-row__tick" />{save ? "Found a new company" : "Found a company"}
            <span className="ts-row__hint">the arc starts at wk 0</span>
          </button>
          {onScenarios && (
            <button className="ts-row" onClick={onScenarios}>
              <span className="ts-row__tick" />Scenarios<span className="ts-row__hint">authored starts</span>
            </button>
          )}
          <button className="ts-row ts-row--quiet" onClick={onSettings}>
            <span className="ts-row__tick" />Settings
          </button>
        </nav>
      </div>

      <div className="ts__foot">
        <span><b>Moonshot Inc</b> · a frontier-capital simulation</span>
        <span>{stats.version} · <b>{stats.programs}</b> programs · <b>{stats.megaprojects}</b> megaprojects · <b>{stats.rivals}</b> rivals</span>
      </div>
    </div>
  );
}
