// ============================================================================
// App.tsx — the shell binding the four assembled tabs to the store.
// Tab bar in the locked UI language; each tab gets live slices + actions.
// ============================================================================
import React, { useEffect, useState } from "react";
import { T } from "./tokens";
import { useGame } from "./store";
import { ContractsTab } from "./ContractsTab";
import { ResearchTab } from "./ResearchTab";
import { MegaprojectsTab } from "./MegaprojectsTab";
import { EmpireTab } from "./EmpireTab";
import { HomeTab } from "./HomeTab";
import { StandingTab } from "./StandingTab";
import { ExecutivesTab } from "./ExecutivesTab";
import { execQuality } from "./executives";
import contentRaw from "./content.json";

const TABS = ["Home", "Contracts", "Research", "Megaprojects", "Empire", "Executives", "Standing"] as const;
type Tab = typeof TABS[number];

export default function App() {
  const g = useGame();
  const [tab, setTab] = useState<Tab>("Home");
  useEffect(() => { if (!g.slice) g.boot(contentRaw as Record<string, any>, 2077); }, []);
  if (!g.slice || !g.content || !g.execContent) return null;
  const s = g.slice, c = g.content;

  const sagaLog: Record<string, { week: number; text: string }[]> = {};
  for (const a of s.megas.active) sagaLog[a.def_id] = a.log.map(l => ({ week: l.week, text: l.text }));

  return (
    <div style={{ fontFamily: T.sans, background: T.bg, color: T.txt, minHeight: "100vh" }}>
      {/* top bar: identity + the numbers that always matter */}
      <div style={{ display: "flex", alignItems: "center", gap: 22, padding: "12px 24px",
        borderBottom: `1px solid ${T.line}` }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ background: "none", border: "none",
            cursor: "pointer", fontSize: 13.5, fontWeight: tab === t ? 700 : 400,
            color: tab === t ? T.white : T.dim, padding: "4px 2px",
            borderBottom: tab === t ? `2px solid ${T.blue}` : "2px solid transparent" }}>{t}</button>
        ))}
        <div style={{ marginLeft: "auto", display: "flex", gap: 18, fontSize: 12.5, alignItems: "baseline" }}>
          <span style={{ color: T.dim }}>wk <b style={{ color: T.white, fontFamily: T.mono }}>{s.week}</b></span>
          <span style={{ color: "#7dc4a6", fontFamily: T.mono, fontWeight: 700 }}>${s.cashM.toFixed(0)}M</span>
          <span style={{ color: "#bd9dff", fontFamily: T.mono, fontWeight: 700 }}>power {s.powerAxis.power}</span>
          <button onClick={g.endTurn} style={{ background: "#16233c", color: "#9fc0ff",
            border: "1px solid #274069", borderRadius: 8, padding: "7px 16px", fontSize: 13,
            fontWeight: 600, cursor: "pointer" }}>End turn →</button>
        </div>
      </div>

      {tab === "Home" && <HomeTab reports={g.reports} week={s.week} />}
      {tab === "Standing" && <StandingTab s={s} c={c} />}
      {tab === "Executives" && (
        <ExecutivesTab state={g.execs} domains={g.execContent.domains} traits={g.execContent.traits}
          quality={execQuality(g.execs, g.execContent.traits)} stature={s.stature}
          onHire={g.playerHireExec} onFire={g.playerFireExec} />
      )}
      {tab === "Contracts" && (
        <ContractsTab state={s.contracts} templates={c.contractTemplates} customers={c.customers}
          cfo={{ id: "cfo_dana", name: "Dana Whitfield", domain: "cfo", competence: 74, traits: ["steady"] }}
          rng={g.rng} onTake={g.playerTakeContract} />
      )}
      {tab === "Research" && (
        <ResearchTab state={s.research} nodes={c.researchNodes} ctoName="Priya Raman"
          onStart={g.playerStartResearch} />
      )}
      {tab === "Megaprojects" && (
        <MegaprojectsTab state={s.megas} defs={c.megaprojects}
          gateCtx={{
            researchDone: new Set(Object.entries(s.research.nodes)
              .filter(([, n]) => n.state === "complete").map(([id]) => id)),
            stature: s.stature, cash: s.cashM,
            execDomains: new Set(Object.keys(s.execQualityByDomain)),
            capacity: {}, megasDone: new Set(Object.keys(s.megas.builds)) }}
          sagaLog={sagaLog} execName="Marcus Vale" onBegin={d => g.playerBeginMega(d)} />
      )}
      {tab === "Empire" && (
        <EmpireTab state={s.subEcon} defs={c.subEconomies} synergies={c.synergies}
          activeSynergies={s.activeSynergies} onPosture={g.playerSetPosture} />
      )}
    </div>
  );
}
