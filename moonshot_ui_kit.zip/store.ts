// ============================================================================
// store.ts — The Zustand store hosting GameSlice + the player actions.
// The single source of truth the tabs bind to. Engines stay pure; the store
// owns state, calls engines, and commits results.
// ============================================================================
import { create } from "zustand";
import { GameSlice, GameContent, TurnReport, advanceTurn } from "./turn";
import { initResearch } from "./research";
import { MegaprojectDef, beginMega, checkGate, GateCheck } from "./megaprojects";
import { initContracts, takeContract, refreshMarket, ContractTemplate } from "./contracts";
import { Posture } from "./empire";
import { ExecState, Candidate, initExecs, generateCandidates, hireExec, fireExec,
         tickRetention, execQuality } from "./executives";
import { loadSubEconomies, loadSynergies, loadContracts, loadPowerEvents,
         loadSubEvents, loadResearchNodes, loadMegaprojects, loadExecutives, ExecContent,
         loadRivals, megaMetaFrom, loadEras, loadCycleTuning, loadPressures } from "./content_loader";
import { pressureTriggerMap } from "./pacing";
import { initRivals, tickRivalPoaching } from "./rivals";
import { initCycle } from "./pacing";

// mulberry32 — the deterministic RNG for the whole run
function mulberry32(seed: number) {
  return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}

export function buildExecContent(raw: Record<string, any>): ExecContent {
  return loadExecutives(raw.executives);
}
export function buildContent(raw: Record<string, any>): GameContent {
  const contracts = loadContracts(raw.contracts);
  const megaprojects = loadMegaprojects(raw.megaprojects);
  const rivals = loadRivals(raw.rivals);
  return {
    researchNodes: loadResearchNodes(raw.research),
    megaprojects,
    subEconomies: loadSubEconomies(raw.sub_economies),
    synergies: loadSynergies(raw.synergies),
    contractTemplates: contracts.templates,
    customers: contracts.customers,
    powerEvents: loadPowerEvents(raw.events_power),
    subEvents: loadSubEvents(raw.events_sub),
    worldEvents: loadSubEvents(raw.events_world),
    rivalDefs: rivals.defs,
    rivalTuning: rivals.tuning,
    megaMeta: megaMetaFrom(megaprojects),
    eras: loadEras(raw.eras),
    cycleTuning: loadCycleTuning(raw.cycles),
    pressures: loadPressures(raw.pressures),
    pressureTriggers: pressureTriggerMap(Object.values(loadPressures(raw.pressures))),
  };
}

export function newGame(content: GameContent, seed: number): GameSlice {
  return {
    week: 0, cashM: 150, stature: 200,
    frontsOperated: [], rdLevels: {}, productTiers: {},
    execQualityByDomain: {}, maxMarketShare: 0,
    research: initResearch(Object.values(content.researchNodes)),
    megas: { builds: {}, active: [], slots_total: 1 },
    subEcon: { instances: {}, resource_pool: {} },
    contracts: initContracts(),
    powerAxis: { power: 0, basePower: 0, reputation: 0, regulationLevel: 0, eventCooldowns: {} },
    activeSynergies: [],
    rivals: initRivals(content.rivalDefs, content.rivalTuning, content.megaMeta),
    claimedLegacies: {},
    era: "garage",
    cycle: initCycle(content.cycleTuning, mulberry32(seed ^ 0x5eed)),
    activePressures: [],
    schema_version: 1, ext: {},
    founder: { age_years: 32, founded_week: 0 },
    subsidiaries: [], deals_log: [],
  };
}

interface GameStore {
  content: GameContent | null;
  execContent: ExecContent | null;
  execs: ExecState;
  slice: GameSlice | null;
  lastReport: TurnReport | null;
  reports: TurnReport[];
  rng: () => number;
  // lifecycle
  boot: (raw: Record<string, any>, seed?: number) => void;
  // the player actions (each = one engine call + commit)
  endTurn: () => void;
  playerTakeContract: (t: ContractTemplate) => void;
  playerBeginMega: (def: MegaprojectDef) => { ok: boolean; reason?: string };
  playerStartResearch: (id: string) => void;
  playerSetPosture: (subId: string, p: Posture) => void;
  playerHireExec: (c: Candidate) => void;
  playerFireExec: (domain: string) => void;
  playerRefreshMarket: () => void;
  megaGate: (def: MegaprojectDef) => GateCheck;
}

export const useGame = create<GameStore>((set, get) => ({
  content: null, execContent: null, execs: initExecs(), slice: null, lastReport: null, reports: [], rng: mulberry32(1),

  boot: (raw, seed = Date.now() & 0xffff) => {
    const content = buildContent(raw);
    const execContent = buildExecContent(raw);
    const rng = mulberry32(seed);
    const slice = newGame(content, seed);
    const execs = initExecs();
    execs.market = generateCandidates(execContent.archetypes, execContent.traits,
      execContent.names, execContent.domains, slice.stature, execContent.tuning, rng);
    set({ content, execContent, execs, slice, rng, reports: [], lastReport: null });
  },

  endTurn: () => {
    const { slice, content, execContent, execs, rng, reports } = get();
    if (!slice || !content || !execContent) return;
    const next = structuredClone(slice);            // engines mutate; clone -> new identity for React
    const nextExecs = structuredClone(execs);
    // exec layer first: retention roll, rival raids, market refresh, quality feed
    tickRetention(nextExecs, execContent.traits, execContent.tuning, next.week, 4, rng);
    const raid = tickRivalPoaching(next.rivals, content.rivalDefs, content.rivalTuning,
      nextExecs.seats, execContent.traits, next.week, 4, rng);
    nextExecs.weeks_since_refresh += 4;
    if (nextExecs.weeks_since_refresh >= execContent.tuning.market_refresh_weeks) {
      nextExecs.market = generateCandidates(execContent.archetypes, execContent.traits,
        execContent.names, execContent.domains, next.stature, execContent.tuning, rng);
      nextExecs.weeks_since_refresh = 0;
    }
    next.execQualityByDomain = execQuality(nextExecs, execContent.traits);
    const report = advanceTurn(next, content, rng);
    report.rivalNews.push(...raid.news);
    set({ slice: next, execs: nextExecs, lastReport: report, reports: [...reports.slice(-49), report] });
  },

  playerHireExec: (cand: Candidate) => {
    const { execs, execContent, slice } = get();
    if (!execContent || !slice) return;
    const nextExecs = structuredClone(execs);
    const r = hireExec(nextExecs, cand, cand.ask_salary, slice.week);
    if (!r.ok) return;
    const nextSlice = structuredClone(slice);
    nextSlice.execQualityByDomain = execQuality(nextExecs, execContent.traits);
    set({ execs: nextExecs, slice: nextSlice });
  },

  playerFireExec: (domain: string) => {
    const { execs, execContent, slice } = get();
    if (!execContent || !slice) return;
    const nextExecs = structuredClone(execs);
    const r = fireExec(nextExecs, domain, slice.week, execContent.tuning);
    if (!r) return;
    const nextSlice = structuredClone(slice);
    nextSlice.cashM -= r.severance;
    nextSlice.execQualityByDomain = execQuality(nextExecs, execContent.traits);
    set({ execs: nextExecs, slice: nextSlice });
  },

  playerTakeContract: (t) => {
    const { slice } = get();
    if (!slice) return;
    const next = structuredClone(slice);
    takeContract(next.contracts, t);
    next.cashM += t.payment.upfront;
    set({ slice: next });
  },

  playerBeginMega: (def) => {
    const { slice } = get();
    if (!slice) return { ok: false, reason: "no game" };
    const next = structuredClone(slice);
    const r = beginMega(next.megas, def, next.week);
    if (!r.ok) return r;
    next.cashM -= r.cost;
    set({ slice: next });
    return r;
  },

  playerStartResearch: (id) => {
    const { slice, content } = get();
    if (!slice || !content) return;
    const next = structuredClone(slice);
    const node = content.researchNodes[id];
    const st = next.research.nodes[id];
    if (st && (st.state === "available" || st.state === "locked")) {
      st.state = "in_progress";
      next.cashM -= node.cost;
    }
    set({ slice: next });
  },

  playerSetPosture: (subId, p) => {
    const { slice } = get();
    if (!slice?.subEcon.instances[subId]) return;
    const next = structuredClone(slice);
    next.subEcon.instances[subId].posture = p;
    set({ slice: next });
  },

  playerRefreshMarket: () => {
    const { slice, content, rng } = get();
    if (!slice || !content) return;
    const next = structuredClone(slice);
    refreshMarket(next.contracts, content.contractTemplates, content.customers, {
      stature: next.stature, productTiers: next.productTiers, rdLevels: next.rdLevels,
      frontsOperated: next.frontsOperated, clearances: next.contracts.clearances }, rng);
    set({ slice: next });
  },

  megaGate: (def) => {
    const { slice } = get();
    const s = slice!;
    return checkGate(def, {
      researchDone: new Set(Object.entries(s.research.nodes)
        .filter(([, n]) => n.state === "complete").map(([id]) => id)),
      stature: s.stature, cash: s.cashM,
      execDomains: new Set(Object.keys(s.execQualityByDomain)),
      capacity: {}, megasDone: new Set(Object.keys(s.megas.builds)) });
  },
}));
